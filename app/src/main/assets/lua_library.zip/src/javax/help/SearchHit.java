/*
 * Decompiled with CFR 0_115.
 */
package javax.help;

public class SearchHit {
    private double confidence;
    private int begin;
    private int end;

    public SearchHit(double d, int n, int n2) {
        this.confidence = d;
        this.begin = n;
        this.end = n2;
    }

    public double getConfidence() {
        return this.confidence;
    }

    public int getBegin() {
        return this.begin;
    }

    public int getEnd() {
        return this.end;
    }
}

