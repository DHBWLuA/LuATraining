/*
 * Decompiled with CFR 0_115.
 */
package javax.help.search;

import java.util.EventListener;
import javax.help.search.SearchEvent;

public interface SearchListener
extends EventListener {
    public void itemsFound(SearchEvent var1);

    public void searchStarted(SearchEvent var1);

    public void searchFinished(SearchEvent var1);
}

