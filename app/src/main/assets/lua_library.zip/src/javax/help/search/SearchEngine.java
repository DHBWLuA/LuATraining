/*
 * Decompiled with CFR 0_115.
 */
package javax.help.search;

import java.net.URL;
import java.security.InvalidParameterException;
import java.util.Hashtable;
import javax.help.search.SearchQuery;

public abstract class SearchEngine {
    protected URL base;
    protected Hashtable params;
    private static final boolean debug = false;

    public SearchEngine(URL uRL, Hashtable hashtable) throws InvalidParameterException {
        this.base = uRL;
        this.params = hashtable;
    }

    public SearchEngine() {
    }

    public abstract SearchQuery createQuery() throws IllegalStateException;

    private static void debug(String string) {
    }
}

