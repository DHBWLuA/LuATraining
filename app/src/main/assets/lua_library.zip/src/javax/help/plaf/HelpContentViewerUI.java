/*
 * Decompiled with CFR 0_115.
 */
package javax.help.plaf;

import javax.swing.plaf.ComponentUI;

public abstract class HelpContentViewerUI
extends ComponentUI {
}

