/*
 * Decompiled with CFR 0_115.
 */
package javax.help.search;

import java.io.IOException;
import java.io.PrintStream;
import java.io.Reader;
import java.util.Locale;
import javax.help.search.ConfigFile;
import javax.help.search.IndexBuilder;

public abstract class IndexerKit
implements Cloneable {
    protected IndexBuilder builder;
    protected ConfigFile config;
    protected String file;
    protected Locale locale;
    private boolean debugFlag = false;

    public abstract Object clone();

    public abstract String getContentType();

    public void setLocale(Locale locale) {
        this.locale = locale;
    }

    public void setLocale(String string) {
        Locale locale;
        if (string == null) {
            this.setLocale((Locale)null);
            return;
        }
        String string2 = null;
        int n = string.indexOf("_");
        if (n == -1) {
            String string3 = string;
            String string4 = "";
            locale = new Locale(string3, string4);
        } else {
            String string5 = string.substring(0, n);
            int n2 = string.indexOf("_", n + 1);
            if (n2 == -1) {
                String string6 = string.substring(n + 1);
                locale = new Locale(string5, string6);
            } else {
                String string7 = string.substring(n + 1, n2);
                string2 = string.substring(n2 + 1);
                locale = new Locale(string5, string7, string2);
            }
        }
        this.setLocale(locale);
    }

    public Locale getLocale() {
        return this.locale;
    }

    public abstract void parse(Reader var1, String var2, boolean var3, IndexBuilder var4, ConfigFile var5) throws IOException;

    public abstract int parseIntoTokens(String var1, int var2);

    protected abstract void startStoreDocument(String var1) throws Exception;

    protected abstract void endStoreDocument() throws Exception;

    protected abstract void storeToken(String var1, int var2) throws Exception;

    protected abstract void storeTitle(String var1) throws Exception;

    private void debug(String string) {
        if (this.debugFlag) {
            System.err.println("IndexerKit: " + string);
        }
    }
}

