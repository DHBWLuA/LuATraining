/*
 * Decompiled with CFR 0_115.
 */
package javax.help.search;

import java.io.File;
import java.io.PrintStream;
import java.util.Enumeration;

public abstract class IndexBuilder {
    protected String indexDir;
    private boolean debug = false;

    public IndexBuilder(String string) throws Exception {
        this.debug("indexDir=" + string);
        this.indexDir = string;
        File file = new File(string);
        try {
            if (!file.exists()) {
                this.debug("file " + string + " didn't exist - creating");
                file.mkdirs();
            }
        }
        catch (SecurityException var3_3) {
            // empty catch block
        }
    }

    public abstract void close() throws Exception;

    public abstract void storeStopWords(Enumeration var1);

    public abstract Enumeration getStopWords();

    public abstract void openDocument(String var1) throws Exception;

    public abstract void closeDocument() throws Exception;

    public abstract void storeLocation(String var1, int var2) throws Exception;

    public abstract void storeTitle(String var1) throws Exception;

    private void debug(String string) {
        if (this.debug) {
            System.err.println("IndexBuilder: " + string);
        }
    }
}

