/*
 * Decompiled with CFR 0_115.
 */
package javax.help.event;

import java.util.EventListener;
import javax.help.event.TextHelpModelEvent;

public interface TextHelpModelListener
extends EventListener {
    public void highlightsChanged(TextHelpModelEvent var1);
}

