/*
 * Decompiled with CFR 0_115.
 */
package javax.help.search;

import java.util.Enumeration;
import java.util.EventObject;
import java.util.Vector;

public class SearchEvent
extends EventObject {
    private String params;
    private boolean searching;
    private Vector items;

    public SearchEvent(Object object, String string, boolean bl) {
        super(object);
        if (string == null) {
            throw new IllegalArgumentException("null params");
        }
        this.params = string;
        this.searching = bl;
    }

    public SearchEvent(Object object, String string, boolean bl, Vector vector) {
        super(object);
        if (string == null) {
            throw new IllegalArgumentException("null params");
        }
        this.params = string;
        this.searching = bl;
        if (vector == null) {
            throw new IllegalArgumentException("null items");
        }
        this.items = vector;
    }

    public String getParams() {
        return this.params;
    }

    public boolean isSearchCompleted() {
        return this.searching;
    }

    public Enumeration getSearchItems() {
        if (this.items == null) {
            return null;
        }
        return this.items.elements();
    }
}

