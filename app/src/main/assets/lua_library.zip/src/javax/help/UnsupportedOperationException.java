/*
 * Decompiled with CFR 0_115.
 */
package javax.help;

public class UnsupportedOperationException
extends RuntimeException {
    public UnsupportedOperationException() {
    }

    public UnsupportedOperationException(String string) {
        super(string);
    }
}

