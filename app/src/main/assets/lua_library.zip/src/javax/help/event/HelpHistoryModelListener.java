/*
 * Decompiled with CFR 0_115.
 */
package javax.help.event;

import java.util.EventListener;
import javax.help.event.HelpHistoryModelEvent;

public interface HelpHistoryModelListener
extends EventListener {
    public void historyChanged(HelpHistoryModelEvent var1);
}

