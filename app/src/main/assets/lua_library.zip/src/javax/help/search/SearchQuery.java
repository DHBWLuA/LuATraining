/*
 * Decompiled with CFR 0_115.
 */
package javax.help.search;

import java.util.Enumeration;
import java.util.EventListener;
import java.util.Locale;
import java.util.Vector;
import javax.help.event.EventListenerList;
import javax.help.search.SearchEngine;
import javax.help.search.SearchEvent;
import javax.help.search.SearchItem;
import javax.help.search.SearchListener;

public abstract class SearchQuery {
    protected EventListenerList listenerList = new EventListenerList();
    protected SearchEngine hs;
    protected String searchparams;
    protected Locale l;
    private static final boolean debug = false;
    static /* synthetic */ Class class$javax$help$search$SearchListener;

    public SearchQuery(SearchEngine searchEngine) {
        this.hs = searchEngine;
    }

    public void addSearchListener(SearchListener searchListener) {
        Class class_ = class$javax$help$search$SearchListener == null ? (SearchQuery.class$javax$help$search$SearchListener = SearchQuery.class$("javax.help.search.SearchListener")) : class$javax$help$search$SearchListener;
        this.listenerList.add(class_, searchListener);
    }

    public void removeSearchListener(SearchListener searchListener) {
        Class class_ = class$javax$help$search$SearchListener == null ? (SearchQuery.class$javax$help$search$SearchListener = SearchQuery.class$("javax.help.search.SearchListener")) : class$javax$help$search$SearchListener;
        this.listenerList.remove(class_, searchListener);
    }

    public void start(String string, Locale locale) throws IllegalArgumentException, IllegalStateException {
        this.searchparams = string;
        this.l = locale;
        this.fireSearchStarted();
    }

    public void stop() throws IllegalStateException {
        this.fireSearchFinished();
    }

    public SearchEngine getSearchEngine() {
        return this.hs;
    }

    public abstract boolean isActive();

    public void itemsFound(boolean bl, Vector vector) {
        this.fireItemsFound(bl, vector);
    }

    protected void fireItemsFound(boolean bl, Vector vector) {
        SearchQuery.debug("fireItemsFound");
        SearchQuery.debug("  params: " + this.searchparams);
        SearchQuery.debug("  insearch: " + bl);
        SearchQuery.debug("  docs: " + vector);
        Object[] arrobject = this.listenerList.getListenerList();
        SearchEvent searchEvent = null;
        int n = arrobject.length - 2;
        while (n >= 0) {
            if (arrobject[n] == (class$javax$help$search$SearchListener == null ? SearchQuery.class$("javax.help.search.SearchListener") : class$javax$help$search$SearchListener)) {
                if (searchEvent == null) {
                    searchEvent = new SearchEvent(this, this.searchparams, bl, vector);
                }
                ((SearchListener)arrobject[n + 1]).itemsFound(searchEvent);
            }
            n -= 2;
        }
    }

    protected void fireItemsFound(SearchEvent searchEvent) {
        Object[] arrobject = this.listenerList.getListenerList();
        Vector<SearchItem> vector = new Vector<SearchItem>();
        Enumeration enumeration = searchEvent.getSearchItems();
        while (enumeration.hasMoreElements()) {
            vector.addElement((SearchItem)enumeration.nextElement());
        }
        SearchEvent searchEvent2 = new SearchEvent(this, searchEvent.getParams(), searchEvent.isSearchCompleted(), vector);
        int n = arrobject.length - 2;
        while (n >= 0) {
            if (arrobject[n] == (class$javax$help$search$SearchListener == null ? SearchQuery.class$("javax.help.search.SearchListener") : class$javax$help$search$SearchListener)) {
                ((SearchListener)arrobject[n + 1]).itemsFound(searchEvent2);
            }
            n -= 2;
        }
    }

    protected void fireSearchStarted() {
        SearchQuery.debug("fireSearchStarted");
        Object[] arrobject = this.listenerList.getListenerList();
        SearchEvent searchEvent = null;
        int n = arrobject.length - 2;
        while (n >= 0) {
            if (arrobject[n] == (class$javax$help$search$SearchListener == null ? SearchQuery.class$("javax.help.search.SearchListener") : class$javax$help$search$SearchListener)) {
                if (searchEvent == null) {
                    searchEvent = new SearchEvent(this, this.searchparams, true);
                }
                ((SearchListener)arrobject[n + 1]).searchStarted(searchEvent);
            }
            n -= 2;
        }
    }

    protected void fireSearchFinished() {
        SearchQuery.debug("fireSearchFinished");
        Object[] arrobject = this.listenerList.getListenerList();
        SearchEvent searchEvent = null;
        int n = arrobject.length - 2;
        while (n >= 0) {
            if (arrobject[n] == (class$javax$help$search$SearchListener == null ? SearchQuery.class$("javax.help.search.SearchListener") : class$javax$help$search$SearchListener)) {
                if (searchEvent == null) {
                    searchEvent = new SearchEvent(this, this.searchparams, false);
                }
                ((SearchListener)arrobject[n + 1]).searchFinished(searchEvent);
            }
            n -= 2;
        }
    }

    private static void debug(String string) {
    }

    static /* synthetic */ Class class$(String string) {
        try {
            return Class.forName(string);
        }
        catch (ClassNotFoundException var1_1) {
            throw new NoClassDefFoundError(var1_1.getMessage());
        }
    }
}

