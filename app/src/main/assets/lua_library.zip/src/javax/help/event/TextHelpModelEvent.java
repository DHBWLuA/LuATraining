/*
 * Decompiled with CFR 0_115.
 */
package javax.help.event;

import java.util.EventObject;

public class TextHelpModelEvent
extends EventObject {
    public TextHelpModelEvent(Object object) {
        super(object);
    }
}

