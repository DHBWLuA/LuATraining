/*
 * Decompiled with CFR 0_115.
 */
package javax.help;

public class HelpSetException
extends Exception {
    public HelpSetException(String string) {
        super(string);
    }
}

