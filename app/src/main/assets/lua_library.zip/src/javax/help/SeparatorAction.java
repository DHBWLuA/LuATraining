/*
 * Decompiled with CFR 0_115.
 */
package javax.help;

import javax.help.AbstractHelpAction;

public class SeparatorAction
extends AbstractHelpAction {
    public SeparatorAction(Object object) {
        super(object, "SeparatorAction");
    }
}

