/*
 * Decompiled with CFR 0_115.
 */
package javax.help.search;

import java.net.URL;
import java.util.Enumeration;
import java.util.Vector;

public class SearchItem {
    private URL base;
    private String title;
    private String lang;
    private String filename;
    private double confidence;
    private int begin;
    private int end;
    private Vector concepts;

    public SearchItem(URL uRL, String string, String string2, String string3, double d, int n, int n2, Vector vector) {
        if (uRL == null) {
            throw new NullPointerException("base");
        }
        this.base = uRL;
        if (string == null) {
            throw new NullPointerException("title");
        }
        this.title = string;
        this.lang = string2;
        if (string3 == null) {
            throw new NullPointerException("fileName");
        }
        this.filename = string3;
        this.confidence = d;
        this.begin = n;
        this.end = n2;
        if (vector == null) {
            throw new NullPointerException("concepts");
        }
        this.concepts = vector;
    }

    public URL getBase() {
        return this.base;
    }

    public String getTitle() {
        return this.title;
    }

    public String getLang() {
        return this.lang;
    }

    public String getFilename() {
        return this.filename;
    }

    public double getConfidence() {
        return this.confidence;
    }

    public int getBegin() {
        return this.begin;
    }

    public int getEnd() {
        return this.end;
    }

    public Enumeration getConcepts() {
        return this.concepts.elements();
    }

    public String toString() {
        StringBuffer stringBuffer = new StringBuffer("" + this.confidence + " " + this.title + ":" + this.base + this.filename + " [" + this.begin + "," + this.end + "], {");
        if (this.concepts == null) {
            stringBuffer.append("}");
            return stringBuffer.toString();
        }
        Enumeration enumeration = this.concepts.elements();
        while (enumeration.hasMoreElements()) {
            String string = (String)enumeration.nextElement();
            stringBuffer.append(string);
            if (!enumeration.hasMoreElements()) continue;
            stringBuffer.append(",");
        }
        stringBuffer.append("}");
        return stringBuffer.toString();
    }
}

