/*
 * Decompiled with CFR 0_115.
 */
package javax.help.event;

import java.util.EventListener;
import javax.help.event.HelpModelEvent;

public interface HelpModelListener
extends EventListener {
    public void idChanged(HelpModelEvent var1);
}

