/*
 * Decompiled with CFR 0_115.
 */
package sunw.demo.jhdemo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GraphicsEnvironment;
import java.awt.LayoutManager;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.net.URL;
import java.net.URLClassLoader;
import java.security.AccessControlException;
import java.util.Enumeration;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.zip.ZipEntry;
import javax.help.BadIDException;
import javax.help.DefaultHelpModel;
import javax.help.HelpSet;
import javax.help.HelpSetException;
import javax.help.JHelp;
import javax.help.JHelpContentViewer;
import javax.help.SwingHelpUtilities;
import javax.help.TextHelpModel;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.JViewport;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.text.JTextComponent;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;
import sunw.demo.jhdemo.ElementTreePanel;
import sunw.demo.jhdemo.JHLauncher;

public class JHLauncher {
    private static JFrame frame;
    public static int WIDTH;
    public static int HEIGHT;
    protected static boolean debug;
    protected static boolean setHS;
    private static boolean on12;
    private static Font[] fonts;
    private static JHelp jh;
    HelpSet hs = null;
    private JFrame elementTreeFrame;
    private static String hsName;
    private static String hsPath;
    private static String id;
    private static String spec;
    private JDialog selectionDialog = null;
    private JTextField helpSetName;
    private JTextField helpSetURL;
    private String title = "";

    protected void initialize(String string, ClassLoader classLoader) {
        URL uRL = HelpSet.findHelpSet(classLoader, string, "", Locale.getDefault());
        if (uRL == null && (uRL = HelpSet.findHelpSet(classLoader, string, ".hs", Locale.getDefault())) == null) {
            JOptionPane.showMessageDialog(null, "HelpSet not found", "Error", 0);
            return;
        }
        this.initialize(uRL, classLoader);
    }

    protected void initialize(URL uRL, ClassLoader classLoader) {
        try {
            this.hs = new HelpSet(classLoader, uRL);
        }
        catch (Exception var3_3) {
            JOptionPane.showMessageDialog(null, "HelpSet not found", "Error", 0);
            return;
        }
        jh = new JHelp(this.hs);
    }

    private JMenuBar createMenuBar() {
        JMenuBar jMenuBar = new JMenuBar();
        JMenu jMenu = jMenuBar.add(new JMenu("File"));
        jMenu.setMnemonic('F');
        JMenuItem jMenuItem = jMenu.add(new JMenuItem("Open page"));
        OpenPageListener openPageListener = new OpenPageListener();
        jMenuItem.addActionListener(openPageListener);
        if (setHS) {
            jMenuItem = jMenu.add(new JMenuItem("Set HelpSet"));
            jMenuItem.setMnemonic('s');
            jMenuItem.addActionListener(new ActionListener(){

                public void actionPerformed(ActionEvent actionEvent) {
                    if (JHLauncher.this.selectionDialog == null) {
                        JHLauncher.this.initializeSDGUI();
                    }
                    JHLauncher.this.showSD();
                }
            });
        }
        jMenuItem = jMenu.add(new JMenuItem("Exit"));
        jMenuItem.setMnemonic('x');
        jMenuItem.addActionListener(new ActionListener(){

            public void actionPerformed(ActionEvent actionEvent) {
                System.exit(0);
            }
        });
        JMenu jMenu2 = jMenuBar.add(new JMenu("Options"));
        jMenu2.setMnemonic('O');
        jMenuItem = jMenu2.add(new JMenuItem("Set Font..."));
        SetFontListener setFontListener = new SetFontListener();
        jMenuItem.addActionListener(setFontListener);
        if (debug) {
            jMenuItem = jMenu2.add(new JMenuItem("Show Element Tree"));
            ShowElementTreeListener showElementTreeListener = new ShowElementTreeListener();
            jMenuItem.addActionListener(showElementTreeListener);
        }
        return jMenuBar;
    }

    public Frame getFrame() {
        return frame;
    }

    private JTextComponent getEditor() {
        JHelpContentViewer jHelpContentViewer = jh.getContentViewer();
        JScrollPane jScrollPane = (JScrollPane)jHelpContentViewer.getComponent(0);
        JViewport jViewport = jScrollPane.getViewport();
        return (JTextComponent)jViewport.getView();
    }

    public static void main(String[] arrstring) {
        Object object;
        boolean bl = true;
        String string = System.getProperty("java.version");
        if (string.startsWith("1.0")) {
            System.out.println("!!!WARNING: JavaHelp & Swing must be runwith JDK 1.1.2 or higher version VM!!!");
        }
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }
        catch (Exception var3_3) {
            // empty catch block
        }
        try {
            object = Class.forName("javax.swing.JComponent");
        }
        catch (ClassNotFoundException var3_5) {
            Frame frame = new Frame("Error");
            TextArea textArea = new TextArea("Java Foundation Classes not found.\n\nThe program can only be run using JDK 1.2 and higher.\nIf you are using JDK 1.1 use the hsviewer1_1 utility", 4, 53, 3);
            frame.add(textArea);
            WindowAdapter windowAdapter = new WindowAdapter(){

                public void windowClosing(WindowEvent windowEvent) {
                    System.exit(0);
                }

                public void windowClosed(WindowEvent windowEvent) {
                    System.exit(0);
                }
            };
            frame.addWindowListener(windowAdapter);
            frame.pack();
            frame.show();
            bl = false;
        }
        if (bl) {
            object = new JHLauncher();
            object.setup(arrstring);
        }
    }

    private String[] shiftArgs(String[] arrstring, int n) {
        int n2 = arrstring.length;
        String[] arrstring2 = new String[n2 - n];
        int n3 = 0;
        while (n3 < n2 - n) {
            arrstring2[n3] = arrstring[n3 + n];
            ++n3;
        }
        return arrstring2;
    }

    private static URL[] parseURLs(String string) {
        Object[] arrobject;
        Vector<URL> vector = new Vector<URL>();
        try {
            arrobject = new Object[](string);
            vector.addElement((URL)arrobject);
        }
        catch (Exception var2_3) {
            System.err.println("cannot create URL for " + string);
        }
        arrobject = new URL[vector.size()];
        vector.copyInto(arrobject);
        return arrobject;
    }

    private void setup(String[] arrstring) {
        Object object;
        ClassLoader classLoader = this.getClass().getClassLoader();
        Object var3_3 = null;
        URL uRL = null;
        String string = null;
        while (arrstring.length > 0) {
            URL[] arruRL;
            if (arrstring[0].equals("-helpset")) {
                arrstring = this.shiftArgs(arrstring, 1);
                if (on12) {
                    object = new File(arrstring[0]);
                    this.handleHSFile((File)object);
                    arruRL = JHLauncher.parseURLs(hsPath);
                    try {
                        classLoader = URLClassLoader.newInstance(arruRL, classLoader);
                    }
                    catch (NoClassDefFoundError var8_11) {
                    }
                    catch (NoSuchMethodError var9_14) {}
                } else {
                    hsName = arrstring[0];
                }
                arrstring = this.shiftArgs(arrstring, 1);
                continue;
            }
            if (arrstring[0].equals("-classpath")) {
                object = (arrstring = this.shiftArgs(arrstring, 1))[0];
                if (object.startsWith("//")) {
                    object = object.substring(1);
                }
                if (object.startsWith("..")) {
                    arruRL = System.getProperty("user.dir");
                    object = (String)arruRL + File.separator + (String)object;
                }
                object = new String("file:" + (String)object);
                arruRL = JHLauncher.parseURLs((String)object);
                arrstring = this.shiftArgs(arrstring, 1);
                try {
                    classLoader = URLClassLoader.newInstance(arruRL, classLoader);
                }
                catch (NoClassDefFoundError var8_12) {
                    System.err.println("-classpath not supported in 1.1");
                }
                catch (NoSuchMethodError var9_15) {
                    System.err.println("-classpath not supported in 1.1");
                }
                continue;
            }
            if (arrstring[0].equals("-hsURL")) {
                arrstring = this.shiftArgs(arrstring, 1);
                string = arrstring[0];
                arrstring = this.shiftArgs(arrstring, 1);
                continue;
            }
            if (arrstring[0].equals("-debug")) {
                debug = true;
                arrstring = this.shiftArgs(arrstring, 1);
                continue;
            }
            if (arrstring[0].equals("-ID")) {
                arrstring = this.shiftArgs(arrstring, 1);
                id = arrstring[0];
                arrstring = this.shiftArgs(arrstring, 1);
                continue;
            }
            if (arrstring[0].equals("-contentViewer")) {
                arrstring = this.shiftArgs(arrstring, 1);
                SwingHelpUtilities.setContentViewerUI(arrstring[0]);
                arrstring = this.shiftArgs(arrstring, 1);
                continue;
            }
            this.usage();
        }
        if (string != null) {
            try {
                JHLauncher.debug("hsSpec=" + string);
                uRL = new URL(string);
            }
            catch (Exception var6_7) {
                this.usage("Invalid URL spec for HelpSet");
            }
        }
        if (hsName != null && uRL != null) {
            this.usage();
        }
        if (hsName == null && uRL == null) {
            object = classLoader == null ? ClassLoader.getSystemResource("JHLauncher.data") : classLoader.getResource("JHLauncher.data");
            if (object != null) {
                System.err.println("Found JHLauncher.data at " + object);
            } else {
                setHS = true;
                this.initializeSDGUI();
                this.showSD();
                return;
            }
        }
        if (debug) {
            JHLauncher.debug("hsName: " + hsName);
            JHLauncher.debug("hsURL: " + uRL);
            JHLauncher.debug("loader: " + classLoader);
        }
        if (uRL != null) {
            this.initialize(uRL, classLoader);
        } else {
            this.initialize(hsName, classLoader);
        }
        if (this.hs == null) {
            setHS = true;
            this.initializeSDGUI();
            this.showSD();
            return;
        }
        if (id != null) {
            try {
                jh.setCurrentID(id);
            }
            catch (BadIDException var6_8) {
                System.out.println("ID " + id + " doesn't exist in Helpset");
            }
        }
        this.createFrame(null, null);
        this.launch();
    }

    private void showSD() {
        if (this.selectionDialog != null) {
            this.selectionDialog.pack();
            this.selectionDialog.show();
        }
    }

    private void initializeSDGUI() {
        if (!on12) {
            JOptionPane.showMessageDialog(null, "Cannot set the HelpSet on JDK1.1 Platforms", "Error", 0);
            if (jh == null) {
                System.exit(0);
            } else {
                return;
            }
        }
        this.selectionDialog = new JDialog((Frame)null, "Set HelpSet...", true);
        Box box = Box.createVerticalBox();
        JPanel jPanel = new JPanel();
        jPanel.setLayout(new BoxLayout(jPanel, 1));
        jPanel.setBorder(new TitledBorder(BorderFactory.createEtchedBorder(), "HelpSet Information"));
        Box box2 = Box.createHorizontalBox();
        box2.add(Box.createRigidArea(new Dimension(15, 0)));
        box2.add(new JLabel("HelpSet Name: "));
        this.helpSetName = new JTextField("HolidayHistory.hs", 40);
        this.helpSetName.setEditable(true);
        box2.add(this.helpSetName);
        box2.add(Box.createRigidArea(new Dimension(15, 0)));
        jPanel.add(box2);
        jPanel.add(Box.createVerticalStrut(5));
        box2 = Box.createHorizontalBox();
        box2.add(Box.createRigidArea(new Dimension(15, 0)));
        box2.add(new JLabel("HelpSet URL:  "));
        this.helpSetURL = new JTextField(40);
        box2.add(this.helpSetURL);
        box2.add(Box.createRigidArea(new Dimension(15, 0)));
        JButton jButton = new JButton("Browse...");
        jButton.addActionListener(new ActionListener(){

            public void actionPerformed(ActionEvent actionEvent) {
                File file;
                JFileChooser jFileChooser = new JFileChooser();
                if (jFileChooser.showOpenDialog(JHLauncher.this.selectionDialog) == 0 && (file = jFileChooser.getSelectedFile()) != null) {
                    JHLauncher.this.handleHSFile(file);
                    JHLauncher.this.helpSetURL.setText(hsPath);
                    JHLauncher.this.helpSetName.setText(hsName);
                }
            }
        });
        box2.add(jButton);
        box2.add(Box.createRigidArea(new Dimension(15, 0)));
        jPanel.add(box2);
        jPanel.add(Box.createVerticalStrut(5));
        Box box3 = Box.createHorizontalBox();
        jButton = new JButton("Display");
        jButton.setEnabled(true);
        jButton.addActionListener(new DisplayAction());
        box3.add(jButton);
        box3.add(Box.createRigidArea(new Dimension(15, 0)));
        jButton = new JButton("Cancel");
        jButton.addActionListener(new CancelAction());
        box3.add(jButton);
        box3.add(Box.createRigidArea(new Dimension(15, 0)));
        box.add(Box.createRigidArea(new Dimension(0, 10)));
        box.add(jPanel);
        box.add(Box.createRigidArea(new Dimension(0, 10)));
        box.add(box3);
        box.add(Box.createRigidArea(new Dimension(0, 10)));
        this.selectionDialog.getContentPane().add(box);
    }

    private void handleHSFile(File file) {
        String string;
        Object object;
        string = null;
        hsName = file.getName();
        if (hsName.endsWith(".jar")) {
            string = file.getPath();
            hsName = "";
            try {
                object = new JarFile(file);
                Enumeration<JarEntry> enumeration = object.entries();
                while (enumeration.hasMoreElements()) {
                    ZipEntry zipEntry = enumeration.nextElement();
                    String string2 = zipEntry.getName();
                    if (!string2.endsWith(".hs")) continue;
                    hsName = string2;
                    break;
                }
            }
            catch (IOException var3_4) {}
        } else {
            string = file.getParent();
            string = string == null ? File.separator : string.concat(File.separator);
        }
        if (string.startsWith("//")) {
            string = string.substring(1);
        }
        if (string.startsWith("..")) {
            object = System.getProperty("user.dir");
            string = (String)object + File.separator + string;
        }
        hsPath = new String("file:" + string);
    }

    private String breakPath(String string) {
        StringBuffer stringBuffer = null;
        StringTokenizer stringTokenizer = new StringTokenizer(string, File.pathSeparator);
        while (stringTokenizer.hasMoreTokens()) {
            String string2 = stringTokenizer.nextToken();
            if (stringBuffer == null) {
                stringBuffer = new StringBuffer();
            } else {
                stringBuffer.append("\n");
            }
            stringBuffer.append(string2);
        }
        return stringBuffer.toString();
    }

    public void setTitle(String string) {
        this.title = string;
    }

    public String getTitle() {
        return this.title;
    }

    protected JFrame createFrame(String string, JMenuBar jMenuBar) {
        Object object;
        if (jh == null) {
            return null;
        }
        if (string == null || string.equals("")) {
            object = jh.getModel();
            HelpSet helpSet = object.getHelpSet();
            String string2 = helpSet.getTitle();
            if (string2 == null || string2.equals("")) {
                this.setTitle("Unnamed HelpSet");
            } else {
                this.setTitle(string2);
            }
        } else {
            this.setTitle(string);
        }
        if (frame == null) {
            object = new WindowAdapter(){

                public void windowClosing(WindowEvent windowEvent) {
                    System.exit(0);
                }

                public void windowClosed(WindowEvent windowEvent) {
                    System.exit(0);
                }
            };
            frame = new JFrame(this.getTitle());
            frame.setSize(WIDTH, HEIGHT);
            frame.setForeground(Color.black);
            frame.setBackground(Color.lightGray);
            frame.addWindowListener((WindowListener)object);
            frame.getContentPane().add(jh);
            if (jMenuBar == null) {
                jMenuBar = this.createMenuBar();
            }
            frame.setJMenuBar(jMenuBar);
        } else {
            frame.setTitle(this.getTitle());
        }
        frame.pack();
        return frame;
    }

    protected void setMenuBar(JMenuBar jMenuBar) {
        frame.setJMenuBar(jMenuBar);
    }

    protected void launch() {
        if (frame == null) {
            return;
        }
        frame.setVisible(true);
    }

    protected void usage() {
        this.usage(null);
    }

    protected void usage(String string) {
        if (string != null) {
            System.err.println("JHLauncher: " + string);
        }
        System.err.println("Usage: [-helpset name | -classpath path | -hsURL spec | -ID id | -contentViewer viewerclass]");
        System.exit(1);
    }

    protected static void debug(String string) {
        if (debug) {
            System.err.println("JHLauncher: " + string);
        }
    }

    static {
        WIDTH = 645;
        HEIGHT = 495;
        debug = false;
        setHS = false;
        jh = null;
        hsName = null;
        hsPath = null;
        id = null;
        spec = "";
        try {
            AccessControlException accessControlException = new AccessControlException("");
            on12 = true;
        }
        catch (NoClassDefFoundError var0_1) {
            on12 = false;
        }
    }

    private class DisplayAction
    implements ActionListener {
        private DisplayAction() {
        }

        public void actionPerformed(ActionEvent actionEvent) {
            Object object;
            URLClassLoader uRLClassLoader;
            HelpSet helpSet = null;
            String string = JHLauncher.this.helpSetURL.getText();
            String string2 = JHLauncher.this.helpSetName.getText();
            if (on12) {
                object = JHLauncher.parseURLs(string);
                uRLClassLoader = new URLClassLoader((URL[])object);
            } else {
                uRLClassLoader = null;
            }
            object = HelpSet.findHelpSet(uRLClassLoader, string2);
            if (object == null) {
                JOptionPane.showMessageDialog(JHLauncher.this.selectionDialog, "HelpSet not found", "Error", 0);
                return;
            }
            try {
                helpSet = new HelpSet(uRLClassLoader, (URL)object);
            }
            catch (HelpSetException var7_7) {
                System.err.println("Could not create HelpSet for " + object);
            }
            if (jh == null) {
                jh = new JHelp(helpSet);
            } else {
                jh.setHelpSetPresentation(helpSet.getDefaultPresentation());
                DefaultHelpModel defaultHelpModel = new DefaultHelpModel(helpSet);
                jh.setModel(defaultHelpModel);
            }
            JHLauncher.this.createFrame(helpSet.getTitle(), null);
            JHLauncher.this.launch();
            JHLauncher.this.selectionDialog.hide();
        }
    }

    private class CancelAction
    implements ActionListener {
        private CancelAction() {
        }

        public void actionPerformed(ActionEvent actionEvent) {
            if (frame == null) {
                System.exit(0);
            }
            JHLauncher.this.selectionDialog.setVisible(false);
        }
    }

    class ShowElementTreeListener
    implements ActionListener {
        ShowElementTreeListener() {
        }

        public void actionPerformed(ActionEvent actionEvent) {
            JHLauncher.this.elementTreeFrame = null;
            if (JHLauncher.this.elementTreeFrame == null) {
                Object object;
                try {
                    object = "Element Tree For Current Document";
                    JHLauncher.this.elementTreeFrame = new JFrame((String)object);
                }
                catch (MissingResourceException var2_3) {
                    JHLauncher.this.elementTreeFrame = new JFrame();
                }
                JHLauncher.this.elementTreeFrame.addWindowListener(new WindowAdapter(this){
                    private final /* synthetic */ ShowElementTreeListener this$1;

                    public void windowClosing(WindowEvent windowEvent) {
                        JHLauncher.access$100(ShowElementTreeListener.access$200(this.this$1)).setVisible(false);
                    }
                });
                object = JHLauncher.this.elementTreeFrame.getContentPane();
                object.setLayout(new BorderLayout());
                object.add(new ElementTreePanel(JHLauncher.this.getEditor()));
                JHLauncher.this.elementTreeFrame.pack();
            }
            JHLauncher.this.elementTreeFrame.show();
        }

        static /* synthetic */ JHLauncher access$200(ShowElementTreeListener showElementTreeListener) {
            return showElementTreeListener.JHLauncher.this;
        }
    }

    private class MyFont {
        private Font f;

        public MyFont(Font font) {
            this.f = font;
        }

        public Font getFont() {
            return this.f;
        }

        public String toString() {
            String string = this.f.getFamily();
            String string2 = this.f.getFontName();
            String string3 = string2.substring(string.length());
            if (string3.length() == 0) {
                string3 = "Plain";
            }
            return string3;
        }
    }

    private class SetFontListener
    implements ActionListener,
    TreeSelectionListener,
    ItemListener {
        JDialog sfDialog;
        JComboBox cb;
        JTree fontTree;
        JTextArea preview;
        JButton okButton;
        JButton cancelButton;
        Font font;

        private SetFontListener() {
            this.sfDialog = null;
        }

        public void actionPerformed(ActionEvent actionEvent) {
            try {
                GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
            }
            catch (NoClassDefFoundError var2_3) {
                JOptionPane.showMessageDialog(null, "Setting Fonts on JDK1.1 not allowed", "Set Font...", 0);
                return;
            }
            if (this.sfDialog == null) {
                this.sfDialog = new JDialog(JHLauncher.this.getFrame(), "Set Font...", false);
                this.initSetFontComponents();
                this.sfDialog.pack();
                this.cancelButton.addActionListener(new ActionListener(this){
                    private final /* synthetic */ SetFontListener this$1;

                    public void actionPerformed(ActionEvent actionEvent) {
                        this.this$1.sfDialog.setVisible(false);
                        this.this$1.sfDialog.dispose();
                    }
                });
                this.okButton.addActionListener(new ActionListener(this){
                    private final /* synthetic */ SetFontListener this$1;

                    public void actionPerformed(ActionEvent actionEvent) {
                        JHLauncher.access$000().setFont(this.this$1.font);
                        this.this$1.sfDialog.setVisible(false);
                        this.this$1.sfDialog.dispose();
                    }
                });
            }
            this.font = jh.getFont();
            this.preview.setFont(this.font);
            this.sfDialog.show();
        }

        private void initSetFontComponents() {
            Container container;
            Object object;
            Object object3;
            Object object2;
            Vector vector = new Vector();
            DefaultMutableTreeNode defaultMutableTreeNode2 = new DefaultMutableTreeNode();
            GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
            Font[] arrfont = graphicsEnvironment.getAllFonts();
            int n = 0;
            while (n < arrfont.length) {
                void jScrollPane;
                container = new DefaultMutableTreeNode(new MyFont(arrfont[n]));
                object3 = arrfont[n].getFamily();
                object2 = null;
                Object var10_10 = null;
                object = defaultMutableTreeNode2.children();
                while (object.hasMoreElements()) {
                    DefaultMutableTreeNode defaultMutableTreeNode = (DefaultMutableTreeNode)object.nextElement();
                    object2 = (String)defaultMutableTreeNode.getUserObject();
                    if (object2.compareTo((String)object3) == 0) break;
                    Object var10_13 = null;
                }
                if (jScrollPane == null) {
                    DefaultMutableTreeNode defaultMutableTreeNode = new DefaultMutableTreeNode(object3);
                    defaultMutableTreeNode2.add(defaultMutableTreeNode);
                    defaultMutableTreeNode.add((MutableTreeNode)((Object)container));
                } else {
                    jScrollPane.add((MutableTreeNode)((Object)container));
                }
                ++n;
            }
            container = Box.createVerticalBox();
            object3 = Box.createHorizontalBox();
            this.fontTree = new JTree(defaultMutableTreeNode2);
            this.fontTree.setShowsRootHandles(true);
            this.fontTree.setRootVisible(false);
            object2 = this.fontTree.getSelectionModel();
            object2.addTreeSelectionListener(this);
            JScrollPane jScrollPane = new JScrollPane();
            jScrollPane.getViewport().add(this.fontTree);
            TitledBorder titledBorder = BorderFactory.createTitledBorder("Fonts");
            jScrollPane.setBorder(titledBorder);
            object3.add(Box.createHorizontalStrut(5));
            object3.add(jScrollPane);
            object3.add(Box.createHorizontalStrut(5));
            object = Box.createHorizontalBox();
            this.cb = new JComboBox();
            titledBorder = BorderFactory.createTitledBorder("Size");
            this.cb.setBorder(titledBorder);
            this.cb.setEditable(true);
            this.cb.addItem("8");
            this.cb.addItem("9");
            this.cb.addItem("10");
            this.cb.addItem("11");
            this.cb.addItem("12");
            this.cb.addItem("13");
            this.cb.addItem("14");
            this.cb.addItem("16");
            this.cb.addItem("18");
            this.cb.addItem("20");
            this.cb.addItem("24");
            this.cb.addItem("28");
            this.cb.addItem("32");
            this.cb.addItem("36");
            this.cb.addItem("48");
            this.cb.addItem("72");
            this.cb.setSelectedItem("12");
            this.cb.addItemListener(this);
            object.add(Box.createHorizontalStrut(5));
            object.add(this.cb);
            object.add(Box.createHorizontalStrut(5));
            object3.add((Component)object);
            object3.add(Box.createHorizontalStrut(5));
            container.add(Box.createVerticalStrut(10));
            container.add(Box.createVerticalStrut(5));
            container.add((Component)object3);
            Box box = Box.createHorizontalBox();
            JPanel jPanel = new JPanel();
            titledBorder = BorderFactory.createTitledBorder("Preview");
            jPanel.setBorder(titledBorder);
            this.preview = new JTextArea("\nAaBbCc...XxYyZz\n");
            jPanel.add(this.preview);
            box.add(Box.createHorizontalStrut(5));
            box.add(jPanel);
            box.add(Box.createHorizontalStrut(5));
            container.add(Box.createVerticalStrut(10));
            container.add(box);
            Box box2 = Box.createHorizontalBox();
            this.okButton = new JButton("OK");
            this.cancelButton = new JButton("Cancel");
            box2.add(this.okButton);
            box2.add(this.cancelButton);
            Box box3 = Box.createHorizontalBox();
            box3.add(Box.createHorizontalStrut(5));
            box3.add(new JSeparator());
            box3.add(Box.createHorizontalStrut(5));
            container.add(Box.createVerticalStrut(10));
            container.add(box3);
            container.add(box2);
            this.sfDialog.getContentPane().add(container);
        }

        public void valueChanged(TreeSelectionEvent treeSelectionEvent) {
            JHLauncher.debug("ValueChanged: " + treeSelectionEvent);
            TreePath treePath = this.fontTree.getSelectionPath();
            if (treePath == null) {
                return;
            }
            DefaultMutableTreeNode defaultMutableTreeNode = (DefaultMutableTreeNode)treePath.getLastPathComponent();
            Object object = defaultMutableTreeNode.getUserObject();
            if (object instanceof MyFont) {
                MyFont myFont = (MyFont)object;
                String string = (String)this.cb.getSelectedItem();
                this.font = myFont.getFont().deriveFont(Integer.valueOf(string).floatValue());
                this.preview.setFont(this.font);
            }
        }

        public void itemStateChanged(ItemEvent itemEvent) {
            JHLauncher.debug("ValueChanged: " + itemEvent);
            String string = (String)this.cb.getSelectedItem();
            this.font = this.font.deriveFont(Integer.valueOf(string).floatValue());
            this.preview.setFont(this.font);
        }
    }

    private class OpenPageListener
    implements ActionListener {
        JDialog opDialog;
        JButton okButton;
        JButton cancelButton;
        JButton chooseFileButton;
        JTextField page;

        private OpenPageListener() {
            this.opDialog = null;
        }

        public void actionPerformed(ActionEvent actionEvent) {
            if (this.opDialog == null) {
                this.opDialog = new JDialog(JHLauncher.this.getFrame(), "Open Page", false);
                this.initOpenPageComponents();
                this.opDialog.pack();
                this.cancelButton.addActionListener(new ActionListener(){

                    public void actionPerformed(ActionEvent actionEvent) {
                        OpenPageListener.this.opDialog.setVisible(false);
                        OpenPageListener.this.opDialog.dispose();
                    }
                });
                this.okButton.addActionListener(new ActionListener(this){
                    private final /* synthetic */ OpenPageListener this$1;

                    public void actionPerformed(ActionEvent actionEvent) {
                        try {
                            URL uRL = new URL(this.this$1.page.getText());
                            JHLauncher.access$000().setCurrentURL(uRL);
                        }
                        catch (java.net.MalformedURLException var2_3) {
                            // empty catch block
                        }
                        this.this$1.opDialog.setVisible(false);
                        this.this$1.opDialog.dispose();
                    }
                });
                this.chooseFileButton.addActionListener(new ActionListener(this){
                    private final /* synthetic */ OpenPageListener this$1;

                    public void actionPerformed(ActionEvent actionEvent) {
                        File file;
                        JFileChooser jFileChooser = new JFileChooser();
                        if (jFileChooser.showOpenDialog(JHLauncher.access$000()) == 0 && (file = jFileChooser.getSelectedFile()) != null) {
                            String string = file.getPath();
                            if (string.startsWith("//")) {
                                string = string.substring(1);
                            }
                            this.this$1.page.setText(new String("file:" + string));
                        }
                    }
                });
            }
            this.opDialog.show();
        }

        private void initOpenPageComponents() {
            Box box = Box.createVerticalBox();
            Box box2 = Box.createHorizontalBox();
            JLabel jLabel = new JLabel("Enter the WWW location (URL) or specify the local file you would like to open");
            box2.add(Box.createHorizontalStrut(5));
            box2.add(jLabel);
            box2.add(Box.createHorizontalStrut(5));
            box.add(Box.createVerticalStrut(5));
            box.add(box2);
            Box box3 = Box.createHorizontalBox();
            JLabel jLabel2 = new JLabel("URL: ");
            this.page = new JTextField(20);
            this.page.setEditable(true);
            this.chooseFileButton = new JButton("Choose File...");
            this.chooseFileButton.setAlignmentY(0.5f);
            box3.add(Box.createHorizontalStrut(5));
            box3.add(jLabel2);
            box3.add(this.page);
            box3.add(Box.createHorizontalStrut(5));
            box3.add(this.chooseFileButton);
            box3.add(Box.createHorizontalStrut(5));
            box.add(Box.createVerticalStrut(10));
            box.add(box3);
            Box box4 = Box.createHorizontalBox();
            this.okButton = new JButton("OK");
            this.cancelButton = new JButton("Cancel");
            box4.add(this.okButton);
            box4.add(this.cancelButton);
            Box box5 = Box.createHorizontalBox();
            box5.add(Box.createHorizontalStrut(5));
            box5.add(new JSeparator());
            box5.add(Box.createHorizontalStrut(5));
            box.add(Box.createVerticalStrut(10));
            box.add(box5);
            box.add(box4);
            this.opDialog.getContentPane().add(box);
        }
    }

}

