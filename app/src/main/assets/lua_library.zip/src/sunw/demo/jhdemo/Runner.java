/*
 * Decompiled with CFR 0_115.
 */
package sunw.demo.jhdemo;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.URL;
import java.util.Enumeration;
import java.util.Vector;
import java.util.jar.Attributes;
import java.util.jar.Manifest;

public class Runner {
    public static void main(String[] arrstring) {
        Runner runner = new Runner();
        ClassLoader classLoader = ClassLoader.getSystemClassLoader();
        String string = null;
        String string2 = null;
        try {
            Object object;
            Object object2;
            Object object3;
            Enumeration<URL> enumeration = classLoader.getResources("META-INF/MANIFEST.MF");
            while (enumeration.hasMoreElements()) {
                object = enumeration.nextElement();
                object2 = object.openStream();
                Manifest manifest = new Manifest((InputStream)object2);
                object3 = manifest.getMainAttributes();
                string = object3.getValue("Run-Class");
                string2 = object3.getValue("Arguments");
                if (string != null) break;
            }
            object = Runner.getArgs(string2);
            object2 = classLoader.loadClass(string);
            object3 = object2.getMethod("main", object.getClass());
            object3.setAccessible(true);
            int n = object3.getModifiers();
            if (object3.getReturnType() != Void.TYPE || !Modifier.isStatic(n) || !Modifier.isPublic(n)) {
                throw new NoSuchMethodException("main");
            }
            object3.invoke(null, object);
        }
        catch (IllegalAccessException var6_6) {
        }
        catch (IOException var7_9) {
            var7_9.printStackTrace();
        }
        catch (ClassNotFoundException var8_11) {
            var8_11.printStackTrace();
        }
        catch (NoSuchMethodException var9_13) {
            var9_13.printStackTrace();
        }
        catch (InvocationTargetException var10_15) {
            var10_15.printStackTrace();
        }
    }

    private static String[] getArgs(String string) {
        int n;
        Vector<String> vector = new Vector<String>();
        int n2 = 0;
        int n3 = string.length();
        do {
            int n4 = string.indexOf(" ", n2);
            int n5 = string.indexOf("\"", n2);
            if (n5 != -1 && n4 < n5 || n5 == -1 && n4 != -1) {
                vector.add(string.substring(n2, n4));
                n2 = n4 + 1;
                continue;
            }
            if ((n4 == 1 || n5 >= n4) && (n4 != -1 || n5 == -1)) break;
            n = string.indexOf("\"", n5 + 1);
            if (n == -1) {
                n2 = n5 + 1;
                continue;
            }
            vector.add(string.substring(n5 + 1, n - 1));
            n2 = n + 1;
        } while (true);
        if (n3 != n2) {
            vector.add(string.substring(n2, n3));
        }
        String[] arrstring = new String[vector.size()];
        Enumeration enumeration = vector.elements();
        n = 0;
        while (enumeration.hasMoreElements()) {
            arrstring[n] = (String)enumeration.nextElement();
            ++n;
        }
        return arrstring;
    }
}

