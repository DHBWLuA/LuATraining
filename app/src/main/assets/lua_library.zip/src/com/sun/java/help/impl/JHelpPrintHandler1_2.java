/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.impl;

import com.sun.java.help.impl.JHelpPrintHandler;
import javax.help.JHelp;

public class JHelpPrintHandler1_2
extends JHelpPrintHandler {
    public JHelpPrintHandler1_2(JHelp jHelp) {
        super(jHelp);
    }
}

