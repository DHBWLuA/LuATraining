/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.search;

import com.sun.java.help.search.RAFFile;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.security.Permission;

public final class TemporaryRAFFile
extends RAFFile {
    private RandomAccessFile raf;
    private Permission permission;
    private static final boolean debug = false;

    public TemporaryRAFFile(File file, Permission permission) throws IOException {
        TemporaryRAFFile.debug("TemporaryRAFFile " + file);
        this.raf = new RandomAccessFile(file, "r");
        this.permission = permission;
    }

    public long length() throws IOException {
        return this.raf.length();
    }

    public long getFilePointer() throws IOException {
        return this.raf.getFilePointer();
    }

    public void close() throws IOException {
        this.raf.close();
    }

    public void seek(long l) throws IOException {
        this.raf.seek(l);
    }

    public int readInt() throws IOException {
        return this.raf.readInt();
    }

    public int read() throws IOException {
        return this.raf.read();
    }

    public void readFully(byte[] arrby) throws IOException {
        this.raf.readFully(arrby);
    }

    public int read(byte[] arrby, int n, int n2) throws IOException {
        return this.raf.read(arrby, n, n2);
    }

    public void writeInt(int n) throws IOException {
        this.raf.writeInt(n);
    }

    public void write(byte[] arrby) throws IOException {
        this.raf.write(arrby);
    }

    private static void debug(String string) {
    }
}

