/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.search;

import com.sun.java.help.search.ByteArrayDecompressor;
import com.sun.java.help.search.ConceptData;
import com.sun.java.help.search.ConceptGroupGenerator;
import com.sun.java.help.search.GeneratorHeap;
import com.sun.java.help.search.IntegerArray;
import com.sun.java.help.search.NextDocGenerator;
import com.sun.java.help.search.NextDocGeneratorHeap;
import com.sun.java.help.search.Query;
import com.sun.java.help.search.RoleFiller;
import com.sun.java.help.search.SearchEnvironment;
import java.io.PrintStream;
import javax.help.search.SearchQuery;

class Search {
    private static final int InitNConcepts = 128;
    private SearchEnvironment _env;
    private int _max;
    private int _nConcepts;
    private int _nQueries;
    private ConceptGroupGenerator _firstGenerator = new ConceptGroupGenerator();
    private int[] _concepts = new int[16];
    private int _free2;
    private int _size2;
    private int _startingIndex = 0;
    private int _limit = 0;
    private Query[] _query;
    private ConceptData[] _conceptData;
    private GeneratorHeap _genHeap = new GeneratorHeap();
    private int _document;
    private byte[] _data = null;
    private int _base = 0;
    private NextDocGeneratorHeap _nextDocGenHeap = new NextDocGeneratorHeap();
    private IntegerArray _kTable = new IntegerArray();
    private IntegerArray _offsets = new IntegerArray();
    private IntegerArray _maxConcepts = new IntegerArray();
    private IntegerArray _docConcepts = new IntegerArray();
    private IntegerArray _queryMasks = new IntegerArray();
    private int _maxHitsToShow = 100;

    public Search(SearchEnvironment searchEnvironment, int n) {
        this._env = searchEnvironment;
        this._nQueries = 1;
        this._query = new Query[this._nQueries];
        this._size2 = 128;
        this._free2 = 0;
        this._conceptData = new ConceptData[this._size2];
        this._query[0] = new Query(searchEnvironment, n, null);
    }

    public void addTerm(int n, int n2, double d, int n3) {
        if (this._env.occursInText(n2)) {
            if (this._free2 == this._size2) {
                ConceptData[] arrconceptData = new ConceptData[this._size2 *= 2];
                System.arraycopy(this._conceptData, 0, arrconceptData, 0, this._free2);
                this._conceptData = arrconceptData;
            }
            this._conceptData[this._free2++] = new ConceptData(n2, n, d, n3, this._query[n3].getNColumns());
        }
    }

    public void startSearch(SearchQuery searchQuery) {
        int n;
        this.quicksort(0, this._free2 - 1);
        int n2 = 0;
        while (n2 < this._free2 - 1) {
            n = n2 + 1;
            while (n < this._free2) {
                if (this._conceptData[n2].crqEquals(this._conceptData[n])) {
                    this._conceptData[n] = null;
                } else {
                    n2 = n;
                }
                ++n;
            }
            n2 = n;
        }
        n2 = 0;
        while (n2 < this._free2 - 1) {
            n = n2 + 1;
            while (n < this._free2) {
                if (this._conceptData[n] != null) {
                    if (this._conceptData[n2].cEquals(this._conceptData[n])) {
                        this._conceptData[n2].addLast(this._conceptData[n]);
                        this._conceptData[n] = null;
                    } else {
                        n2 = n;
                    }
                }
                ++n;
            }
            n2 = n;
        }
        n2 = 0;
        while (n2 < this._free2 - 1) {
            if (this._conceptData[n2] == null) {
                n = n2 + 1;
                while (n < this._free2) {
                    if (this._conceptData[n] != null) {
                        this._conceptData[n2] = this._conceptData[n];
                        this._conceptData[n] = null;
                        break;
                    }
                    ++n;
                }
            }
            ++n2;
        }
        this._nextDocGenHeap.reset();
        n2 = 0;
        while (n2 < this._free2 && this._conceptData[n2] != null) {
            NextDocGenerator nextDocGenerator = new NextDocGenerator(this._conceptData[n2], this._env);
            try {
                nextDocGenerator.first();
                if (nextDocGenerator.getDocument() != -1) {
                    this._conceptData[n2].setConceptLength(this._env.getConceptLength(this._conceptData[n2].getConcept()));
                    this._nextDocGenHeap.addGenerator(nextDocGenerator);
                }
            }
            catch (Exception var5_5) {
                var5_5.printStackTrace();
            }
            ++n2;
        }
        this._nextDocGenHeap.start();
        this.searchDocument();
        if (searchQuery == null) {
            this.printResults(this._maxHitsToShow);
        } else {
            this._query[0].makeEvent(this._maxHitsToShow, searchQuery);
        }
    }

    private void searchDocument() {
        RoleFiller[] arrroleFiller = new RoleFiller[this._nQueries];
        do {
            try {
                switch (this.nextDocument(arrroleFiller)) {
                    case 0: {
                        this._genHeap.start(arrroleFiller);
                        while (this._genHeap.next(arrroleFiller)) {
                        }
                        break;
                    }
                    case 1: {
                        if (!this._firstGenerator.next()) break;
                        this._firstGenerator.generateFillers(arrroleFiller);
                        while (this._firstGenerator.next()) {
                            this._firstGenerator.generateFillers(arrroleFiller);
                        }
                        break;
                    }
                    case 2: {
                        return;
                    }
                }
            }
            catch (Exception var2_2) {
                var2_2.printStackTrace(System.err);
                continue;
            }
            int n = 0;
            while (n < this._nQueries) {
                RoleFiller roleFiller = arrroleFiller[n];
                if (roleFiller != null && roleFiller != RoleFiller.STOP) {
                    roleFiller.scoreList(this._query[n], this._document);
                }
                ++n;
            }
            this._genHeap.reset();
        } while (this._nextDocGenHeap.isNonEmpty());
    }

    private int indexOf(int n) throws Exception {
        int n2 = this._startingIndex;
        int n3 = this._nConcepts;
        while (n2 <= n3) {
            int n4 = (n2 + n3) / 2;
            if (this._concepts[n4] < n) {
                n2 = n4 + 1;
                continue;
            }
            if (n < this._concepts[n4]) {
                n3 = n4 - 1;
                continue;
            }
            this._startingIndex = n4 + 1;
            return n4;
        }
        throw new Exception("indexOf " + n + " not found");
    }

    private void printResults(int n) {
        int n2 = 0;
        while (n2 < this._nQueries) {
            System.out.println("query " + n2);
            if (this._query[n2] != null) {
                this._query[n2].printHits(n);
            }
            ++n2;
        }
    }

    private ConceptGroupGenerator makeGenerator(int n) throws Exception {
        int n2;
        int n3;
        if (n > 0) {
            n3 = this._base + this._offsets.at(n - 1);
            n2 = this._maxConcepts.at(n - 1);
        } else {
            n3 = this._base;
            n2 = 0;
        }
        ConceptGroupGenerator conceptGroupGenerator = new ConceptGroupGenerator(this._data, n3, this._kTable.at(2 * n + 1));
        this._nConcepts = conceptGroupGenerator.decodeConcepts(this._kTable.at(2 * n), n2, this._concepts);
        this._max = n < this._limit ? (this._concepts[this._nConcepts] = this._maxConcepts.at(n)) : this._concepts[this._nConcepts - 1];
        this._genHeap.addGenerator(conceptGroupGenerator);
        this._startingIndex = 0;
        return conceptGroupGenerator;
    }

    private boolean openDocumentIndex(int n) throws Exception {
        this._data = this._env.getPositions(n);
        this._base = 0;
        this._startingIndex = 0;
        int n2 = this._data[this._base] & 255;
        switch (n2 >> 6) {
            case 0: {
                byte by = this._data[this._base + 1];
                this._firstGenerator.init(this._data, this._base += 2, by);
                this._nConcepts = this._firstGenerator.decodeConcepts(n2 & 63, 0, this._concepts);
                return false;
            }
            case 2: {
                this._kTable.clear();
                this._offsets.clear();
                this._maxConcepts.clear();
                ByteArrayDecompressor byteArrayDecompressor = new ByteArrayDecompressor(this._data, this._base + 1);
                byteArrayDecompressor.decode(n2 & 63, this._kTable);
                byteArrayDecompressor.ascDecode(this._kTable.popLast(), this._offsets);
                byteArrayDecompressor.ascDecode(this._kTable.popLast(), this._maxConcepts);
                this._base += 1 + byteArrayDecompressor.bytesRead();
                this._limit = this._maxConcepts.cardinality();
                return true;
            }
            case 1: 
            case 3: {
                throw new Exception("extents not yet implemented\n");
            }
        }
        return false;
    }

    private int nextDocument(RoleFiller[] arrroleFiller) throws Exception {
        while (this._nextDocGenHeap.isNonEmpty()) {
            int n = 0;
            while (n < this._nQueries) {
                if (this._query[n] != null) {
                    this._query[n].resetForNextDocument();
                }
                ++n;
            }
            int n2 = 0;
            this._document = this._nextDocGenHeap.getDocument();
            this._docConcepts.clear();
            this._queryMasks.clear();
            do {
                this._docConcepts.add(this._nextDocGenHeap.getConcept());
                this._queryMasks.add(this._nextDocGenHeap.getQueryMask());
                int n3 = n2++;
                ConceptData conceptData = this._nextDocGenHeap.getTerms();
                this._conceptData[n3] = conceptData;
                conceptData.runBy(this._query);
                this._nextDocGenHeap.step();
            } while (this._nextDocGenHeap.atDocument(this._document));
            int n4 = 0;
            int n5 = 0;
            while (n5 < this._nQueries) {
                if (this._query[n5] != null) {
                    if (this._query[n5].vote()) {
                        arrroleFiller[n5] = null;
                        n4 |= 1 << n5;
                    } else {
                        arrroleFiller[n5] = RoleFiller.STOP;
                    }
                }
                ++n5;
            }
            if (n4 == 0) continue;
            if (this.openDocumentIndex(this._document)) {
                int n6 = 0;
                while ((this._queryMasks.at(n6) & n4) == 0) {
                    ++n6;
                }
                int n7 = this._docConcepts.at(n6);
                int n8 = 0;
                while (n7 > this._maxConcepts.at(n8) && ++n8 < this._limit) {
                }
                ConceptGroupGenerator conceptGroupGenerator = this.makeGenerator(n8);
                conceptGroupGenerator.addTerms(this.indexOf(n7), this._conceptData[n6]);
                while (++n6 < n2) {
                    if ((this._queryMasks.at(n6) & n4) > 0) {
                        n7 = this._docConcepts.at(n6);
                        if (n7 > this._max) {
                            while (n7 > this._maxConcepts.at(n8) && ++n8 < this._limit) {
                            }
                            conceptGroupGenerator = this.makeGenerator(n8);
                        }
                        conceptGroupGenerator.addTerms(this.indexOf(n7), this._conceptData[n6]);
                    }
                    ++n6;
                }
                return 0;
            }
            int n9 = 0;
            while (n9 < n2) {
                if ((this._queryMasks.at(n9) & n4) != 0) {
                    this._firstGenerator.addTerms(this.indexOf(this._docConcepts.at(n9)), this._conceptData[n9]);
                }
                ++n9;
            }
            return 1;
        }
        return 2;
    }

    private int partition(int n, int n2) {
        ConceptData conceptData = this._conceptData[n];
        int n3 = n - 1;
        int n4 = n2 + 1;
        do {
            if (conceptData.compareWith(this._conceptData[--n4])) {
                continue;
            }
            while (this._conceptData[++n3].compareWith(conceptData)) {
            }
            if (n3 >= n4) break;
            ConceptData conceptData2 = this._conceptData[n3];
            this._conceptData[n3] = this._conceptData[n4];
            this._conceptData[n4] = conceptData2;
        } while (true);
        return n4;
    }

    private void quicksort(int n, int n2) {
        if (n < n2) {
            int n3 = this.partition(n, n2);
            this.quicksort(n, n3);
            this.quicksort(n3 + 1, n2);
        }
    }
}

