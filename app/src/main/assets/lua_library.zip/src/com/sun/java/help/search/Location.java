/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.search;

class Location {
    private final int _docID;
    private final int _begin;
    private final int _end;

    public Location(int n, int n2, int n3) {
        this._docID = n;
        this._begin = n2;
        this._end = n3;
    }

    public int getDocument() {
        return this._docID;
    }

    public int getBegin() {
        return this._begin;
    }

    public int getEnd() {
        return this._end;
    }
}

