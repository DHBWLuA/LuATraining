/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.search;

import com.sun.java.help.search.ConceptData;
import com.sun.java.help.search.Location;
import com.sun.java.help.search.Query;
import java.io.PrintStream;

class RoleFiller {
    static int Threshold = 300;
    private ConceptData _conceptData;
    private byte _fixedRole;
    private short _filled;
    private int _begin;
    private int _end;
    private int _limit;
    private RoleFiller _next;
    private RoleFiller[] _fillers;
    public static final RoleFiller STOP = new RoleFiller();

    private RoleFiller() {
    }

    public RoleFiller(int n, ConceptData conceptData, int n2, int n3, int n4) {
        this._conceptData = conceptData;
        this._fixedRole = (byte)n2;
        this._filled = (short)(1 << this._fixedRole);
        this._begin = n3;
        this._end = this._begin + conceptData.getConceptLength();
        this._limit = n4;
        this._next = null;
        this._fillers = new RoleFiller[n];
        this._fillers[n2] = this;
    }

    public void print(PrintStream printStream) {
        printStream.println("" + this._begin + ", " + this._end);
    }

    void makeQueryHit(Query query, int n, int n2, double d) {
        if (query.goodEnough(d)) {
            int[] arrn = query.getConceptArrayOfNewHit(d, new Location(n2, this._begin, this._end));
            int n3 = 0;
            while (n3 < n) {
                arrn[n3] = (this._filled & 1 << n3) != 0 ? this._fillers[n3].getConcept() : 0;
                ++n3;
            }
        }
    }

    boolean isHit() {
        return this._filled > 1 << this._fixedRole;
    }

    double getScore() {
        return this._conceptData.getScore();
    }

    int getConcept() {
        return this._conceptData.getConcept();
    }

    RoleFiller next() {
        return this._next;
    }

    void use(RoleFiller[] arrroleFiller, int n) {
        if (arrroleFiller[n] != null) {
            RoleFiller roleFiller = arrroleFiller[n];
            arrroleFiller[n] = this;
            this._next = roleFiller;
            while (roleFiller._limit >= this._begin) {
                if (this._fixedRole != roleFiller._fixedRole) {
                    if ((roleFiller._filled & 1 << this._fixedRole) == 0) {
                        roleFiller._filled = (short)(roleFiller._filled | 1 << this._fixedRole);
                        roleFiller._fillers[this._fixedRole] = this;
                        roleFiller._end = this._end;
                    } else {
                        roleFiller.considerReplacementWith(this);
                    }
                }
                if (roleFiller._next != null) {
                    roleFiller = roleFiller._next;
                    continue;
                }
                return;
            }
        } else {
            arrroleFiller[n] = this;
        }
    }

    private void considerReplacementWith(RoleFiller roleFiller) {
        byte by = roleFiller._fixedRole;
        if (roleFiller.getScore() > this._fillers[by].getScore()) {
            this._fillers[by] = roleFiller;
        }
    }

    private double penalty(Query query, int n) {
        int n2 = this._end - this._begin + 1;
        double d = query.lookupPenalty(this._filled);
        int n3 = 0;
        while (n3 < n) {
            if ((this._filled & 1 << n3) != 0) {
                d += this._fillers[n3]._conceptData.getPenalty();
                n2 -= this._fillers[n3]._conceptData.getConceptLength() + 1;
                if (this._filled >> n3 + 1 != 0) {
                    int n4 = n3 + 1;
                    while (n4 < n) {
                        if ((this._filled & 1 << n4) != 0 && this._fillers[n4]._begin < this._begin) {
                            d += query.getOutOufOrderPenalty();
                        }
                        ++n4;
                    }
                }
            }
            ++n3;
        }
        return d + (double)n2 * query.getGapPenalty();
    }

    public void scoreList(Query query, int n) {
        int n2 = query.getNColumns();
        RoleFiller roleFiller = this;
        double d = roleFiller.penalty(query, n2);
        RoleFiller roleFiller2 = roleFiller._next;
        while (roleFiller2 != null) {
            if (roleFiller2._end < roleFiller._begin) {
                roleFiller.makeQueryHit(query, n2, n, d);
                roleFiller = roleFiller2;
                d = roleFiller.penalty(query, n2);
            } else {
                double d2 = roleFiller2.penalty(query, n2);
                if (d2 <= d) {
                    d = d2;
                    roleFiller = roleFiller2;
                }
            }
            roleFiller2 = roleFiller2._next;
        }
        roleFiller.makeQueryHit(query, n2, n, d);
    }
}

