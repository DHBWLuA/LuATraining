/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.search;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.Reader;
import java.net.URL;
import java.net.URLConnection;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Vector;

public class Schema {
    private String _dirName;
    private URL _hsBase = null;
    private boolean _update;
    private Vector _lines = new Vector();
    private static boolean debugFlag = false;

    public static void main(String[] arrstring) {
        try {
            Schema schema = new Schema(null, "/files/resources/lexicon/LIF_ONT", false);
            Schema.debug(schema.parametersAsString("EDGE"));
            Schema.debug(schema.parametersAsString("TMAP"));
            Schema.debug(schema.parameters("EDGE").get("rt").toString());
            Schema.debug(schema.parameters("EDGE").get("vl").toString());
        }
        catch (Exception var1_2) {
            var1_2.printStackTrace();
        }
    }

    public Schema(URL uRL, String string, boolean bl) throws Exception {
        this._hsBase = uRL;
        this._dirName = string;
        this._update = bl;
        try {
            this.read();
        }
        catch (FileNotFoundException var4_4) {
            Schema.debug("error creating SCHEMA");
        }
        int n = 0;
        while (n < this._lines.size()) {
            Schema.debug(this._lines.elementAt(n).toString());
            ++n;
        }
    }

    public void update(String string, String string2) {
        int n = 0;
        while (n < this._lines.size()) {
            if (((String)this._lines.elementAt(n)).startsWith(string)) {
                this._lines.removeElementAt(n);
            }
            ++n;
        }
        this._lines.addElement(string + " " + string2);
    }

    public String parametersAsString(String string) {
        int n = 0;
        while (n < this._lines.size()) {
            if (((String)this._lines.elementAt(n)).startsWith(string)) {
                return ((String)this._lines.elementAt(n)).substring(string.length() + 1);
            }
            ++n;
        }
        return null;
    }

    public Hashtable parameters(String string) {
        int n = 0;
        while (n < this._lines.size()) {
            if (((String)this._lines.elementAt(n)).startsWith(string)) {
                Hashtable<String, String> hashtable = new Hashtable<String, String>();
                StringTokenizer stringTokenizer = new StringTokenizer((String)this._lines.elementAt(n), " =");
                stringTokenizer.nextToken();
                while (stringTokenizer.hasMoreTokens()) {
                    hashtable.put(stringTokenizer.nextToken(), stringTokenizer.nextToken());
                }
                return hashtable;
            }
            ++n;
        }
        return null;
    }

    public URL getURL(String string) throws Exception {
        URL uRL = null;
        Object var4_3 = null;
        Schema.debug("getURL " + string);
        Schema.debug("dirName=" + this._dirName + " hsBase= " + this._hsBase);
        if (this._hsBase == null) {
            File file = new File(this._dirName);
            if (file.exists()) {
                if (File.separatorChar != '/') {
                    this._dirName = this._dirName.replace(File.separatorChar, '/');
                }
                if (this._dirName.lastIndexOf(47) != this._dirName.length() - 1) {
                    this._dirName = this._dirName.concat("/");
                }
                Schema.debug("file:" + this._dirName);
                uRL = new URL("file", "", this._dirName);
            } else {
                uRL = new URL(this._dirName);
            }
        }
        if (this._hsBase != null) {
            return new URL(this._hsBase, this._dirName + "/" + string);
        }
        return new URL(uRL, string);
    }

    public void save() {
        if (this._update) {
            try {
                FileWriter fileWriter = new FileWriter(this._dirName + "/SCHEMA");
                fileWriter.write("JavaSearch 1.0\n");
                int n = 0;
                while (n < this._lines.size()) {
                    fileWriter.write((String)this._lines.elementAt(n));
                    fileWriter.write(10);
                    ++n;
                }
                fileWriter.close();
            }
            catch (IOException var1_2) {
                System.err.println("SCHEMA save failed " + var1_2);
            }
        }
    }

    private void read() throws Exception {
        String string;
        URL uRL = this.getURL("SCHEMA");
        URLConnection uRLConnection = uRL.openConnection();
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(uRLConnection.getInputStream()));
        while ((string = bufferedReader.readLine()) != null) {
            this._lines.addElement(string);
        }
        bufferedReader.close();
    }

    private static void debug(String string) {
        if (debugFlag) {
            System.out.println("Schema: " + string);
        }
    }
}

