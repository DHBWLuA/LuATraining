/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.search;

import java.lang.reflect.Method;

class Utilities {
    static /* synthetic */ Class class$java$lang$String;

    Utilities() {
    }

    public static String URLDecoder(String string) {
        String string2 = string;
        try {
            Class class_ = Class.forName("java.net.URLDecoder");
            Class[] arrclass = new Class[1];
            Class class_2 = class$java$lang$String == null ? (Utilities.class$java$lang$String = Utilities.class$("java.lang.String")) : class$java$lang$String;
            arrclass[0] = class_2;
            Class[] arrclass2 = arrclass;
            Method method = class_.getMethod("decode", arrclass2);
            if (method != null) {
                Object[] arrobject = new Object[]{string};
                string2 = (String)method.invoke(null, arrobject);
            }
        }
        catch (Throwable var2_3) {
            var2_3.printStackTrace();
        }
        return string2;
    }

    static /* synthetic */ Class class$(String string) {
        try {
            return Class.forName(string);
        }
        catch (ClassNotFoundException var1_1) {
            throw new NoClassDefFoundError(var1_1.getMessage());
        }
    }
}

