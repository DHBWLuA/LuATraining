/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.search;

import com.sun.java.help.search.Decompressor;

class ByteArrayDecompressor
extends Decompressor {
    private byte[] _array;
    private int _index;
    private int _index0;

    public ByteArrayDecompressor(byte[] arrby, int n) {
        this.initReading(arrby, n);
    }

    public void initReading(byte[] arrby, int n) {
        this._array = arrby;
        this._index = this._index0 = n;
        this.initReading();
    }

    public int bytesRead() {
        return this._index - this._index0;
    }

    protected int getNextByte() throws Exception {
        return this._array[this._index++] & 255;
    }
}

