/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.search;

import com.sun.java.help.search.Rule;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Vector;

public abstract class LiteMorph {
    protected static Vector variants;
    protected static Hashtable rulesTable;
    protected static Hashtable blockedVariants;
    protected static Hashtable exceptions;
    private static final boolean debugFlag = false;

    public LiteMorph() {
        this.initialize();
    }

    public static LiteMorph getMorph() {
        return null;
    }

    protected abstract void initialize();

    protected void initialize(String[] arrstring) {
        if (exceptions == null || arrstring == null) {
            return;
        }
        int n = 0;
        while (n < arrstring.length) {
            StringTokenizer stringTokenizer = new StringTokenizer(arrstring[n], " ");
            while (stringTokenizer.hasMoreTokens()) {
                String string = stringTokenizer.nextToken();
                String string2 = (String)exceptions.get(string);
                if (string2 == null) {
                    exceptions.put(string, arrstring[n]);
                    continue;
                }
                exceptions.put(string, string2 + " " + arrstring[n]);
            }
            ++n;
        }
    }

    public synchronized String[] variantsOf(String string) {
        variants = new Vector<E>();
        blockedVariants = new Hashtable<K, V>();
        blockedVariants.put(string, string);
        this.morphWord(string, 0);
        blockedVariants = null;
        Object[] arrobject = new String[variants.size()];
        variants.copyInto(arrobject);
        variants = null;
        return arrobject;
    }

    protected void morphWord(String string, int n) {
        LiteMorph.debug(" analyzing: " + string + " at depth " + n);
        if (n > 2) {
            return;
        }
        String string2 = (String)exceptions.get(string);
        if (string2 == null) {
            string2 = "";
        }
        if (string2.length() > 0) {
            StringTokenizer stringTokenizer = new StringTokenizer(string2, " ");
            while (stringTokenizer.hasMoreTokens()) {
                this.addVariant(stringTokenizer.nextToken());
            }
            LiteMorph.debug("   " + string + ": found match in exceptions -- " + string2 + ", at depth " + n);
            return;
        }
        if (string.indexOf("-") >= 0) {
            return;
        }
        Rule[] arrrule = null;
        int n2 = 0;
        Enumeration<K> enumeration = rulesTable.keys();
        while (enumeration.hasMoreElements()) {
            String string3 = (String)enumeration.nextElement();
            if (!string.endsWith(string3) || string3.equals("default")) continue;
            arrrule = (Rule[])rulesTable.get(string3);
            n2 = string3.length();
            break;
        }
        if (arrrule == null) {
            arrrule = (Rule[])rulesTable.get("default");
            n2 = 0;
        }
        int n3 = 0;
        while (n3 < arrrule.length) {
            LiteMorph.debug("  " + string + ": trying rule: " + arrrule[n3] + ", at depth " + n);
            String[] arrstring = arrrule[n3].match(string, n, n2);
            if (arrstring.length > 0) {
                LiteMorph.debug("  " + string + ": found match for: " + arrrule[n3] + ", at depth " + n);
                this.addVariant(string);
                int n4 = 0;
                while (n4 < arrstring.length) {
                    this.addVariant(arrstring[n4]);
                    ++n4;
                }
                break;
            }
            ++n3;
        }
    }

    private void addVariant(String string) {
        if (blockedVariants.get(string) == null) {
            variants.addElement(string);
            blockedVariants.put(string, string);
        }
    }

    protected static Rule r(String string, String string2, LiteMorph liteMorph) {
        return new Rule(string, string2, liteMorph);
    }

    private static void debug(String string) {
    }
}

