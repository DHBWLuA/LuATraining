/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.search;

interface CompressorIterator {
    public void value(int var1);
}

