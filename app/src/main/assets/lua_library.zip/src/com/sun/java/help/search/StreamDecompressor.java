/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.search;

import com.sun.java.help.search.Decompressor;
import com.sun.java.help.search.IntegerArray;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;

class StreamDecompressor
extends Decompressor {
    private InputStream _input;

    public StreamDecompressor(InputStream inputStream) {
        this.initReading(inputStream);
    }

    public void initReading(InputStream inputStream) {
        this._input = inputStream;
        this.initReading();
    }

    public int getNextByte() throws IOException {
        return this._input.read();
    }

    public static void main(String[] arrstring) {
        try {
            FileInputStream fileInputStream = new FileInputStream(arrstring[0]);
            try {
                int n = fileInputStream.read();
                long l = System.currentTimeMillis();
                System.out.println("k1 = " + n);
                IntegerArray integerArray = new IntegerArray();
                StreamDecompressor streamDecompressor = new StreamDecompressor(fileInputStream);
                try {
                    streamDecompressor.ascDecode(n, integerArray);
                }
                catch (Exception var7_8) {
                    System.err.println(var7_8);
                }
                System.out.println("index1 = " + integerArray.cardinality());
                int n2 = fileInputStream.read();
                System.out.println("k2 = " + n2);
                IntegerArray integerArray2 = new IntegerArray(integerArray.cardinality());
                StreamDecompressor streamDecompressor2 = new StreamDecompressor(fileInputStream);
                try {
                    streamDecompressor2.decode(n2, integerArray2);
                }
                catch (Exception var10_12) {
                    System.err.println(var10_12);
                }
                System.out.println("index2 = " + integerArray2.cardinality());
                System.out.println("" + (System.currentTimeMillis() - l) + " msec");
                fileInputStream.close();
            }
            catch (IOException var2_4) {
                System.err.println(var2_4);
            }
        }
        catch (FileNotFoundException var1_2) {
            System.err.println(var1_2);
        }
    }
}

