/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.impl;

import java.beans.PropertyDescriptor;
import java.beans.SimpleBeanInfo;

public class JHSecondaryViewerBeanInfo
extends SimpleBeanInfo {
    static /* synthetic */ Class class$com$sun$java$help$impl$JHSecondaryViewer;

    public PropertyDescriptor[] getPropertyDescriptors() {
        PropertyDescriptor[] arrpropertyDescriptor = new PropertyDescriptor[15];
        try {
            Class class_ = class$com$sun$java$help$impl$JHSecondaryViewer == null ? (JHSecondaryViewerBeanInfo.class$com$sun$java$help$impl$JHSecondaryViewer = JHSecondaryViewerBeanInfo.class$("com.sun.java.help.impl.JHSecondaryViewer")) : class$com$sun$java$help$impl$JHSecondaryViewer;
            arrpropertyDescriptor[0] = new PropertyDescriptor("content", class_);
            arrpropertyDescriptor[1] = new PropertyDescriptor("id", class$com$sun$java$help$impl$JHSecondaryViewer == null ? (JHSecondaryViewerBeanInfo.class$com$sun$java$help$impl$JHSecondaryViewer = JHSecondaryViewerBeanInfo.class$("com.sun.java.help.impl.JHSecondaryViewer")) : class$com$sun$java$help$impl$JHSecondaryViewer);
            arrpropertyDescriptor[2] = new PropertyDescriptor("viewerName", class$com$sun$java$help$impl$JHSecondaryViewer == null ? (JHSecondaryViewerBeanInfo.class$com$sun$java$help$impl$JHSecondaryViewer = JHSecondaryViewerBeanInfo.class$("com.sun.java.help.impl.JHSecondaryViewer")) : class$com$sun$java$help$impl$JHSecondaryViewer);
            arrpropertyDescriptor[3] = new PropertyDescriptor("viewerActivator", class$com$sun$java$help$impl$JHSecondaryViewer == null ? (JHSecondaryViewerBeanInfo.class$com$sun$java$help$impl$JHSecondaryViewer = JHSecondaryViewerBeanInfo.class$("com.sun.java.help.impl.JHSecondaryViewer")) : class$com$sun$java$help$impl$JHSecondaryViewer);
            arrpropertyDescriptor[4] = new PropertyDescriptor("viewerStyle", class$com$sun$java$help$impl$JHSecondaryViewer == null ? (JHSecondaryViewerBeanInfo.class$com$sun$java$help$impl$JHSecondaryViewer = JHSecondaryViewerBeanInfo.class$("com.sun.java.help.impl.JHSecondaryViewer")) : class$com$sun$java$help$impl$JHSecondaryViewer);
            arrpropertyDescriptor[5] = new PropertyDescriptor("viewerLocation", class$com$sun$java$help$impl$JHSecondaryViewer == null ? (JHSecondaryViewerBeanInfo.class$com$sun$java$help$impl$JHSecondaryViewer = JHSecondaryViewerBeanInfo.class$("com.sun.java.help.impl.JHSecondaryViewer")) : class$com$sun$java$help$impl$JHSecondaryViewer);
            arrpropertyDescriptor[6] = new PropertyDescriptor("viewerSize", class$com$sun$java$help$impl$JHSecondaryViewer == null ? (JHSecondaryViewerBeanInfo.class$com$sun$java$help$impl$JHSecondaryViewer = JHSecondaryViewerBeanInfo.class$("com.sun.java.help.impl.JHSecondaryViewer")) : class$com$sun$java$help$impl$JHSecondaryViewer);
            arrpropertyDescriptor[7] = new PropertyDescriptor("iconByName", class$com$sun$java$help$impl$JHSecondaryViewer == null ? (JHSecondaryViewerBeanInfo.class$com$sun$java$help$impl$JHSecondaryViewer = JHSecondaryViewerBeanInfo.class$("com.sun.java.help.impl.JHSecondaryViewer")) : class$com$sun$java$help$impl$JHSecondaryViewer);
            arrpropertyDescriptor[8] = new PropertyDescriptor("iconByID", class$com$sun$java$help$impl$JHSecondaryViewer == null ? (JHSecondaryViewerBeanInfo.class$com$sun$java$help$impl$JHSecondaryViewer = JHSecondaryViewerBeanInfo.class$("com.sun.java.help.impl.JHSecondaryViewer")) : class$com$sun$java$help$impl$JHSecondaryViewer);
            arrpropertyDescriptor[9] = new PropertyDescriptor("text", class$com$sun$java$help$impl$JHSecondaryViewer == null ? (JHSecondaryViewerBeanInfo.class$com$sun$java$help$impl$JHSecondaryViewer = JHSecondaryViewerBeanInfo.class$("com.sun.java.help.impl.JHSecondaryViewer")) : class$com$sun$java$help$impl$JHSecondaryViewer);
            arrpropertyDescriptor[10] = new PropertyDescriptor("textFontFamily", class$com$sun$java$help$impl$JHSecondaryViewer == null ? (JHSecondaryViewerBeanInfo.class$com$sun$java$help$impl$JHSecondaryViewer = JHSecondaryViewerBeanInfo.class$("com.sun.java.help.impl.JHSecondaryViewer")) : class$com$sun$java$help$impl$JHSecondaryViewer);
            arrpropertyDescriptor[11] = new PropertyDescriptor("textFontSize", class$com$sun$java$help$impl$JHSecondaryViewer == null ? (JHSecondaryViewerBeanInfo.class$com$sun$java$help$impl$JHSecondaryViewer = JHSecondaryViewerBeanInfo.class$("com.sun.java.help.impl.JHSecondaryViewer")) : class$com$sun$java$help$impl$JHSecondaryViewer);
            arrpropertyDescriptor[12] = new PropertyDescriptor("textFontWeight", class$com$sun$java$help$impl$JHSecondaryViewer == null ? (JHSecondaryViewerBeanInfo.class$com$sun$java$help$impl$JHSecondaryViewer = JHSecondaryViewerBeanInfo.class$("com.sun.java.help.impl.JHSecondaryViewer")) : class$com$sun$java$help$impl$JHSecondaryViewer);
            arrpropertyDescriptor[13] = new PropertyDescriptor("textFontStyle", class$com$sun$java$help$impl$JHSecondaryViewer == null ? (JHSecondaryViewerBeanInfo.class$com$sun$java$help$impl$JHSecondaryViewer = JHSecondaryViewerBeanInfo.class$("com.sun.java.help.impl.JHSecondaryViewer")) : class$com$sun$java$help$impl$JHSecondaryViewer);
            arrpropertyDescriptor[14] = new PropertyDescriptor("textColor", class$com$sun$java$help$impl$JHSecondaryViewer == null ? (JHSecondaryViewerBeanInfo.class$com$sun$java$help$impl$JHSecondaryViewer = JHSecondaryViewerBeanInfo.class$("com.sun.java.help.impl.JHSecondaryViewer")) : class$com$sun$java$help$impl$JHSecondaryViewer);
            return arrpropertyDescriptor;
        }
        catch (Exception var2_2) {
            return null;
        }
    }

    static /* synthetic */ Class class$(String string) {
        try {
            return Class.forName(string);
        }
        catch (ClassNotFoundException var1_1) {
            throw new NoClassDefFoundError(var1_1.getMessage());
        }
    }
}

