/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.impl;

import javax.swing.text.View;

public interface ViewAwareComponent {
    public void setViewData(View var1);
}

