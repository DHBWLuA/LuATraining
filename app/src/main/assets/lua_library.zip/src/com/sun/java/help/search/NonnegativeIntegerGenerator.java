/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.search;

interface NonnegativeIntegerGenerator {
    public static final int END = -1;

    public int first() throws Exception;

    public int next() throws Exception;
}

