/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.search;

interface EntryProcessor {
    public void processEntry(String var1, int var2);
}

