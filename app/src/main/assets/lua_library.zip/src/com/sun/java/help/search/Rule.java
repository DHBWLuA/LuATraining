/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.search;

import com.sun.java.help.search.LiteMorph;
import java.util.StringTokenizer;
import java.util.Vector;

public class Rule {
    private String[] pattern;
    private int killnum = 0;
    private String[] expansions;
    private Vector words;
    private LiteMorph morph;
    private static final boolean debugFlag = false;

    public Rule(String string, String string2, LiteMorph liteMorph) {
        Vector<String> vector;
        StringTokenizer stringTokenizer;
        boolean bl = false;
        this.morph = liteMorph;
        if (string.length() > 0) {
            vector = new Vector<String>(string.length());
            stringTokenizer = new StringTokenizer(string, " \t\n\r");
            while (stringTokenizer.hasMoreTokens()) {
                String string3;
                if (bl) {
                    ++this.killnum;
                }
                if ((string3 = stringTokenizer.nextToken()).equals("+")) {
                    bl = true;
                    continue;
                }
                vector.addElement(string3);
            }
            this.pattern = new String[vector.size()];
            vector.copyInto(this.pattern);
        } else {
            this.pattern = new String[0];
        }
        if (string2.length() > 0) {
            vector = new Vector(string2.length());
            stringTokenizer = new StringTokenizer(string2, ", \t\n\r");
            while (stringTokenizer.hasMoreTokens()) {
                vector.addElement(stringTokenizer.nextToken());
            }
            this.expansions = new String[vector.size()];
            vector.copyInto(this.expansions);
        } else {
            this.expansions = new String[0];
        }
    }

    public String[] match(String string, int n, int n2) {
        Object object;
        this.words = new Vector();
        boolean bl = true;
        int n3 = string.length() - 1 - n2;
        int n4 = this.pattern.length - 1 - n2;
        while (n4 > -1) {
            Rule.debug("   trying " + this.pattern[n4] + " at " + n3 + " for i = " + n4);
            if (n3 < 0) {
                bl = false;
                break;
            }
            if (this.pattern[n4].equals("&")) {
                if (n3 < 1 || string.charAt(n3) != string.charAt(n3 - 1)) {
                    bl = false;
                    break;
                }
                --n4;
            } else if (this.pattern[n4].startsWith(".")) {
                if (this.pattern[n4].indexOf(string.charAt(n3), 1) >= 0) {
                    --n4;
                }
            } else {
                if (this.pattern[n4].indexOf(string.charAt(n3)) < 0) {
                    bl = false;
                    break;
                }
                --n4;
            }
            --n3;
        }
        if (bl) {
            object = string.substring(0, string.length() - this.killnum);
            n4 = 0;
            while (n4 < this.expansions.length) {
                this.makeForm((String)object, this.expansions[n4], n);
                ++n4;
            }
        }
        object = new String[this.words.size()];
        this.words.copyInto((Object[])object);
        this.words = null;
        return object;
    }

    private void makeForm(String string, String string2, int n) {
        switch (string2.charAt(0)) {
            case '_': {
                this.words.addElement(string);
                break;
            }
            case '&': {
                this.words.addElement(string + string.charAt(string.length() - 1) + string2.substring(1));
                break;
            }
            case '*': {
                Rule.debug(" starting redo: with " + string + " + " + string2 + " from depth " + n);
                if (string2.charAt(1) == '_') {
                    this.morph.morphWord(string, n + 1);
                    break;
                }
                this.morph.morphWord(string + string2.substring(1), n + 1);
                break;
            }
            default: {
                this.words.addElement(string + string2);
            }
        }
    }

    private static void debug(String string) {
    }
}

