/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.search;

import com.sun.java.help.search.Schema;
import java.net.URL;
import java.util.Hashtable;

public class DBPartParameters {
    protected Schema _schema;
    private String _partName;
    private Hashtable _parameters;

    protected DBPartParameters() {
    }

    public DBPartParameters(Schema schema, String string) {
        this._schema = schema;
        this._partName = string;
        this._parameters = schema.parameters(string);
    }

    protected boolean parametersKnown() {
        return this._parameters != null;
    }

    protected void updateSchema(String string) {
        this._schema.update(this._partName, string);
    }

    public int integerParameter(String string) {
        return Integer.parseInt((String)this._parameters.get(string));
    }

    public URL getURL() throws Exception {
        return this._schema.getURL(this._partName);
    }
}

