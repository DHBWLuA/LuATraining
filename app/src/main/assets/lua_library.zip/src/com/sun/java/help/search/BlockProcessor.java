/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.search;

import com.sun.java.help.search.Block;

interface BlockProcessor {
    public void process(Block var1);
}

