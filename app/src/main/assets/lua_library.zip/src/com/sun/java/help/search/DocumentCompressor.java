/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.search;

import com.sun.java.help.search.Compressor;
import com.sun.java.help.search.ConceptLocation;
import com.sun.java.help.search.IntegerArray;
import com.sun.java.help.search.StreamDecompressor;
import com.sun.java.help.search.Utilities;
import java.io.BufferedInputStream;
import java.io.DataOutput;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.io.RandomAccessFile;
import java.net.URL;
import java.net.URLConnection;

class DocumentCompressor {
    public static final int NConceptsInGroup = 16;
    public static final int BitsInLabel = 4;
    public static final int DefaultSize = 32;
    private int _nGroups;
    private int _nExtents;
    private int _freeComp;
    private int _sizeComp;
    private int _kk;
    private Compressor _currentCompressor;
    private Compressor[] _compressors;
    private Compressor _kCompr;
    private Compressor _lCompr;
    private Compressor _mCompr;
    private Compressor _posCompressor;
    private IntegerArray _kTable;
    private IntegerArray _lTable;
    private IntegerArray _maxConcepts;
    private IntegerArray _concepts;
    private IntegerArray _documents;
    private IntegerArray _offsets;
    private IntegerArray _titles;
    private IntegerArray _positions;
    private IntegerArray _labels;
    private RandomAccessFile _posFile;
    private static boolean debug = false;

    public DocumentCompressor(URL uRL) throws Exception {
        URL uRL2;
        this._sizeComp = 32;
        this._currentCompressor = null;
        this._compressors = new Compressor[32];
        this._kCompr = new Compressor();
        this._lCompr = new Compressor();
        this._mCompr = new Compressor();
        this._posCompressor = new Compressor();
        this._kTable = new IntegerArray();
        this._lTable = new IntegerArray();
        this._maxConcepts = new IntegerArray();
        this._concepts = new IntegerArray();
        this._documents = new IntegerArray();
        this._offsets = new IntegerArray();
        this._titles = new IntegerArray();
        this._positions = new IntegerArray();
        this._labels = new IntegerArray();
        uRL2 = new URL(uRL, "POSITIONS");
        if (this.isFileURL(uRL2)) {
            try {
                URL uRL3 = new URL(uRL, "OFFSETS");
                URLConnection uRLConnection = uRL3.openConnection();
                BufferedInputStream bufferedInputStream = new BufferedInputStream(uRLConnection.getInputStream());
                int n = bufferedInputStream.read();
                StreamDecompressor streamDecompressor = new StreamDecompressor(bufferedInputStream);
                streamDecompressor.ascDecode(n, this._documents);
                int n2 = bufferedInputStream.read();
                StreamDecompressor streamDecompressor2 = new StreamDecompressor(bufferedInputStream);
                streamDecompressor2.ascDecode(n2, this._offsets);
                int n3 = bufferedInputStream.read();
                StreamDecompressor streamDecompressor3 = new StreamDecompressor(bufferedInputStream);
                streamDecompressor3.decode(n3, this._titles);
                bufferedInputStream.close();
            }
            catch (FileNotFoundException var3_4) {
                // empty catch block
            }
        } else {
            throw new IOException();
        }
        this._posFile = new RandomAccessFile(Utilities.URLDecoder(uRL2.getFile()), "rw");
    }

    private boolean isFileURL(URL uRL) {
        return uRL.getProtocol().equalsIgnoreCase("file");
    }

    public void close(String string) throws IOException {
        this._posFile.close();
        this.writeOutOffsets(string);
    }

    public void compress(int n, int n2, ConceptLocation[] arrconceptLocation, int n3, ConceptLocation[] arrconceptLocation2, int n4) throws IOException {
        long l = System.currentTimeMillis();
        this.encode(arrconceptLocation, n3, 16);
        if (n4 > 0) {
            this.encodeExtents(arrconceptLocation2, n4);
        }
        this.finalizeEncoding();
        DocumentCompressor.debug("" + (System.currentTimeMillis() - l) + " msec proc");
        int n5 = this.byteCount();
        l = System.currentTimeMillis();
        long l2 = this._posFile.length();
        this._documents.add(n);
        this._offsets.add((int)l2);
        this._titles.add(n2);
        this._posFile.seek(l2);
        this.writeOut(this._posFile);
        DocumentCompressor.debug("" + (System.currentTimeMillis() - l) + " msec file");
        DocumentCompressor.debug("nGroups = " + this._nGroups);
    }

    private void writeOutOffsets(String string) throws IOException {
        Compressor compressor = new Compressor();
        int n = compressor.compressAscending(this._documents);
        Compressor compressor2 = new Compressor();
        int n2 = compressor2.compressAscending(this._offsets);
        Compressor compressor3 = new Compressor();
        int n3 = compressor3.minimize(this._titles, 8);
        int n4 = compressor.byteCount();
        RandomAccessFile randomAccessFile = new RandomAccessFile(string, "rw");
        randomAccessFile.seek(0);
        randomAccessFile.write(n);
        compressor.write(randomAccessFile);
        randomAccessFile.write(n2);
        compressor2.write(randomAccessFile);
        randomAccessFile.write(n3);
        compressor3.write(randomAccessFile);
        randomAccessFile.close();
    }

    private void encode(ConceptLocation[] arrconceptLocation, int n, int n2) {
        ConceptLocation.sortByConcept(arrconceptLocation, 0, n);
        this.clear();
        int n3 = 0;
        int n4 = 0;
        int n5 = 0;
        int n6 = arrconceptLocation[0].getConcept();
        this.nextCompressor();
        this._concepts.add(n6);
        int n7 = 0;
        do {
            if (n7 < n && arrconceptLocation[n7].getConcept() == n6) {
                arrconceptLocation[n7].setConcept(n3);
                ++n7;
                continue;
            }
            if (n7 == n) {
                if (this._concepts.cardinality() > 0) {
                    ++this._nGroups;
                    this._kTable.add(this._currentCompressor.minimize(this._concepts, 4));
                    break;
                }
                break;
            }
            if (++n3 == n2) {
                ++this._nGroups;
                this._concepts.popLast();
                this._maxConcepts.add(n6 - n5);
                n5 = n6;
                this._kTable.add(this._currentCompressor.minimize(this._concepts, 4));
                this.encodePositions(arrconceptLocation, n4, n7, 4);
                n4 = n7;
                this.nextCompressor();
                this._concepts.clear();
                n3 = 0;
            }
            this._concepts.add(arrconceptLocation[n7].getConcept() - n6);
            n6 = arrconceptLocation[n7].getConcept();
        } while (true);
        this.encodePositions(arrconceptLocation, n4, n7, 4);
    }

    private void encodePositions(ConceptLocation[] arrconceptLocation, int n, int n2, int n3) {
        ConceptLocation.sortByPosition(arrconceptLocation, n, n2);
        this._positions.clear();
        this._labels.clear();
        int n4 = arrconceptLocation[n].getBegin();
        this._positions.add(n4);
        this._labels.add(arrconceptLocation[n].getConcept());
        int n5 = n;
        int n6 = n + 1;
        while (n6 < n2) {
            if (!arrconceptLocation[n5].equals(arrconceptLocation[n6])) {
                n5 = n6;
                this._positions.add(arrconceptLocation[n5].getBegin() - n4);
                n4 = arrconceptLocation[n5].getBegin();
                this._labels.add(arrconceptLocation[n5].getConcept());
            }
            ++n6;
        }
        int n7 = this._posCompressor.minimize(this._positions, 3);
        this._kTable.add(n7);
        this._posCompressor.clear();
        this._posCompressor.encode(this._positions, this._labels, n7, n3);
        this._currentCompressor.concatenate(this._posCompressor);
    }

    private void encodeExtents(ConceptLocation[] arrconceptLocation, int n) {
        int n2 = 0;
        IntegerArray integerArray = new IntegerArray(n);
        IntegerArray integerArray2 = new IntegerArray();
        IntegerArray integerArray3 = new IntegerArray();
        IntegerArray integerArray4 = new IntegerArray();
        this.nextCompressor();
        Compressor compressor = this._currentCompressor;
        int n3 = 0;
        while (n3 < n) {
            if (arrconceptLocation[n3].getConcept() != n2) {
                if (n2 != 0) {
                    ++this._nExtents;
                    this.nextCompressor();
                    integerArray3.add(this._currentCompressor.minimize(integerArray2, 4));
                    integerArray4.add(this._currentCompressor.byteCount());
                }
                integerArray.add(arrconceptLocation[n3].getConcept() - n2);
                n2 = arrconceptLocation[n3].getConcept();
                integerArray2.clear();
                integerArray2.add(arrconceptLocation[n3].getLength());
            } else {
                integerArray2.add(arrconceptLocation[n3].getLength());
            }
            ++n3;
        }
        this.nextCompressor();
        integerArray3.add(this._currentCompressor.minimize(integerArray2, 4));
        integerArray4.add(this._currentCompressor.byteCount());
        Compressor compressor2 = new Compressor();
        integerArray3.add(compressor2.minimize(integerArray4, 4));
        Compressor compressor3 = new Compressor();
        integerArray3.add(compressor3.minimize(integerArray, 4));
        this._kTable.add(compressor.minimize(integerArray3, 4));
        compressor.concatenate(compressor2);
        compressor.concatenate(compressor3);
    }

    private void finalizeEncoding() {
        if (this._nGroups > 1) {
            int n = this._nExtents > 0 ? this._freeComp : this._freeComp - 1;
            int n2 = 0;
            while (n2 < n) {
                this._lTable.add(this._compressors[n2].byteCount());
                ++n2;
            }
            this._kTable.add(this._mCompr.minimize(this._maxConcepts, 3));
            this._kTable.add(this._lCompr.minimize(this._lTable, 3));
            this._kk = this._kCompr.minimize(this._kTable, 3);
            this._kCompr.concatenate(this._lCompr);
            this._kCompr.concatenate(this._mCompr);
        } else if (this._nGroups == 1 && this._nExtents > 0) {
            this._kTable.add(this._compressors[0].byteCount());
            this._kk = this._kCompr.minimize(this._kTable, 3);
        }
        DocumentCompressor.debug("compr: " + this.byteCount() + " bytes");
    }

    private void writeOut(DataOutput dataOutput) throws IOException {
        if (this._nExtents == 0) {
            if (this._nGroups > 1) {
                dataOutput.write(128 | this._kk);
                this._kCompr.write(dataOutput);
                int n = 0;
                while (n < this._freeComp) {
                    this._compressors[n].write(dataOutput);
                    ++n;
                }
            } else {
                dataOutput.write(this._kTable.at(0));
                dataOutput.write(this._kTable.at(1));
                this._compressors[0].write(dataOutput);
            }
        } else {
            dataOutput.write((this._nGroups > 1 ? 192 : 64) | this._kk);
            this._kCompr.write(dataOutput);
            int n = 0;
            while (n < this._freeComp) {
                this._compressors[n].write(dataOutput);
                ++n;
            }
        }
    }

    private Compressor nextCompressor() {
        if (this._freeComp == this._sizeComp) {
            Compressor[] arrcompressor = new Compressor[this._sizeComp *= 2];
            System.arraycopy(this._compressors, 0, arrcompressor, 0, this._freeComp);
            this._compressors = arrcompressor;
        }
        if (this._compressors[this._freeComp] == null) {
            this._compressors[this._freeComp] = new Compressor();
        }
        this._currentCompressor = this._compressors[this._freeComp++];
        return this._currentCompressor;
    }

    private int byteCount() {
        if (this._nGroups == 1 && this._nExtents == 0) {
            return 2 + this._compressors[0].byteCount();
        }
        int n = 1;
        n += this._kCompr.byteCount();
        int n2 = 0;
        while (n2 < this._freeComp) {
            n += this._compressors[n2].byteCount();
            ++n2;
        }
        return n;
    }

    private void clear() {
        this._nGroups = 0;
        this._nExtents = 0;
        this._kTable.clear();
        this._lTable.clear();
        this._concepts.clear();
        this._maxConcepts.clear();
        this._kCompr.clear();
        this._lCompr.clear();
        this._mCompr.clear();
        int n = 0;
        while (n < this._sizeComp) {
            if (this._compressors[n] != null) {
                this._compressors[n].clear();
            }
            ++n;
        }
        this._freeComp = 0;
        this._currentCompressor = null;
    }

    private static void debug(String string) {
        if (debug) {
            System.err.println("DocumentCompressor: " + string);
        }
    }
}

