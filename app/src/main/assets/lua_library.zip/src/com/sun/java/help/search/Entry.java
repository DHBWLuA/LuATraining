/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.search;

class Entry {
    public byte[] key;
    public int id;
    public int block = -1;

    public Entry(byte[] arrby, int n, int n2) {
        this.key = new byte[n + 1];
        System.arraycopy(arrby, 0, this.key, 0, n);
        this.key[n] = 0;
        this.id = n2;
    }

    public byte[] getKey() {
        return this.key;
    }

    public int getID() {
        return this.id;
    }

    public boolean smallerThan(Entry entry) {
        int n = 0;
        while (n < Math.min(this.key.length, entry.key.length)) {
            if (this.key[n] != entry.key[n]) {
                return (this.key[n] & 255) - (entry.key[n] & 255) < 0;
            }
            ++n;
        }
        return false;
    }
}

