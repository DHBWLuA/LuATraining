/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.search;

import com.sun.java.help.search.CompressorIterator;
import com.sun.java.help.search.IntegerArray;

abstract class Decompressor {
    private static final int BitsInByte = 8;
    private static final int NBits = 32;
    private int _readByte;
    private int _toRead = 0;
    private int _path = 0;

    Decompressor() {
    }

    protected abstract int getNextByte() throws Exception;

    protected void initReading() {
        this._toRead = 0;
    }

    private int countZeroes() throws Exception {
        int n = 0;
        do {
            if (this._toRead-- > 0) {
                if ((this._readByte & 1 << this._toRead) != 0) {
                    return n;
                }
                ++n;
                continue;
            }
            this._readByte = this.getNextByte();
            this._toRead = 8;
        } while (true);
    }

    private int read() throws Exception {
        if (this._toRead-- > 0) {
            return this._readByte & 1 << this._toRead;
        }
        this._toRead = 7;
        this._readByte = this.getNextByte();
        return this._readByte & 128;
    }

    public int read(int n) throws Exception {
        int n2 = 8 - this._toRead;
        if (n <= this._toRead) {
            return (this._readByte << n2 & 255) >>> n2 + (this._toRead -= n);
        }
        int n3 = this._toRead > 0 ? (this._readByte << n2 & 255) >>> n2 : 0;
        while ((n -= this._toRead) >= 8) {
            n3 = n3 << 8 | this.getNextByte();
            n -= 8;
        }
        if (n > 0) {
            this._readByte = this.getNextByte();
            this._toRead = 8 - n;
            return n3 << n | this._readByte >>> this._toRead;
        }
        this._toRead = 0;
        return n3;
    }

    public void beginIteration() {
        this._path = 0;
    }

    public boolean readNext(int n, CompressorIterator compressorIterator) throws Exception {
        if (this.read() != 0) {
            compressorIterator.value(this._path | this.read(n));
            return true;
        }
        int n2 = 1;
        do {
            if (this._toRead-- > 0) {
                if ((this._readByte & 1 << this._toRead) != 0) {
                    int n3 = this._path;
                    this._path = (this._path >>> n + n2 << n2 | this.read(n2)) << n;
                    if (this._path != n3) {
                        compressorIterator.value(this._path | this.read(n));
                        return true;
                    }
                    return false;
                }
                ++n2;
                continue;
            }
            this._readByte = this.getNextByte();
            this._toRead = 8;
        } while (true);
    }

    public void decode(int n, IntegerArray integerArray) throws Exception {
        int n2 = 0;
        do {
            if (this.read() != 0) {
                integerArray.add(n2 | this.read(n));
                continue;
            }
            int n3 = this.countZeroes() + 1;
            int n4 = n2;
            if ((n2 = (n2 >>> n + n3 << n3 | this.read(n3)) << n) == n4) break;
            integerArray.add(n2 | this.read(n));
        } while (true);
    }

    public void ascDecode(int n, IntegerArray integerArray) throws Exception {
        int n2 = 0;
        int n3 = 0;
        do {
            if (this.read() != 0) {
                integerArray.add(n3 += n2 | this.read(n));
                continue;
            }
            int n4 = this.countZeroes() + 1;
            int n5 = n2;
            if ((n2 = (n2 >>> n + n4 << n4 | this.read(n4)) << n) == n5) break;
            integerArray.add(n3 += n2 | this.read(n));
        } while (true);
    }

    public int ascendingDecode(int n, int n2, int[] arrn) throws Exception {
        int n3 = 0;
        int n4 = 0;
        block0 : do {
            if (this.read() != 0) {
                arrn[n4++] = n2 += n3 | this.read(n);
                continue;
            }
            int n5 = 0;
            do {
                if (this._toRead-- > 0) {
                    if ((this._readByte & 1 << this._toRead) != 0) {
                        int n6;
                        if ((n6 = (n3 >>> n + ++n5 << n5 | this.read(n5)) << n) != n3) {
                            int n7 = n4++;
                            n3 = n6;
                            arrn[n7] = n2 += n3 | this.read(n);
                            continue block0;
                        }
                        return n4;
                    }
                    ++n5;
                    continue;
                }
                this._readByte = this.getNextByte();
                this._toRead = 8;
            } while (true);
            break;
        } while (true);
    }
}

