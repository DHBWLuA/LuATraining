/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.search;

import com.sun.java.help.search.Location;

class QueryHit {
    private int _doc;
    private int _begin;
    private int _end;
    private double _score;
    private final int[] _concepts;

    public QueryHit(Location location, double d, int n) {
        this._score = d;
        this._doc = location.getDocument();
        this._begin = location.getBegin();
        this._end = location.getEnd();
        this._concepts = new int[n];
    }

    public String toString() {
        return "[doc = " + this._doc + ", " + this._begin + ", " + this._end + ", " + this._score + "]";
    }

    public int getDocument() {
        return this._doc;
    }

    public int getBegin() {
        return this._begin;
    }

    public int getEnd() {
        return this._end;
    }

    public double getScore() {
        return this._score;
    }

    public int[] getArray() {
        return this._concepts;
    }

    public boolean betterThan(QueryHit queryHit) {
        if (this._score < queryHit._score) {
            return true;
        }
        if (this._score > queryHit._score) {
            return false;
        }
        if (this._begin < queryHit._begin) {
            return true;
        }
        if (this._begin > queryHit._begin) {
            return false;
        }
        if (this._end < queryHit._end) {
            return true;
        }
        if (this._end > queryHit._end) {
            return false;
        }
        return false;
    }
}

