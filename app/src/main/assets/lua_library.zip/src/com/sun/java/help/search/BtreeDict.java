/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.search;

import com.sun.java.help.search.Block;
import com.sun.java.help.search.BlockFactory;
import com.sun.java.help.search.BlockManager;
import com.sun.java.help.search.BlockManagerParameters;
import com.sun.java.help.search.BlockProcessor;
import com.sun.java.help.search.BtreeDictParameters;
import com.sun.java.help.search.Schema;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.net.URL;

public class BtreeDict {
    protected static final int ENTHEADERLEN = 6;
    protected static final int BLOCKSIZE = 2048;
    protected static final int DATALEN = 2040;
    protected static final int MaxKeyLength = 255;
    protected static final int lastPtrIndex = 508;
    protected BlockManager blockManager;
    protected int root;
    protected int[] blocks;
    private boolean debug = false;

    protected BtreeDict() {
    }

    public BtreeDict(BtreeDictParameters btreeDictParameters) throws Exception {
        this.init(btreeDictParameters, false, new BlockFactory(){

            public Block makeBlock() {
                return new DictBlock();
            }
        });
        this.blocks = new int[btreeDictParameters.getFreeID()];
        this.setBlocks(this.blocks);
    }

    public int fetch(String string) throws Exception {
        byte[] arrby = string.getBytes("UTF8");
        byte[] arrby2 = new byte[arrby.length + 1];
        System.arraycopy(arrby, 0, arrby2, 0, arrby.length);
        arrby2[arrby.length] = 0;
        return this.find(this.accessBlock(this.root), arrby2);
    }

    public String fetch(int n) throws Exception {
        return this.findID(this.blocks[n], n);
    }

    public void close() throws Exception {
        this.blockManager.close();
    }

    protected void init(BtreeDictParameters btreeDictParameters, boolean bl, BlockFactory blockFactory) throws Exception {
        this.blockManager = new BlockManager(btreeDictParameters, bl, blockFactory);
        this.root = btreeDictParameters.getRootPosition();
    }

    protected void lock(Block block) {
        this.blockManager.lockBlock(block.number);
    }

    protected void unlock(Block block) {
        this.blockManager.unlockBlock(block.number);
    }

    protected DictBlock accessBlock(int n) throws Exception {
        return (DictBlock)this.blockManager.accessBlock(n);
    }

    protected DictBlock child(DictBlock dictBlock, int n) throws Exception {
        return this.accessBlock(dictBlock.getChildIdx(n));
    }

    private String findID(int n, int n2) throws Exception {
        return this.accessBlock(n).findID(n2);
    }

    private int find(DictBlock dictBlock, byte[] arrby, int n) throws Exception {
        return dictBlock.isLeaf ? 0 : this.find(this.child(dictBlock, n), arrby);
    }

    private int find(DictBlock dictBlock, byte[] arrby) throws Exception {
        int n = arrby.length - 1;
        int n2 = dictBlock.firstEntry();
        int n3 = dictBlock.free();
        int n4 = 0;
        int n5 = 0;
        int n6 = 0;
        while (n2 != n3) {
            if (n5 == n4) {
                int n7 = dictBlock.entryKeyLength(n2);
                int n8 = dictBlock.entryKey(n2);
                int n9 = 0;
                while (n9 < n7 && arrby[n4] == dictBlock.data[n8 + n9]) {
                    ++n4;
                    ++n9;
                }
                if (n9 == n7) {
                    if (n4 == n) {
                        return dictBlock.entryID(n2);
                    }
                } else if ((arrby[n4] & 255) < (dictBlock.data[n8 + n9] & 255)) {
                    return this.find(dictBlock, arrby, n6);
                }
            } else if (n5 < n4) {
                return this.find(dictBlock, arrby, n2 == n3 ? dictBlock.numberOfEntries() : n6);
            }
            do {
                n2 = dictBlock.nextEntry(n2);
                ++n6;
            } while (dictBlock.entryCompression(n2) > n4);
            n5 = dictBlock.entryCompression(n2);
        }
        return this.find(dictBlock, arrby, dictBlock.numberOfEntries());
    }

    private void setBlocks(final int[] arrn) throws Exception {
        long l = System.currentTimeMillis();
        this.blockManager.mapBlocks(new BlockProcessor(){

            public void process(Block block) {
                ((DictBlock)block).setBlockNumbers(arrn);
            }
        });
        this.debug("" + (System.currentTimeMillis() - l) + " msec; TMAP");
    }

    private void debug(String string) {
        if (this.debug) {
            System.err.println("BtreeDict: " + string);
        }
    }

    public static void main(String[] arrstring) {
        try {
            Schema schema = new Schema(null, arrstring[0], false);
            BtreeDictParameters btreeDictParameters = new BtreeDictParameters(schema, "TMAP");
            BtreeDict btreeDict = new BtreeDict(btreeDictParameters);
        }
        catch (Exception var1_2) {
            System.err.println(var1_2);
            var1_2.printStackTrace();
        }
    }

    protected class DictBlock
    extends Block {
        public DictBlock() {
            super(2048);
        }

        public int free() {
            return this.free + this.firstEntry();
        }

        public int numberOfEntries() {
            return this.integerAt(0);
        }

        public int nthPointer(int n) {
            return this.integerAt(4 * (n + 1));
        }

        public int getChildIdx(int n) {
            return this.nthPointer(508 - n);
        }

        public int entryKeyLength(int n) {
            return this.data[n] & 255;
        }

        public int entryCompression(int n) {
            return this.data[n + 1] & 255;
        }

        public int entryID(int n) {
            return this.integerAt(n + 2);
        }

        public int entryLength(int n) {
            return 6 + this.entryKeyLength(n);
        }

        public int entryKey(int n) {
            return n + 6;
        }

        public int firstEntry() {
            return 4;
        }

        public int nextEntry(int n) {
            return n + this.entryLength(n);
        }

        public void restoreKeyInBuffer(int n, byte[] arrby) {
            int n2 = this.entryKeyLength(n);
            int n3 = this.entryCompression(n);
            int n4 = this.entryKey(n);
            while (n2-- > 0) {
                arrby[n3++] = this.data[n4++];
            }
        }

        public String restoreKey(int n, byte[] arrby) {
            int n2 = this.entryKeyLength(n);
            int n3 = this.entryCompression(n);
            int n4 = this.entryKey(n);
            while (n2-- > 0) {
                arrby[n3++] = this.data[n4++];
            }
            String string = null;
            try {
                string = new String(arrby, 0, n3, "UTF8");
            }
            catch (UnsupportedEncodingException var7_7) {
                // empty catch block
            }
            return string;
        }

        public String findID(int n) throws Exception {
            byte[] arrby = new byte[255];
            int n2 = this.free();
            int n3 = this.firstEntry();
            while (n3 < n2) {
                if (this.entryID(n3) == n) {
                    return this.restoreKey(n3, arrby);
                }
                this.restoreKeyInBuffer(n3, arrby);
                n3 = this.nextEntry(n3);
            }
            throw new Exception("ID not found in block");
        }

        protected void setBlockNumbers(int[] arrn) {
            int n = this.firstEntry();
            while (n < this.free) {
                arrn[this.entryID((int)n)] = this.number;
                n = this.nextEntry(n);
            }
        }
    }

}

