/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.search;

import java.io.PrintStream;

class ConceptLocation {
    private int _concept;
    private int _begin;
    private int _end;
    private static ConceptLocationSorter _cComp;
    private static ConceptLocationSorter _pComp;

    private ConceptLocation() {
        _cComp = new ConceptSorter();
        _pComp = new PositionSorter();
    }

    public ConceptLocation(int n, int n2, int n3) {
        this._concept = n;
        this._begin = n2;
        this._end = n3;
    }

    public boolean equals(ConceptLocation conceptLocation) {
        return this._concept == conceptLocation._concept && this._begin == conceptLocation._begin && this._end == conceptLocation._end;
    }

    public void setConcept(int n) {
        this._concept = n;
    }

    public int getConcept() {
        return this._concept;
    }

    public int getBegin() {
        return this._begin;
    }

    public int getEnd() {
        return this._end;
    }

    public int getLength() {
        return this._end - this._begin;
    }

    public static void sortByConcept(ConceptLocation[] arrconceptLocation, int n, int n2) {
        _cComp.quicksort(arrconceptLocation, n, n2 - 1);
    }

    public static void sortByPosition(ConceptLocation[] arrconceptLocation, int n, int n2) {
        _pComp.quicksort(arrconceptLocation, n, n2 - 1);
    }

    public void print() {
        System.out.println("" + this._concept + "\t" + this._begin + "\t" + this._end);
    }

    public static void main(String[] arrstring) {
        int n = 30;
        ConceptLocation[] arrconceptLocation = new ConceptLocation[n];
        int n2 = 0;
        while (n2 < n) {
            int n3 = (int)(Math.random() * 1000.0);
            arrconceptLocation[n2] = new ConceptLocation((int)(Math.random() * 1000.0), n3, n3 + (int)(Math.random() * 10.0));
            ++n2;
        }
        int n4 = 0;
        while (n4 < n) {
            arrconceptLocation[n4].print();
            ++n4;
        }
        ConceptLocation.sortByConcept(arrconceptLocation, 0, n);
        System.out.println("----------------------------------");
        int n5 = 0;
        while (n5 < n) {
            arrconceptLocation[n5].print();
            ++n5;
        }
        ConceptLocation.sortByPosition(arrconceptLocation, 0, n);
        System.out.println("----------------------------------");
        int n6 = 0;
        while (n6 < n) {
            arrconceptLocation[n6].print();
            ++n6;
        }
    }

    static {
        new ConceptLocation();
    }

    private class PositionSorter
    extends ConceptLocationSorter {
        private PositionSorter() {
            super();
        }

        public boolean smallerThan(ConceptLocation conceptLocation, ConceptLocation conceptLocation2) {
            return conceptLocation._begin < conceptLocation2._begin || conceptLocation._begin == conceptLocation2._begin && conceptLocation._end < conceptLocation2._end;
        }
    }

    private class ConceptSorter
    extends ConceptLocationSorter {
        private ConceptSorter() {
            super();
        }

        public boolean smallerThan(ConceptLocation conceptLocation, ConceptLocation conceptLocation2) {
            return conceptLocation._concept < conceptLocation2._concept;
        }
    }

    private abstract class ConceptLocationSorter {
        private ConceptLocationSorter() {
        }

        public abstract boolean smallerThan(ConceptLocation var1, ConceptLocation var2);

        private int partition(ConceptLocation[] arrconceptLocation, int n, int n2) {
            ConceptLocation conceptLocation = arrconceptLocation[n];
            int n3 = n - 1;
            int n4 = n2 + 1;
            do {
                if (this.smallerThan(conceptLocation, arrconceptLocation[--n4])) {
                    continue;
                }
                while (this.smallerThan(arrconceptLocation[++n3], conceptLocation)) {
                }
                if (n3 >= n4) break;
                ConceptLocation conceptLocation2 = arrconceptLocation[n3];
                arrconceptLocation[n3] = arrconceptLocation[n4];
                arrconceptLocation[n4] = conceptLocation2;
            } while (true);
            return n4;
        }

        public void quicksort(ConceptLocation[] arrconceptLocation, int n, int n2) {
            if (n < n2) {
                int n3 = this.partition(arrconceptLocation, n, n2);
                this.quicksort(arrconceptLocation, n, n3);
                this.quicksort(arrconceptLocation, n3 + 1, n2);
            }
        }
    }

}

