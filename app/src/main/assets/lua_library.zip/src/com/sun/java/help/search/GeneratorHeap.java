/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.search;

import com.sun.java.help.search.ConceptGroupGenerator;
import com.sun.java.help.search.RoleFiller;

class GeneratorHeap {
    private static final int InitSize = 128;
    private int _heapSize = 0;
    private ConceptGroupGenerator[] _heap = new ConceptGroupGenerator[128];
    private int _size = 128;
    private int _free = 0;

    public void reset() {
        this._free = 0;
    }

    public void addGenerator(ConceptGroupGenerator conceptGroupGenerator) {
        if (this._free == this._size) {
            ConceptGroupGenerator[] arrconceptGroupGenerator = new ConceptGroupGenerator[this._size *= 2];
            System.arraycopy(this._heap, 0, arrconceptGroupGenerator, 0, this._free);
            this._heap = arrconceptGroupGenerator;
        }
        this._heap[this._free++] = conceptGroupGenerator;
    }

    private void buildHeap() {
        int n = this._heapSize / 2;
        while (n >= 0) {
            this.heapify(n);
            --n;
        }
    }

    private void heapify(int n) {
        int n2;
        int n3 = n + 1 << 1;
        int n4 = n3 - 1;
        int n5 = n2 = n4 < this._heapSize && this._heap[n4].position() < this._heap[n].position() ? n4 : n;
        if (n3 < this._heapSize && this._heap[n3].position() < this._heap[n2].position()) {
            n2 = n3;
        }
        if (n2 != n) {
            ConceptGroupGenerator conceptGroupGenerator = this._heap[n2];
            this._heap[n2] = this._heap[n];
            this._heap[n] = conceptGroupGenerator;
            this.heapify(n2);
        }
    }

    public boolean start(RoleFiller[] arrroleFiller) throws Exception {
        this._heapSize = this._free;
        if (this._heapSize > 0) {
            int n = 0;
            while (n < this._free) {
                this._heap[n].next();
                ++n;
            }
            this.buildHeap();
            this._heap[0].generateFillers(arrroleFiller);
            return true;
        }
        return false;
    }

    public boolean next(RoleFiller[] arrroleFiller) throws Exception {
        if (this._heapSize > 0) {
            if (!this._heap[0].next()) {
                if (this._heapSize > 1) {
                    this._heap[0] = this._heap[--this._heapSize];
                } else {
                    this._heapSize = 0;
                    return false;
                }
            }
            this.heapify(0);
            this._heap[0].generateFillers(arrroleFiller);
            return true;
        }
        return false;
    }
}

