/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.search;

import com.sun.java.help.search.BlockManagerParameters;
import com.sun.java.help.search.Schema;
import com.sun.java.help.search.Utilities;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.Reader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.StringTokenizer;

class BtreeDictParameters
extends BlockManagerParameters {
    private int id1;
    private String dirName;
    private static boolean debugFlag = false;

    public BtreeDictParameters(URL uRL, int n, int n2, int n3) {
        super(uRL, n, n2);
        this.id1 = n3;
    }

    public BtreeDictParameters(Schema schema, String string) throws Exception {
        super(schema, string);
    }

    public boolean readState() {
        if (super.readState()) {
            this.setFreeID(this.integerParameter("id1"));
            return true;
        }
        return false;
    }

    public void writeState() {
    }

    public int getFreeID() {
        return this.id1;
    }

    public final void setFreeID(int n) {
        this.id1 = n;
    }

    private void setDirName(String string) {
        this.dirName = string;
    }

    public static BtreeDictParameters create(URL uRL) {
        try {
            URL uRL2 = new URL(uRL, "TMAP");
            BtreeDictParameters btreeDictParameters = null;
            btreeDictParameters.setDirName(uRL.getFile());
            return btreeDictParameters;
        }
        catch (MalformedURLException var1_2) {
            System.out.println("Couldn't create " + uRL + File.separator + "TMAP");
            return null;
        }
    }

    public static BtreeDictParameters read(String string, URL uRL) throws Exception {
        String string2;
        String string3;
        URL uRL2 = null;
        URL uRL3 = null;
        int n = -1;
        int n2 = -1;
        int n3 = -1;
        if (uRL == null) {
            File file = new File(string);
            if (file.exists()) {
                if (File.separatorChar != '/') {
                    string = string.replace(File.separatorChar, '/');
                }
                if (string.lastIndexOf(File.separatorChar) != string.length() - 1) {
                    string = string.concat(File.separator);
                }
                BtreeDictParameters.debug("file:" + string);
                uRL2 = new URL("file", "", string);
            } else {
                uRL2 = new URL(string);
            }
        }
        URL uRL4 = uRL != null ? new URL(uRL, string + "/SCHEMA") : new URL(uRL2, "SCHEMA");
        URLConnection uRLConnection = uRL4.openConnection();
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(uRLConnection.getInputStream()));
        while (!(string3 = bufferedReader.readLine()).startsWith("TMAP")) {
        }
        bufferedReader.close();
        StringTokenizer stringTokenizer = new StringTokenizer(string3, " =");
        stringTokenizer.nextToken();
        while (stringTokenizer.hasMoreTokens()) {
            string2 = stringTokenizer.nextToken();
            if (string2.equals("bs")) {
                n = Integer.parseInt(stringTokenizer.nextToken());
                continue;
            }
            if (string2.equals("rt")) {
                n2 = Integer.parseInt(stringTokenizer.nextToken());
                continue;
            }
            if (!string2.equals("id1")) continue;
            n3 = Integer.parseInt(stringTokenizer.nextToken());
        }
        uRL3 = uRL != null ? new URL(uRL, string + "/TMAP") : new URL(uRL2, "TMAP");
        string2 = null;
        if (uRL == null) {
            string2.setDirName(Utilities.URLDecoder(uRL2.getFile()));
        }
        return string2;
    }

    public void updateSchema() {
        super.updateSchema("id1=" + this.id1 + " id2=1");
    }

    public void write() throws IOException {
        FileWriter fileWriter = new FileWriter(this.dirName + "/SCHEMA");
        fileWriter.write("JavaSearch 1.0\n");
        fileWriter.write("TMAP bs=2048 rt=" + this.root + " fl=-1 id1=" + this.id1 + " id2=1\n");
        fileWriter.close();
    }

    private static void debug(String string) {
        if (debugFlag) {
            System.out.println("BtreeDictParamters: " + string);
        }
    }
}

