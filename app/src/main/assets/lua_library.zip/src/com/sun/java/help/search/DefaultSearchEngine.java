/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.search;

import com.sun.java.help.search.DefaultSearchQuery;
import com.sun.java.help.search.QueryEngine;
import java.net.URL;
import java.security.InvalidParameterException;
import java.util.Hashtable;
import javax.help.search.SearchEngine;
import javax.help.search.SearchQuery;

public class DefaultSearchEngine
extends SearchEngine {
    private String urldata;
    protected QueryEngine qe;
    private static final boolean debugFlag = false;

    public DefaultSearchEngine(URL uRL, Hashtable hashtable) throws InvalidParameterException {
        super(uRL, hashtable);
        DefaultSearchEngine.debug("Loading Search Database");
        DefaultSearchEngine.debug("  base: " + uRL);
        DefaultSearchEngine.debug("  params: " + hashtable);
        try {
            this.urldata = (String)hashtable.get("data");
            this.qe = new QueryEngine(this.urldata, uRL);
        }
        catch (Exception var3_3) {
            throw new InvalidParameterException();
        }
    }

    public SearchQuery createQuery() {
        return new DefaultSearchQuery(this);
    }

    protected QueryEngine getQueryEngine() {
        return this.qe;
    }

    private static void debug(String string) {
    }
}

