/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.search;

import com.sun.java.help.search.MemoryRAFFile;
import com.sun.java.help.search.RAFFile;
import com.sun.java.help.search.TemporaryRAFFile;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLConnection;
import java.security.AccessController;
import java.security.Permission;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;

public final class RAFFileFactoryOn12 {
    private static int BUF_SIZE = 2048;
    private static final boolean debug = false;

    public static RAFFile get(final URLConnection uRLConnection) throws IOException {
        RAFFile rAFFile = null;
        RAFFileFactoryOn12.debug("get on " + uRLConnection);
        final Permission permission = uRLConnection.getPermission();
        int n = uRLConnection.getContentLength();
        try {
            rAFFile = (RAFFile)AccessController.doPrivileged(new PrivilegedExceptionAction(){
                RAFFile back;

                /*
                 * WARNING - Removed try catching itself - possible behaviour change.
                 */
                public Object run() throws IOException {
                    OutputStream outputStream;
                    block8 : {
                        InputStream inputStream = null;
                        outputStream = null;
                        try {
                            File file = File.createTempFile("dict_cache", null);
                            file.deleteOnExit();
                            if (file != null) {
                                inputStream = uRLConnection.getInputStream();
                                outputStream = new FileOutputStream(file);
                                int n = 0;
                                byte[] arrby = new byte[BUF_SIZE];
                                while ((n = inputStream.read(arrby)) != -1) {
                                    outputStream.write(arrby, 0, n);
                                }
                                this.back = new TemporaryRAFFile(file, permission);
                            } else {
                                this.back = new MemoryRAFFile(uRLConnection);
                            }
                            Object var7_6 = null;
                            if (inputStream == null) break block8;
                        }
                        catch (Throwable var6_8) {
                            Object var7_7 = null;
                            if (inputStream != null) {
                                inputStream.close();
                            }
                            if (outputStream != null) {
                                outputStream.close();
                            }
                            throw var6_8;
                        }
                        inputStream.close();
                    }
                    if (outputStream != null) {
                        outputStream.close();
                    }
                    return this.back;
                }
            });
        }
        catch (PrivilegedActionException var4_4) {
            rAFFile = new MemoryRAFFile(uRLConnection);
        }
        catch (SecurityException var5_5) {
            rAFFile = new MemoryRAFFile(uRLConnection);
        }
        return rAFFile;
    }

    private static void debug(String string) {
    }

}

