/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.impl;

public class DocPConst {
    public static final char AMPERSAND = '&';
    public static final char COLON = ':';
    public static final char DQUOTE = '\"';
    public static final char EQUALS = '=';
    public static final char EXCLAIM = '!';
    public static final char HASH = '#';
    public static final char HORIZBAR = '_';
    public static final char LANGLE = '<';
    public static final char MINUS = '-';
    public static final char NEWLINE = '\n';
    public static final char NINE = '9';
    public static final char NULL = '\u0000';
    public static final char QUESTION = '?';
    public static final char RANGLE = '>';
    public static final char RETURN = '\r';
    public static final char QUOTE = '\'';
    public static final char SEMICOLON = ';';
    public static final char SLASH = '/';
    public static final char SPACE = ' ';
    public static final char TAB = '\t';
    public static final char ZERO = '0';
}

