/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.search;

import com.sun.java.help.search.IntegerArray;
import com.sun.java.help.search.LiteMorph;
import com.sun.java.help.search.Search;
import com.sun.java.help.search.SearchEnvironment;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.Reader;
import java.lang.reflect.Method;
import java.net.URL;
import java.text.BreakIterator;
import java.util.Enumeration;
import java.util.Locale;
import java.util.Vector;
import javax.help.HelpUtilities;
import javax.help.search.SearchQuery;

public class QueryEngine {
    private SearchEnvironment _env;
    static /* synthetic */ Class class$com$sun$java$help$search$QueryEngine;

    public QueryEngine(String string, URL uRL) throws Exception {
        this._env = new SearchEnvironment(string, uRL);
    }

    public void processQuery(String string, Locale locale, SearchQuery searchQuery) throws Exception {
        String[] arrstring;
        int n;
        int n2;
        int n3;
        Vector<SearchIds> vector = new Vector<SearchIds>();
        LiteMorph liteMorph = this.getMorphForLocale(locale);
        int n4 = -1;
        try {
            BreakIterator breakIterator = BreakIterator.getWordInstance(locale);
            breakIterator.setText(string);
            int n5 = breakIterator.first();
            n3 = breakIterator.next();
            while (n3 != -1) {
                int n6;
                int n7;
                String string2 = new String(string.substring(n5, n3));
                string2 = string2.trim();
                if ((string2 = string2.toLowerCase(locale)).length() > 1) {
                    ++n4;
                    n7 = this._env.fetch(string2);
                    if (n7 > 0) {
                        vector.addElement(new SearchIds(n4, n7, 0.0));
                    }
                    if (liteMorph != null) {
                        arrstring = liteMorph.variantsOf(string2);
                        n = 0;
                        while (n < arrstring.length) {
                            n6 = this._env.fetch(arrstring[n]);
                            if (n6 > 0) {
                                vector.addElement(new SearchIds(n4, n6, 0.1));
                            }
                            ++n;
                        }
                    }
                } else if (string2.length() == 1 && ((n7 = Character.getType(string2.charAt(0))) == 9 || n7 == 10 || n7 == 2 || n7 == 5 || n7 == 11 || n7 == 3 || n7 == 0 || n7 == 1)) {
                    ++n4;
                    int n8 = this._env.fetch(string2);
                    if (n8 > 0) {
                        vector.addElement(new SearchIds(n4, n8, 0.0));
                    }
                    if (liteMorph != null) {
                        String[] arrstring2 = liteMorph.variantsOf(string2);
                        n6 = 0;
                        while (n6 < arrstring2.length) {
                            n2 = this._env.fetch(arrstring2[n6]);
                            if (n2 > 0) {
                                vector.addElement(new SearchIds(n4, n2, 0.1));
                            }
                            ++n6;
                        }
                    }
                }
                n5 = n3;
                n3 = breakIterator.next();
            }
        }
        catch (Exception var10_10) {
            var10_10.printStackTrace();
        }
        n3 = vector.size();
        Search search = new Search(this._env, n4 + 1);
        arrstring = new String[]();
        n = 0;
        while (n < n3) {
            SearchIds searchIds = (SearchIds)vector.elementAt(n);
            search.addTerm(searchIds.col, searchIds.concept, searchIds.score, 0);
            arrstring.clear();
            this._env.getChildren(searchIds.concept, (IntegerArray)arrstring);
            if (arrstring.cardinality() > 0) {
                n2 = 0;
                while (n2 < arrstring.cardinality()) {
                    search.addTerm(searchIds.col, arrstring.at(n2), searchIds.score + 0.1, 0);
                    this._env.getChildren(arrstring.at(n2), (IntegerArray)arrstring);
                    ++n2;
                }
            }
            ++n;
        }
        search.startSearch(searchQuery);
    }

    private LiteMorph getMorphForLocale(Locale locale) {
        if (locale == null) {
            locale = Locale.ENGLISH;
        }
        Enumeration enumeration = HelpUtilities.getCandidates(locale);
        String string = "com.sun.java.help.search.LiteMorph";
        Class class_ = class$com$sun$java$help$search$QueryEngine == null ? (QueryEngine.class$com$sun$java$help$search$QueryEngine = QueryEngine.class$("com.sun.java.help.search.QueryEngine")) : class$com$sun$java$help$search$QueryEngine;
        ClassLoader classLoader = class_.getClassLoader();
        while (enumeration.hasMoreElements()) {
            String string2 = (String)enumeration.nextElement();
            String string3 = new String(string + string2);
            try {
                Class class_2 = classLoader == null ? Class.forName(string3) : classLoader.loadClass(string3);
                Method method = class_2.getMethod("getMorph", null);
                return (LiteMorph)method.invoke(null, null);
            }
            catch (Exception var7_7) {
                // empty catch block
            }
        }
        return null;
    }

    public static void main(String[] arrstring) {
        try {
            String string;
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in), 1);
            String string2 = new String(arrstring[0]);
            QueryEngine queryEngine = new QueryEngine(string2, null);
            System.out.println("initialized; enter query");
            while (!(string = bufferedReader.readLine()).equals(".")) {
                long l = System.currentTimeMillis();
                queryEngine.processQuery(string, Locale.getDefault(), null);
                System.out.println("" + (System.currentTimeMillis() - l) + " msec search");
                System.out.println("enter next query or . to quit");
            }
        }
        catch (Exception var1_2) {
            var1_2.printStackTrace();
        }
    }

    static /* synthetic */ Class class$(String string) {
        try {
            return Class.forName(string);
        }
        catch (ClassNotFoundException var1_1) {
            throw new NoClassDefFoundError(var1_1.getMessage());
        }
    }

    private class SearchIds {
        public int col;
        public int concept;
        public double score;

        public SearchIds(int n, int n2, double d) {
            this.col = n;
            this.concept = n2;
            this.score = d;
        }

        public String toString() {
            return "col=" + this.col + " concept=" + this.concept + " score=" + this.score;
        }
    }

}

