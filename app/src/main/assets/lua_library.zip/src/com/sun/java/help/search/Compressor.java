/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.search;

import com.sun.java.help.search.BitBuffer;
import com.sun.java.help.search.IntegerArray;
import java.io.DataOutput;
import java.io.IOException;

class Compressor {
    private static final int NBits = 32;
    private static final int BeginK = 5;
    private BitBuffer _buffer = new BitBuffer();

    Compressor() {
    }

    public void write(DataOutput dataOutput) throws IOException {
        this._buffer.write(dataOutput);
    }

    public int byteCount() {
        return this._buffer.byteCount();
    }

    public void clear() {
        this._buffer.clear();
    }

    public void concatenate(Compressor compressor) {
        this._buffer.concatenate(compressor._buffer);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void encode(IntegerArray var1_1, int var2_2) {
        var3_3 = 1 << var2_2;
        var4_4 = 0;
        var5_5 = 0;
        while (var5_5 < var1_1.cardinality()) {
            var6_6 = var1_1.at(var5_5) >>> var2_2;
            var7_7 = var1_1.at(var5_5) % var3_3;
            if (var6_6 == var4_4) ** GOTO lbl15
            var8_8 = var4_4;
            var9_9 = var4_4;
            var10_10 = 0;
            var11_11 = 1;
            if (var6_6 <= var4_4) ** GOTO lbl31
            var12_12 = var4_4;
            ** GOTO lbl24
lbl15: // 1 sources:
            this._buffer.append(var7_7 | var3_3, var2_2 + 1);
            ** GOTO lbl42
lbl-1000: // 1 sources:
            {
                if ((var9_9 & 1) != 0) {
                    var8_8 -= var11_11;
                } else {
                    var12_12 += var11_11;
                }
                var9_9 >>>= 1;
                var11_11 <<= 1;
                ++var10_10;
lbl24: // 2 sources:
                ** while (var12_12 < var6_6)
            }
lbl25: // 1 sources:
            ** GOTO lbl32
lbl-1000: // 1 sources:
            {
                if ((var9_9 & 1) != 0) {
                    var8_8 -= var11_11;
                }
                var9_9 >>>= 1;
                var11_11 <<= 1;
                ++var10_10;
lbl31: // 2 sources:
                ** while (var8_8 > var6_6)
            }
lbl32: // 2 sources:
            if (var10_10 * 2 + 1 + var2_2 <= 32) {
                this._buffer.append((1 << var10_10 | var6_6 - var8_8) << var2_2 | var7_7, var10_10 * 2 + 1 + var2_2);
            } else {
                if (var10_10 * 2 + 1 <= 32) {
                    this._buffer.append(1 << var10_10 | var6_6 - var8_8, var10_10 * 2 + 1);
                } else {
                    this._buffer.append(0, var10_10);
                    this._buffer.append(1 << var10_10 | var6_6 - var8_8, var10_10 + 1);
                }
                this._buffer.append(var7_7, var2_2);
            }
            var4_4 = var6_6;
lbl42: // 2 sources:
            ++var5_5;
        }
        this._buffer.append(2 | var4_4 & true, 3);
        this._buffer.close();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void encode(IntegerArray var1_1, IntegerArray var2_2, int var3_3, int var4_4) {
        var5_5 = 1 << var3_3;
        var6_6 = 0;
        var7_7 = 0;
        while (var7_7 < var1_1.cardinality()) {
            var8_8 = var1_1.at(var7_7) >>> var3_3;
            var9_9 = var1_1.at(var7_7) % var5_5;
            if (var8_8 == var6_6) ** GOTO lbl15
            var10_10 = var6_6;
            var11_11 = var6_6;
            var12_12 = 0;
            var13_13 = 1;
            if (var8_8 <= var6_6) ** GOTO lbl31
            var14_14 = var6_6;
            ** GOTO lbl24
lbl15: // 1 sources:
            this._buffer.append((var9_9 | var5_5) << var4_4 | var2_2.at(var7_7), var3_3 + var4_4 + 1);
            ** GOTO lbl43
lbl-1000: // 1 sources:
            {
                if ((var11_11 & 1) != 0) {
                    var10_10 -= var13_13;
                } else {
                    var14_14 += var13_13;
                }
                var11_11 >>>= 1;
                var13_13 <<= 1;
                ++var12_12;
lbl24: // 2 sources:
                ** while (var14_14 < var8_8)
            }
lbl25: // 1 sources:
            ** GOTO lbl32
lbl-1000: // 1 sources:
            {
                if ((var11_11 & 1) != 0) {
                    var10_10 -= var13_13;
                }
                var11_11 >>>= 1;
                var13_13 <<= 1;
                ++var12_12;
lbl31: // 2 sources:
                ** while (var10_10 > var8_8)
            }
lbl32: // 2 sources:
            if (var12_12 * 2 + 1 + var3_3 <= 32) {
                this._buffer.append((1 << var12_12 | var8_8 - var10_10) << var3_3 | var9_9, var12_12 * 2 + 1 + var3_3);
            } else {
                if (var12_12 * 2 + 1 <= 32) {
                    this._buffer.append(1 << var12_12 | var8_8 - var10_10, var12_12 * 2 + 1);
                } else {
                    this._buffer.append(0, var12_12);
                    this._buffer.append(1 << var12_12 | var8_8 - var10_10, var12_12 + 1);
                }
                this._buffer.append(var9_9, var3_3);
            }
            this._buffer.append(var2_2.at(var7_7), var4_4);
            var6_6 = var8_8;
lbl43: // 2 sources:
            ++var7_7;
        }
        this._buffer.append(2 | var6_6 & true, 3);
        this._buffer.close();
    }

    public int minimize(IntegerArray integerArray, int n) {
        BitBuffer bitBuffer = new BitBuffer();
        int n2 = n;
        this._buffer.clear();
        this.encode(integerArray, n);
        int n3 = this._buffer.bitCount();
        bitBuffer.setFrom(this._buffer);
        this._buffer.clear();
        this.encode(integerArray, n + 1);
        if (this._buffer.bitCount() < n3) {
            int n4 = n + 1;
            do {
                bitBuffer.setFrom(this._buffer);
                n3 = this._buffer.bitCount();
                n2 = n4++;
                this._buffer.clear();
                this.encode(integerArray, n4);
            } while (this._buffer.bitCount() < n3);
        } else {
            int n5 = n - 1;
            while (n5 > 0) {
                this._buffer.clear();
                this.encode(integerArray, n5);
                if (this._buffer.bitCount() >= n3) break;
                bitBuffer.setFrom(this._buffer);
                n3 = this._buffer.bitCount();
                n2 = n5--;
            }
        }
        this._buffer.setFrom(bitBuffer);
        return n2;
    }

    public int compressAscending(IntegerArray integerArray) {
        IntegerArray integerArray2 = new IntegerArray(integerArray.cardinality());
        integerArray.toDifferences(integerArray2);
        return this.minimize(integerArray2, 5);
    }
}

