/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.search;

import com.sun.java.help.search.DBPartParameters;
import com.sun.java.help.search.Schema;
import java.io.PrintStream;
import java.net.URL;

class BlockManagerParameters
extends DBPartParameters {
    private URL url;
    private int blockSize;
    protected int root;
    private boolean debug = false;

    public BlockManagerParameters(Schema schema, String string) throws Exception {
        super(schema, string);
        this.url = schema.getURL(string);
        this.debug(this.url.toString());
    }

    public boolean readState() {
        if (this.parametersKnown()) {
            this.blockSize = this.integerParameter("bs");
            this.root = this.integerParameter("rt");
            return true;
        }
        return false;
    }

    public void updateSchema(String string) {
        super.updateSchema("bs=" + this.blockSize + " rt=" + this.root + " fl=-1 " + string);
    }

    public BlockManagerParameters(URL uRL, int n, int n2) {
        this.url = uRL;
        this.blockSize = n;
        this.root = n2;
    }

    public URL getURL() {
        return this.url;
    }

    public int getBlockSize() {
        return this.blockSize;
    }

    public void setBlockSize(int n) {
        this.blockSize = n;
    }

    public int getRootPosition() {
        return this.root;
    }

    public void setRoot(int n) {
        this.root = n;
    }

    private void debug(String string) {
        if (this.debug) {
            System.err.println("Block Manager Parameters: " + string);
        }
    }
}

