/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.search;

import com.sun.java.help.search.ByteArrayDecompressor;
import com.sun.java.help.search.CompressorIterator;
import com.sun.java.help.search.ConceptData;
import com.sun.java.help.search.Decompressor;
import com.sun.java.help.search.RoleFiller;
import java.io.PrintStream;

class ConceptGroupGenerator
implements CompressorIterator {
    private static final int NConceptsInGroup = 16;
    private static final int BitsInLabel = 4;
    private int _last;
    private ConceptData[] _table;
    private Decompressor _bits;
    private int _k1;
    private final int _k2 = 4;
    private ConceptData _cData;

    public ConceptGroupGenerator() {
        this._k1 = 0;
        this._table = new ConceptData[16];
        this._last = 0;
        this._bits = null;
    }

    public ConceptGroupGenerator(byte[] arrby, int n, int n2) {
        this._k1 = n2;
        this._table = new ConceptData[16];
        this._last = 0;
        this._bits = new ByteArrayDecompressor(arrby, n);
    }

    public void init(byte[] arrby, int n, int n2) {
        this._k1 = n2;
        this._bits = new ByteArrayDecompressor(arrby, n);
        this._last = 0;
        int n3 = 0;
        while (n3 < 16) {
            this._table[n3] = null;
            ++n3;
        }
    }

    public void addTerms(int n, ConceptData conceptData) {
        this._table[n] = conceptData;
    }

    public int decodeConcepts(int n, int n2, int[] arrn) throws Exception {
        return this._bits.ascendingDecode(n, n2, arrn);
    }

    public int position() {
        return this._last;
    }

    public void value(int n) {
        this._last += n;
    }

    boolean next() throws Exception {
        try {
            while (this._bits.readNext(this._k1, this)) {
                this._cData = this._table[this._bits.read(4)];
                if (this._cData == null) continue;
                return true;
            }
            return false;
        }
        catch (Exception var1_1) {
            var1_1.printStackTrace();
            System.err.println(this._bits);
            System.err.println(this._table);
            throw var1_1;
        }
    }

    public void generateFillers(RoleFiller[] arrroleFiller) {
        this._cData.generateFillers(arrroleFiller, this._last);
    }
}

