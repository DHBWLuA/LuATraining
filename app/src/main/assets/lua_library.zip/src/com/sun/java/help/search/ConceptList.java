/*
 * Decompiled with CFR 0_115.
 */
package com.sun.java.help.search;

import com.sun.java.help.search.ByteArrayDecompressor;
import com.sun.java.help.search.CompressorIterator;
import com.sun.java.help.search.NonnegativeIntegerGenerator;

class ConceptList
implements NonnegativeIntegerGenerator,
CompressorIterator {
    private ByteArrayDecompressor _list;
    private byte _k;
    private int _value = 0;

    public ConceptList(byte[] arrby, int n) {
        this._k = arrby[n];
        this._list = new ByteArrayDecompressor(arrby, n + 1);
    }

    public void value(int n) {
        this._value += n;
    }

    public int first() throws Exception {
        this._value = 0;
        return this._list.readNext(this._k, this) ? this._value : -1;
    }

    public int next() throws Exception {
        return this._list.readNext(this._k, this) ? this._value : -1;
    }
}

