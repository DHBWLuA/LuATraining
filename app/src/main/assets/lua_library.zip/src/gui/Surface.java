/*
 * Decompiled with CFR 0_115.
 */
package gui;

import gui.DiaMoreChanges;
import gui.MyTableaux;
import gui.ResolutionPanel;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.PrintStream;
import java.net.URL;
import java.util.ArrayList;
import javax.help.HelpSet;
import javax.help.JHelp;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import logic.CNFConvert;
import logic.CheckCondition;
import logic.Condition;
import logic.ConditionConstr;
import logic.ConvertionMethods;
import logic.Tree;

public class Surface
extends JFrame
implements ActionListener,
MouseListener,
ChangeListener,
KeyListener {
    private static final Character OPEN_BRACKET = Character.valueOf('(');
    private static final Character CLOSED_BRACKET = Character.valueOf(')');
    private static final Character IMPLICIT = Character.valueOf('\u2192');
    private static final Character TRUE = Character.valueOf('\u22a8');
    private static final Character AND = Character.valueOf('\u2227');
    private static final Character NOT = Character.valueOf('\u00ac');
    private static final Character OR = Character.valueOf('\u2228');
    private Container container;
    private JTabbedPane tpMainSurface;
    private JPanel pnlInsertion;
    private JPanel pnlCNF;
    private JPanel pnlCond;
    private JPanel pnlSteerBtn;
    private JPanel pnlMathBtn;
    private JTextArea taLogEx;
    private JTextArea taCNF;
    private JTextArea taConditions;
    private JButton btnConvNegToCNF;
    private JButton btnConvToCond;
    private JButton btnClear;
    private JButton btnCalculate;
    private JButton btnIsNot;
    private JButton btnAnd;
    private JButton btnOr;
    private JButton btnTrue;
    private JButton btnImplicit;
    private JLabel lblCond;
    private String lastFocusOwner;
    private String txtLogEx;
    private String txtCNF;
    private String txtConditions;
    private int lastFocusPosition;
    private Tree tree;
    private String[] conditions;
    private String logEx;
    private JMenuBar menuBar;
    private JMenu helpMenu;
    private JMenuItem helpItem;
    private JMenuItem aboutUsItem;
    private JFrame frame;

    public Surface() {
        this.container = this.getContentPane();
        this.tpMainSurface = new JTabbedPane();
        this.txtLogEx = "The locical expression should be entered here";
        this.taLogEx = new JTextArea(this.txtLogEx, 1, 1);
        this.taLogEx.addMouseListener(this);
        this.taLogEx.addKeyListener(this);
        JScrollPane spLogEx = new JScrollPane(this.taLogEx);
        spLogEx.setPreferredSize(new Dimension(500, 55));
        this.btnConvNegToCNF = new JButton(new String(new char[]{'\u2193'}).concat(" Convert Negation to CNF ").concat(new String(new char[]{'\u2193'})));
        this.btnConvNegToCNF.setActionCommand("Convert Negation to CNF");
        this.btnConvNegToCNF.addActionListener(this);
        this.txtCNF = "The CNF should be entered here";
        this.taCNF = new JTextArea(this.txtCNF);
        this.taCNF.addMouseListener(this);
        this.taCNF.addKeyListener(this);
        JScrollPane spCNF = new JScrollPane(this.taCNF);
        spCNF.setPreferredSize(new Dimension(500, 55));
        this.btnConvToCond = new JButton(new String(new char[]{'\u2193'}).concat(" Convert To Conditions ").concat(new String(new char[]{'\u2193'})));
        this.btnConvToCond.setActionCommand("Convert to Condition");
        this.btnConvToCond.addActionListener(this);
        this.pnlCond = new JPanel();
        this.lblCond = new JLabel("list of condition clauses (can also be entered manually)     ");
        this.txtConditions = "The conditions \nshould be ent-\nered here";
        this.taConditions = new JTextArea(this.txtConditions);
        this.taConditions.addMouseListener(this);
        this.taConditions.addKeyListener(this);
        JScrollPane spCond = new JScrollPane(this.taConditions);
        spCond.setPreferredSize(new Dimension(100, 150));
        this.pnlCond.add(this.lblCond);
        this.pnlCond.add(spCond);
        this.pnlMathBtn = new JPanel();
        this.btnIsNot = new JButton(String.valueOf(new String(new char[]{'\u00ac'})) + " (~)");
        this.btnIsNot.setActionCommand("IsNot");
        this.btnIsNot.addActionListener(this);
        this.btnAnd = new JButton(String.valueOf(new String(new char[]{'\u2227'})) + " (&)");
        this.btnAnd.setActionCommand("And");
        this.btnAnd.addActionListener(this);
        this.btnOr = new JButton(String.valueOf(new String(new char[]{'\u2228'})) + " (v)");
        this.btnOr.setActionCommand("Or");
        this.btnOr.addActionListener(this);
        this.btnTrue = new JButton(String.valueOf(new String(new char[]{'\u22a8'})) + " (=)");
        this.btnTrue.setActionCommand("True");
        this.btnTrue.addActionListener(this);
        this.btnImplicit = new JButton(String.valueOf(new String(new char[]{'\u2192'})) + " (->)");
        this.btnImplicit.setActionCommand("Implicit");
        this.btnImplicit.addActionListener(this);
        this.pnlMathBtn.add(this.btnIsNot);
        this.pnlMathBtn.add(this.btnAnd);
        this.pnlMathBtn.add(this.btnOr);
        this.pnlMathBtn.add(this.btnTrue);
        this.pnlMathBtn.add(this.btnImplicit);
        this.pnlSteerBtn = new JPanel();
        this.btnCalculate = new JButton("Calculate");
        this.btnCalculate.setActionCommand("Calculate");
        this.btnCalculate.addActionListener(this);
        this.btnClear = new JButton("Clear");
        this.btnClear.setActionCommand("Clear");
        this.btnClear.addActionListener(this);
        this.pnlSteerBtn.add(this.btnCalculate);
        this.pnlSteerBtn.add(this.btnClear);
        FlowLayout flInsertion = new FlowLayout();
        flInsertion.setVgap(15);
        this.pnlInsertion = new JPanel(flInsertion);
        this.pnlInsertion.add(spLogEx);
        this.pnlInsertion.add(this.btnConvNegToCNF);
        this.pnlInsertion.add(spCNF);
        this.pnlInsertion.add(this.btnConvToCond);
        this.pnlInsertion.add(this.pnlCond);
        this.pnlInsertion.add(this.pnlMathBtn);
        this.pnlInsertion.add(this.pnlSteerBtn);
        this.tpMainSurface.add("Insertion", this.pnlInsertion);
        this.tpMainSurface.add("Tree", new JPanel());
        this.tpMainSurface.add("Resolution", new JPanel());
        this.tpMainSurface.addChangeListener(this);
        this.container.add(this.tpMainSurface);
        this.menuBar = new JMenuBar();
        this.helpMenu = new JMenu("Help");
        this.helpItem = new JMenuItem("Help");
        this.helpItem.addActionListener(this);
        this.helpItem.setActionCommand("Help");
        this.aboutUsItem = new JMenuItem("About us");
        this.aboutUsItem.addActionListener(this);
        this.aboutUsItem.setActionCommand("AboutUs");
        this.helpMenu.add(this.helpItem);
        this.helpMenu.addSeparator();
        this.helpMenu.add(this.aboutUsItem);
        this.menuBar.add(this.helpMenu);
        this.setJMenuBar(this.menuBar);
        this.setSize(630, 550);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setTitle("ALF");
        this.setDefaultCloseOperation(3);
        this.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ClassLoader cl;
        JHelp helpViewer;
        URL url;
        if (e.getActionCommand() == "AboutUs") {
            helpViewer = null;
            try {
                cl = Surface.class.getClassLoader();
                url = HelpSet.findHelpSet(cl, "HelpSetAU.hs");
                helpViewer = new JHelp(new HelpSet(cl, url));
            }
            catch (Exception ex) {
                System.err.println("API Help Set not found");
            }
            this.frame = new JFrame();
            this.frame.setTitle("About Us");
            this.frame.setSize(420, 320);
            this.frame.getContentPane().add(helpViewer);
            this.frame.setDefaultCloseOperation(2);
            this.frame.setVisible(true);
        }
        if (e.getActionCommand() == "Help") {
            helpViewer = null;
            try {
                cl = Surface.class.getClassLoader();
                url = HelpSet.findHelpSet(cl, "HelpSet.hs");
                helpViewer = new JHelp(new HelpSet(cl, url));
            }
            catch (Exception ex) {
                System.err.println("API Help Set not found");
            }
            this.frame = new JFrame();
            this.frame.setTitle("Help");
            this.frame.setSize(800, 600);
            this.frame.getContentPane().add(helpViewer);
            this.frame.setDefaultCloseOperation(2);
            this.frame.setVisible(true);
        }
        if (e.getActionCommand() == "Convert Negation to CNF") {
            if (this.taLogEx.getText() == this.txtLogEx || this.taLogEx.getText().equals("")) {
                return;
            }
            String finalLogEx = this.adjustLogicalExpression(this.taLogEx.getText());
            if (finalLogEx.equals("error")) {
                return;
            }
            this.taLogEx.setText(finalLogEx);
            this.taCNF.setText(CNFConvert.convertToCNF(this.taLogEx.getText()));
        }
        if (e.getActionCommand() == "Convert to Condition") {
            if (this.taCNF.getText() == this.txtCNF || this.taCNF.getText().equals("")) {
                return;
            }
            String finalCNF = this.adjustCNF(this.taCNF.getText());
            if (finalCNF.equals("error")) {
                return;
            }
            this.taCNF.setText(finalCNF);
            this.conditions = ConvertionMethods.extrConds(this.taCNF.getText());
            String newContent = new String("");
            int i = 0;
            while (i < this.conditions.length) {
                newContent = newContent.concat("{" + this.conditions[i] + "}");
                if (i != this.conditions.length - 1) {
                    newContent = newContent.concat("\n");
                }
                ++i;
            }
            this.taConditions.setText(newContent);
        }
        if (e.getActionCommand() == "IsNot") {
            this.setSign(NOT.charValue());
        }
        if (e.getActionCommand() == "And") {
            this.setSign(AND.charValue());
        }
        if (e.getActionCommand() == "Or") {
            this.setSign(OR.charValue());
        }
        if (e.getActionCommand() == "True") {
            this.setSign(TRUE.charValue());
        }
        if (e.getActionCommand() == "Implicit") {
            this.setSign(IMPLICIT.charValue());
        }
        if (e.getActionCommand() == "Calculate") {
            String relevantChange = "";
            if ((this.taLogEx.getText().equals(this.txtLogEx) || this.taLogEx.getText().equals("")) && (this.taCNF.getText().equals(this.txtCNF) || this.taCNF.getText().equals("")) && (this.taConditions.getText().equals(this.txtConditions) || this.taConditions.getText().equals(""))) {
                JOptionPane.showMessageDialog(this, "No expression entered", "Information", 1);
                return;
            }
            if (!this.taLogEx.getText().equals(this.txtLogEx) && !this.taLogEx.getText().equals("") && !this.taCNF.getText().equals(this.txtCNF) && !this.taCNF.getText().equals("") || !this.taLogEx.getText().equals(this.txtLogEx) && !this.taLogEx.getText().equals("") && !this.taConditions.getText().equals(this.txtConditions) && !this.taConditions.getText().equals("") || !this.taCNF.getText().equals(this.txtCNF) && !this.taCNF.getText().equals("") && !this.taConditions.getText().equals(this.txtConditions) && !this.taConditions.getText().equals("")) {
                relevantChange = new DiaMoreChanges(this).getRelevantChange();
            } else if (!this.taLogEx.getText().equals(this.txtLogEx) && !this.taLogEx.getText().equals("")) {
                relevantChange = "LogEx";
            } else if (!this.taCNF.getText().equals(this.txtCNF) && !this.taCNF.getText().equals("")) {
                relevantChange = "CNF";
            } else if (!this.taConditions.getText().equals(this.txtConditions) && !this.taConditions.getText().equals("")) {
                relevantChange = "Conditions";
            }
            if (relevantChange.equals("LogEx") || relevantChange.equals("CNF")) {
                String finalCNF;
                if (relevantChange.equals("LogEx")) {
                    String finalLogEx = this.adjustLogicalExpression(this.taLogEx.getText());
                    if (finalLogEx.equals("error")) {
                        return;
                    }
                    this.taLogEx.setText(finalLogEx);
                    this.taCNF.setText(CNFConvert.convertToCNF(this.taLogEx.getText()));
                }
                if ((finalCNF = this.adjustCNF(this.taCNF.getText())).equals("error")) {
                    return;
                }
                this.taCNF.setText(finalCNF);
                this.conditions = ConvertionMethods.extrConds(this.taCNF.getText());
                String newContent = new String("");
                int i = 0;
                while (i < this.conditions.length) {
                    newContent = newContent.concat("{" + this.conditions[i] + "}");
                    if (i != this.conditions.length - 1) {
                        newContent = newContent.concat("\n");
                    }
                    ++i;
                }
                this.taConditions.setText(newContent);
            }
            if (relevantChange.equals("Conditions")) {
                String finalCondition = this.adjustConditions(this.taConditions.getText());
                if (finalCondition.equals("error")) {
                    return;
                }
                this.taConditions.setText(finalCondition);
                this.conditions = this.taConditions.getText().split("\n");
                int i = 0;
                while (i < this.conditions.length) {
                    this.conditions[i] = this.conditions[i].replace("{", "");
                    this.conditions[i] = this.conditions[i].replace("}", "");
                    ++i;
                }
            }
            if (relevantChange.equals("LogEx")) {
                this.logEx = "0(" + this.taLogEx.getText() + ")";
                this.tree = new Tree(this.logEx);
            }
            ConditionConstr resolution = new ConditionConstr(this.conditions);
            this.tpMainSurface.setComponentAt(2, ResolutionPanel.createResolutionPanel(resolution.getConditions(), resolution.getExplanations()));
            if (resolution.isTautology()) {
                JOptionPane.showMessageDialog(this, "The entered logical expressions are a tautology", "Tautology", 1);
            } else {
                JOptionPane.showMessageDialog(this, "The entered logical expressions are not a tautology", "No Tautology", 1);
            }
        }
        if (e.getActionCommand() == "Clear") {
            new gui.Surface();
            this.dispose();
        }
    }

    @Override
    public void mouseClicked(MouseEvent me) {
        if (this.taLogEx.isFocusOwner()) {
            this.lastFocusOwner = "taLogEx";
            this.lastFocusPosition = this.taLogEx.getSelectionStart();
        } else if (this.taCNF.isFocusOwner()) {
            this.lastFocusOwner = "taCNF";
            this.lastFocusPosition = this.taCNF.getSelectionStart();
        } else if (this.taConditions.isFocusOwner()) {
            this.lastFocusOwner = "taConditions";
            this.lastFocusPosition = this.taConditions.getSelectionStart();
        }
        if (this.taLogEx.isFocusOwner() && this.taLogEx.getText().equals(this.txtLogEx)) {
            this.taLogEx.setText("");
            this.lastFocusPosition = 0;
        } else if (this.taCNF.isFocusOwner() && this.taCNF.getText().equals(this.txtCNF)) {
            this.taCNF.setText("");
            this.lastFocusPosition = 0;
        } else if (this.taConditions.isFocusOwner() && this.taConditions.getText().equals(this.txtConditions)) {
            this.taConditions.setText("");
            this.lastFocusPosition = 0;
        }
    }

    @Override
    public void mouseEntered(MouseEvent arg0) {
    }

    @Override
    public void mouseExited(MouseEvent arg0) {
    }

    @Override
    public void mousePressed(MouseEvent arg0) {
    }

    @Override
    public void mouseReleased(MouseEvent arg0) {
    }

    @Override
    public void stateChanged(ChangeEvent e) {
        JTabbedPane sourceTabbedPane = (JTabbedPane)e.getSource();
        int index = sourceTabbedPane.getSelectedIndex();
        if (index == 1 && this.logEx != null) {
            this.tree = new Tree(this.logEx);
            this.tpMainSurface.setComponentAt(1, new MyTableaux(this.logEx));
        }
    }

    @Override
    public void keyPressed(KeyEvent arg0) {
    }

    @Override
    public void keyReleased(KeyEvent arg0) {
    }

    @Override
    public void keyTyped(KeyEvent ke) {
        if (this.lastFocusOwner != null) {
            if (this.lastFocusOwner.equals("taLogEx")) {
                this.lastFocusPosition = this.taLogEx.getSelectionStart() + 1;
            } else if (this.lastFocusOwner.equals("taCNF")) {
                this.lastFocusPosition = this.taCNF.getSelectionStart() + 1;
            } else if (this.lastFocusOwner.equals("taConditions")) {
                this.lastFocusPosition = this.taConditions.getSelectionStart() + 1;
            }
        }
        if (this.taLogEx.isFocusOwner()) {
            this.lastFocusOwner = "taLogEx";
        } else if (this.taCNF.isFocusOwner()) {
            this.lastFocusOwner = "taCNF";
            this.taLogEx.setText("");
        } else if (this.taConditions.isFocusOwner()) {
            this.lastFocusOwner = "taConditions";
            this.taCNF.setText("");
            this.taLogEx.setText("");
        }
    }

    public void setSign(char sign) {
        if (this.lastFocusOwner != null && (this.lastFocusOwner.equals("taCNF") || this.lastFocusOwner.equals("taConditions")) && (sign == TRUE.charValue() || sign == IMPLICIT.charValue())) {
            JOptionPane.showMessageDialog(this, "IMPLICIT or TRUE shouldn't be used in a CNF or Condition", "Information", 1);
            return;
        }
        if (this.lastFocusOwner != null && sign != NOT.charValue()) {
            if (this.lastFocusOwner.equals("taLogEx")) {
                this.taLogEx.setText(new StringBuffer(this.taLogEx.getText()).insert(this.lastFocusPosition, " " + sign + " ").toString());
                this.lastFocusPosition += 3;
                this.taLogEx.requestFocus();
                this.taLogEx.setSelectionStart(this.lastFocusPosition);
                this.taLogEx.setSelectionEnd(this.lastFocusPosition);
            } else if (this.lastFocusOwner.equals("taCNF")) {
                this.taCNF.setText(new StringBuffer(this.taCNF.getText()).insert(this.lastFocusPosition, " " + sign + " ").toString());
                this.lastFocusPosition += 3;
                this.taCNF.requestFocus();
                this.taCNF.setSelectionStart(this.lastFocusPosition);
                this.taCNF.setSelectionEnd(this.lastFocusPosition);
            } else if (this.lastFocusOwner.equals("taConditions")) {
                this.taConditions.setText(new StringBuffer(this.taConditions.getText()).insert(this.lastFocusPosition, " " + sign + " ").toString());
                this.lastFocusPosition += 3;
                this.taConditions.requestFocus();
                this.taConditions.setSelectionStart(this.lastFocusPosition);
                this.taConditions.setSelectionEnd(this.lastFocusPosition);
            }
        } else if (this.lastFocusOwner != null && sign == NOT.charValue()) {
            if (this.lastFocusOwner.equals("taLogEx")) {
                this.taLogEx.setText(new StringBuffer(this.taLogEx.getText()).insert(this.lastFocusPosition, sign).toString());
                ++this.lastFocusPosition;
                this.taLogEx.requestFocus();
                this.taLogEx.setSelectionStart(this.lastFocusPosition);
                this.taLogEx.setSelectionEnd(this.lastFocusPosition);
            } else if (this.lastFocusOwner.equals("taCNF")) {
                this.taCNF.setText(new StringBuffer(this.taCNF.getText()).insert(this.lastFocusPosition, sign).toString());
                ++this.lastFocusPosition;
                this.taCNF.requestFocus();
                this.taCNF.setSelectionStart(this.lastFocusPosition);
                this.taCNF.setSelectionEnd(this.lastFocusPosition);
            } else if (this.lastFocusOwner.equals("taConditions")) {
                this.taConditions.setText(new StringBuffer(this.taConditions.getText()).insert(this.lastFocusPosition, sign).toString());
                ++this.lastFocusPosition;
                this.taConditions.requestFocus();
                this.taConditions.setSelectionStart(this.lastFocusPosition);
                this.taConditions.setSelectionEnd(this.lastFocusPosition);
            }
        }
    }

    public String adjustLogicalExpression(String expression) {
        expression = ConvertionMethods.removeWhitespaces(expression);
        int response = CheckCondition.checkLogicalValid(expression = ConvertionMethods.replaceOperators(expression));
        if (response != 0) {
            JOptionPane.showMessageDialog(this, "The logical expression contains a syntactical error", "Error", 0);
            return "error";
        }
        expression = CheckCondition.trim(expression);
        return expression;
    }

    public String adjustCNF(String expression) {
        expression = ConvertionMethods.removeWhitespaces(expression);
        int response = CheckCondition.checkLogicalValid(expression = ConvertionMethods.replaceOperators(expression));
        if (response != 0) {
            JOptionPane.showMessageDialog(this, "The cnf contains a syntactical error", "Error", 0);
            return "error";
        }
        boolean wrongSign = ConvertionMethods.hasWrongSigns(expression);
        if (wrongSign) {
            JOptionPane.showMessageDialog(this, "IMPLICIT or TRUE shouldn't be used in a CNF", "Information", 1);
            return "error";
        }
        boolean isCNF = ConvertionMethods.isCNF(expression = CheckCondition.trim(expression));
        if (!isCNF) {
            JOptionPane.showMessageDialog(this, "The entered expression is not a CNF", "Error", 0);
            return "error";
        }
        return expression;
    }

    public String adjustConditions(String expression) {
        expression = ConvertionMethods.removeWhitespaces(expression);
        expression = ConvertionMethods.replaceOperators(expression);
        boolean hasSyntacticalError = ConvertionMethods.conditionHasSyntacticalError(expression = expression.replace("\n", ""));
        if (hasSyntacticalError) {
            JOptionPane.showMessageDialog(this, "The Condition has to be in the form {A, B}", "Error", 0);
            return "error";
        }
        expression = ConvertionMethods.insertWhitespacesToCondition(expression);
        return expression;
    }
}

