/*
 * Decompiled with CFR 0_115.
 */
package gui;

import java.awt.Component;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;

public class DiaMoreChanges
extends JDialog
implements ActionListener {
    private Container conContainer;
    private JRadioButton rbLogEx;
    private JRadioButton rbCNF;
    private JRadioButton rbConditions;
    private JLabel lblChangesExpl;
    private JLabel lblChangesQu;
    private JButton btnOK;
    private JButton btnAbbrechen;
    private String relevantChange;

    public DiaMoreChanges(JFrame owner) {
        super((Frame)owner, true);
        this.conContainer = this.getContentPane();
        this.conContainer.setLayout(new FlowLayout());
        this.lblChangesExpl = new JLabel("You've inserted more than one Expression.");
        this.lblChangesQu = new JLabel("What is the relevant Expression?");
        this.rbLogEx = new JRadioButton("Logical Expression");
        this.rbCNF = new JRadioButton("CNF");
        this.rbConditions = new JRadioButton("Conditions");
        ButtonGroup bgChanges = new ButtonGroup();
        bgChanges.add(this.rbLogEx);
        bgChanges.add(this.rbCNF);
        bgChanges.add(this.rbConditions);
        this.rbLogEx.setSelected(true);
        this.btnOK = new JButton("OK");
        this.btnOK.setActionCommand("OK");
        this.btnOK.addActionListener(this);
        this.btnAbbrechen = new JButton("Abbrechen");
        this.btnAbbrechen.setActionCommand("Abbrechen");
        this.btnAbbrechen.addActionListener(this);
        this.conContainer.add(this.lblChangesExpl);
        this.conContainer.add(this.lblChangesQu);
        this.conContainer.add(this.rbLogEx);
        this.conContainer.add(this.rbCNF);
        this.conContainer.add(this.rbConditions);
        this.conContainer.add(this.btnOK);
        this.conContainer.add(this.btnAbbrechen);
        this.setSize(300, 150);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setDefaultCloseOperation(2);
        this.setTitle("Relevant Change");
        this.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand() == "OK") {
            if (this.rbLogEx.isSelected()) {
                this.relevantChange = "LogEx";
                this.dispose();
            } else if (this.rbCNF.isSelected()) {
                this.relevantChange = "CNF";
                this.dispose();
            } else if (this.rbConditions.isSelected()) {
                this.relevantChange = "Conditions";
                this.dispose();
            }
        }
        if (e.getActionCommand() == "Abbrechen") {
            this.dispose();
        }
    }

    public String getRelevantChange() {
        return this.relevantChange;
    }
}

