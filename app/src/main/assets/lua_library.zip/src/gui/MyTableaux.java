/*
 * Decompiled with CFR 0_115.
 */
package gui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.LayoutManager;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import logic.Tree;
import logic.TreeObject;

public class MyTableaux
extends JPanel
implements MouseListener,
ActionListener {
    private Dimension area;
    private Vector<Rectangle> boundList;
    private Vector<Rectangle> lineList;
    private Vector<Rectangle> crookedLineListLeft;
    private Vector<Rectangle> crookedLineListRight;
    private Vector<int[]> boundCoordList = new Vector();
    private Vector<String> contentList = new Vector();
    private Vector<Integer> boundIDList = new Vector();
    private JPanel drawingPane;
    private List<TreeObject> myTree = new ArrayList<TreeObject>();
    private List<TreeObject> nodeList = new ArrayList<TreeObject>();
    private List<int[]> coordList = new ArrayList<int[]>();
    private Tree tree;
    private Font font;
    private Rectangle bounds;
    private JScrollPane scroller;
    private JButton toggleButton = new JButton("complete");
    private final int TREE_VERTICAL = 2;
    private final int TREE_NODE = 3;
    private final int TREE_END = 4;
    private boolean expanded = false;
    private String logExpression;

    public MyTableaux(String logEx) {
        this.setLayout(new BorderLayout());
        JPanel buttonPanel = new JPanel(new BorderLayout());
        this.toggleButton.addActionListener(this);
        buttonPanel.add((Component)this.toggleButton, "Center");
        this.area = new Dimension(0, 0);
        this.boundList = new Vector();
        this.lineList = new Vector();
        this.crookedLineListLeft = new Vector();
        this.crookedLineListRight = new Vector();
        this.drawingPane = new DrawingPane();
        this.scroller = new JScrollPane(this.drawingPane);
        this.scroller.setPreferredSize(new Dimension(200, 200));
        this.setOpaque(true);
        this.logExpression = logEx;
        this.tree = new Tree(logEx);
        this.myTree = this.tree.getTree();
        if (!this.expanded) {
            this.drawingPane.addMouseListener(this);
            this.setFirstNode();
        } else {
            this.setWholeTree();
        }
        this.add((Component)buttonPanel, "North");
        this.add((Component)this.scroller, "Center");
    }

    private void setWholeTree() {
        this.tree = new Tree(this.logExpression);
        this.myTree = this.tree.getTree();
        int this_width = 0;
        int this_height = 0;
        int actYpos = 10;
        int actXpos = 0;
        TreeObject myObject = null;
        int frameWidth = this.drawingPane.getWidth();
        boolean changed = false;
        this.font = this.drawingPane.getFont();
        FontMetrics fm = this.drawingPane.getFontMetrics(this.font);
        int listLength = this.myTree.size();
        int nodeListLength = this.nodeList.size();
        int insetsLeft = this.drawingPane.getInsets().left;
        int insetsTop = this.drawingPane.getInsets().top;
        int insetsRight = this.drawingPane.getInsets().right;
        int[] orientation = new int[3];
        String content = null;
        TreeObject successor = null;
        TreeObject successorLeft = null;
        TreeObject successorRight = null;
        int j = 0;
        while (j < listLength) {
            if (this.myTree.get(j).getId() == 1) {
                myObject = this.myTree.get(j);
                this.myTree.remove(j);
                break;
            }
            ++j;
        }
        content = myObject.getContent();
        int stringLength = fm.stringWidth(content);
        actXpos = (frameWidth - insetsLeft - insetsRight - stringLength) / 2;
        actYpos += insetsTop + fm.getHeight();
        while (listLength != 0) {
            content = myObject.getContent();
            orientation = myObject.getSuccessor();
            int orientationSuccessors = this.orientationSuccessors(orientation);
            int sizePrecessor = fm.stringWidth(content);
            switch (orientationSuccessors) {
                case 2: {
                    int i = 0;
                    while (i < listLength) {
                        if (this.myTree.get(i).getId() == myObject.getSuccessor()[1]) {
                            successor = this.myTree.get(i);
                            this.myTree.remove(i);
                            listLength = this.myTree.size();
                            break;
                        }
                        ++i;
                    }
                    int sizeActual = fm.stringWidth(successor.getContent());
                    this.bounds = new Rectangle(actXpos, actYpos - fm.getHeight(), fm.stringWidth(myObject.getContent()), fm.getHeight() + 2);
                    this.boundList.add(this.bounds);
                    this.boundIDList.add(myObject.getId());
                    this.boundCoordList.add(new int[]{actXpos, actYpos});
                    this.contentList.add(myObject.getContent());
                    this.bounds = new Rectangle(actXpos + sizePrecessor / 2, actYpos + 4, 2, actYpos + fm.getHeight());
                    this.lineList.add(this.bounds);
                    actYpos += insetsTop + fm.getHeight() + fm.getHeight();
                    if (sizeActual > sizePrecessor) {
                        actXpos -= (sizeActual - sizePrecessor) / 2;
                    } else if (sizeActual < sizePrecessor) {
                        actXpos += (sizePrecessor - sizeActual) / 2;
                    }
                    this.bounds = new Rectangle(actXpos, actYpos - fm.getHeight(), fm.stringWidth(successor.getContent()), fm.getHeight() + 2);
                    this.boundList.add(this.bounds);
                    this.boundIDList.add(successor.getId());
                    this.boundCoordList.add(new int[]{actXpos, actYpos});
                    this.contentList.add(successor.getContent());
                    this_width = actXpos + fm.stringWidth(successor.getContent());
                    if (this_width > this.area.width) {
                        this.area.width = this_width + 20;
                        changed = true;
                    }
                    if ((this_height = actYpos + fm.getHeight()) > this.area.height) {
                        this.area.height = this_height;
                        changed = true;
                    }
                    if (changed) {
                        this.drawingPane.setPreferredSize(this.area);
                        this.drawingPane.revalidate();
                    }
                    myObject = successor;
                    break;
                }
                case 3: {
                    int i = 0;
                    while (i < listLength) {
                        if (this.myTree.get(i).getId() == myObject.getSuccessor()[0]) {
                            successorLeft = this.myTree.get(i);
                            this.myTree.remove(i);
                            listLength = this.myTree.size();
                            break;
                        }
                        ++i;
                    }
                    this.nodeList.add(myObject);
                    this.coordList.add(new int[]{actXpos, actYpos});
                    if (successorLeft != null) {
                        int tempFirstPointOfLineX = actXpos + fm.stringWidth(myObject.getContent()) / 2;
                        int tempFirstPointOfLineY = actYpos;
                        this.bounds = this.rectangleCrookedLine(tempFirstPointOfLineX, tempFirstPointOfLineY, (actXpos -= 30 + fm.stringWidth(myObject.getContent()) / 2) + fm.stringWidth(successorLeft.getContent()) / 2, (actYpos += insetsTop + 4 * fm.getHeight()) - fm.getHeight(), false);
                        this.crookedLineListLeft.add(this.bounds);
                        this.bounds = new Rectangle(actXpos, actYpos - fm.getHeight(), fm.stringWidth(successorLeft.getContent()), fm.getHeight() + 2);
                        this.drawingPane.scrollRectToVisible(this.bounds);
                        this.boundList.add(this.bounds);
                        this.boundIDList.add(successorLeft.getId());
                        this.boundCoordList.add(new int[]{actXpos, actYpos});
                        this.contentList.add(successorLeft.getContent());
                        this_width = actXpos + fm.stringWidth(successorLeft.getContent());
                        if (this_width > this.area.width) {
                            this.area.width = this_width + 20;
                            changed = true;
                        }
                        if ((this_height = actYpos + fm.getHeight()) > this.area.height) {
                            this.area.height = this_height;
                            changed = true;
                        }
                        if (changed) {
                            this.drawingPane.setPreferredSize(this.area);
                            this.drawingPane.revalidate();
                        }
                    }
                    myObject = successorLeft;
                    break;
                }
                case 4: {
                    int nodeLength = 0;
                    if (this.nodeList.size() > 0) {
                        nodeListLength = this.nodeList.size();
                        int i = 0;
                        while (i < listLength) {
                            if (this.myTree.get(i).getId() == this.nodeList.get(nodeListLength - 1).getSuccessor()[2]) {
                                successorRight = this.myTree.get(i);
                                int j2 = 0;
                                while (j2 < listLength) {
                                    if (this.myTree.get(j2).getId() == this.nodeList.get(nodeListLength - 1).getId()) {
                                        this.myTree.remove(j2);
                                        listLength = this.myTree.size();
                                    }
                                    ++j2;
                                }
                                this.myTree.remove(i);
                                listLength = this.myTree.size();
                                actYpos = this.coordList.get(this.coordList.size() - 1)[1] + 3 * fm.getHeight();
                                nodeLength = fm.stringWidth(this.nodeList.get(nodeListLength - 1).getContent());
                                actXpos = this.coordList.get(this.coordList.size() - 1)[0] + nodeLength + 30;
                                this.coordList.remove(this.coordList.size() - 1);
                                this.nodeList.remove(nodeListLength - 1);
                                break;
                            }
                            ++i;
                        }
                    }
                    this.bounds = this.rectangleCrookedLine(actXpos - nodeLength / 2 - 30, actYpos - 3 * fm.getHeight(), actXpos + fm.stringWidth(successorRight.getContent()) / 2, actYpos, true);
                    this.crookedLineListRight.add(this.bounds);
                    actYpos += insetsTop + fm.getHeight();
                    if (successorRight == null) break;
                    myObject = successorRight;
                    this.bounds = new Rectangle(actXpos, actYpos - fm.getHeight(), fm.stringWidth(successorRight.getContent()), fm.getHeight() + 2);
                    this.drawingPane.scrollRectToVisible(this.bounds);
                    this.boundList.add(this.bounds);
                    this.boundIDList.add(successorRight.getId());
                    this.boundCoordList.add(new int[]{actXpos, actYpos});
                    this.contentList.add(successorRight.getContent());
                    this_width = actXpos + fm.stringWidth(successorRight.getContent());
                    if (this_width > this.area.width) {
                        this.area.width = this_width + 20;
                        changed = true;
                    }
                    if ((this_height = actYpos + fm.getHeight()) > this.area.height) {
                        this.area.height = this_height;
                        changed = true;
                    }
                    if (!changed) break;
                    this.drawingPane.setPreferredSize(this.area);
                    this.drawingPane.revalidate();
                }
            }
        }
        this.drawingPane.repaint();
    }

    private void setFirstNode() {
        int this_height;
        this.tree = new Tree(this.logExpression);
        this.myTree = this.tree.getTree();
        boolean changed = false;
        int listLength = this.myTree.size();
        TreeObject myObject = null;
        int actXpos = 0;
        int actYpos = 10;
        int insetsTop = this.getInsets().top;
        this.font = this.drawingPane.getFont();
        FontMetrics fm = this.drawingPane.getFontMetrics(this.font);
        int j = 0;
        while (j < listLength) {
            if (this.myTree.get(j).getId() == 1) {
                myObject = this.myTree.get(j);
                break;
            }
            ++j;
        }
        actXpos = (790 - this.drawingPane.getInsets().left - this.drawingPane.getInsets().right - fm.stringWidth(myObject.getContent())) / 2;
        this.bounds = new Rectangle(actXpos, (actYpos += insetsTop + fm.getHeight()) - fm.getHeight(), fm.stringWidth(myObject.getContent()), fm.getHeight() + 2);
        this.boundList.add(this.bounds);
        this.boundIDList.add(myObject.getId());
        this.boundCoordList.add(new int[]{actXpos, actYpos});
        this.contentList.add(myObject.getContent());
        this.drawingPane.scrollRectToVisible(this.bounds);
        int this_width = actXpos + fm.stringWidth(myObject.getContent());
        if (this_width > this.area.width) {
            this.area.width = this_width + 20;
            changed = true;
        }
        if ((this_height = actYpos + fm.getHeight()) > this.area.height) {
            this.area.height = this_height;
            changed = true;
        }
        if (changed) {
            this.drawingPane.setPreferredSize(this.area);
            this.drawingPane.revalidate();
        }
        this.drawingPane.repaint();
    }

    @Override
    public void mouseClicked(MouseEvent arg0) {
        TreeObject successorNode = null;
        this.font = this.drawingPane.getFont();
        FontMetrics fm = this.drawingPane.getFontMetrics(this.font);
        boolean changed = false;
        int insetsTop = this.drawingPane.getInsets().top;
        int actXpos = 0;
        int actYpos = 10;
        TreeObject successorLeft = null;
        TreeObject successorRight = null;
        int i = 0;
        block4 : while (i < this.boundList.size()) {
            if (this.boundList.get(i).contains(arg0.getX(), arg0.getY())) {
                int j = 0;
                while (j < this.myTree.size()) {
                    TreeObject startNode = this.myTree.get(j);
                    if (startNode.getId() == this.boundIDList.get(i).intValue()) {
                        int[] successor = startNode.getSuccessor();
                        switch (this.orientationSuccessors(successor)) {
                            case 2: {
                                int this_height;
                                int k = 0;
                                while (k < this.myTree.size()) {
                                    TreeObject directFollowNode = this.myTree.get(k);
                                    if (directFollowNode.getId() == startNode.getSuccessor()[1]) {
                                        successorNode = directFollowNode;
                                        break;
                                    }
                                    ++k;
                                }
                                int sizeActual = fm.stringWidth(successorNode.getContent());
                                actXpos = this.boundCoordList.get(i)[0];
                                actYpos = this.boundCoordList.get(i)[1];
                                int sizePrecessor = fm.stringWidth(this.myTree.get(j).getContent());
                                this.bounds = new Rectangle(actXpos + sizePrecessor / 2, actYpos + 4, 2, actYpos + fm.getHeight());
                                this.lineList.add(this.bounds);
                                this.drawingPane.scrollRectToVisible(this.bounds);
                                actYpos += insetsTop + fm.getHeight() + fm.getHeight();
                                if (sizeActual > sizePrecessor) {
                                    actXpos -= (sizeActual - sizePrecessor) / 2;
                                } else if (sizeActual < sizePrecessor) {
                                    actXpos += (sizePrecessor - sizeActual) / 2;
                                }
                                this.bounds = new Rectangle(actXpos, actYpos - fm.getHeight(), sizeActual, fm.getHeight() + 2);
                                this.boundList.add(this.bounds);
                                this.boundIDList.add(successorNode.getId());
                                this.boundCoordList.add(new int[]{actXpos, actYpos});
                                this.contentList.add(successorNode.getContent());
                                this.drawingPane.scrollRectToVisible(this.bounds);
                                int this_width = actXpos + fm.stringWidth(successorNode.getContent());
                                if (this_width > this.area.width) {
                                    this.area.width = this_width + 20;
                                    changed = true;
                                }
                                if ((this_height = actYpos + fm.getHeight()) > this.area.height) {
                                    this.area.height = this_height;
                                    changed = true;
                                }
                                if (!changed) break block4;
                                this.drawingPane.setPreferredSize(this.area);
                                this.drawingPane.revalidate();
                                break;
                            }
                            case 3: {
                                int this_width;
                                int this_height;
                                actXpos = this.boundCoordList.get(i)[0];
                                actYpos = this.boundCoordList.get(i)[1];
                                int k = 0;
                                while (k < this.myTree.size()) {
                                    if (this.myTree.get(k).getId() == this.myTree.get(j).getSuccessor()[0]) {
                                        successorLeft = this.myTree.get(k);
                                        break;
                                    }
                                    ++k;
                                }
                                k = 0;
                                while (k < this.myTree.size()) {
                                    if (this.myTree.get(k).getId() == this.myTree.get(j).getSuccessor()[2]) {
                                        successorRight = this.myTree.get(k);
                                        break;
                                    }
                                    ++k;
                                }
                                if (successorLeft != null) {
                                    int tempFirstPointOfLineX = actXpos + fm.stringWidth(this.myTree.get(j).getContent()) / 2;
                                    int tempFirstPointOfLineY = actYpos;
                                    this.bounds = this.rectangleCrookedLine(tempFirstPointOfLineX, tempFirstPointOfLineY, (actXpos -= 30 + fm.stringWidth(this.myTree.get(j).getContent()) / 2) + fm.stringWidth(successorLeft.getContent()) / 2, (actYpos += insetsTop + 4 * fm.getHeight()) - fm.getHeight(), false);
                                    this.crookedLineListLeft.add(this.bounds);
                                    this.bounds = new Rectangle(actXpos, actYpos - fm.getHeight(), fm.stringWidth(successorLeft.getContent()), fm.getHeight() + 2);
                                    this.drawingPane.scrollRectToVisible(this.bounds);
                                    this.boundList.add(this.bounds);
                                    this.boundIDList.add(successorLeft.getId());
                                    this.boundCoordList.add(new int[]{actXpos, actYpos});
                                    this.contentList.add(successorLeft.getContent());
                                    this_width = actXpos + fm.stringWidth(successorLeft.getContent());
                                    if (this_width > this.area.width) {
                                        this.area.width = this_width + 20;
                                        changed = true;
                                    }
                                    if ((this_height = actYpos + fm.getHeight()) > this.area.height) {
                                        this.area.height = this_height;
                                        changed = true;
                                    }
                                    if (changed) {
                                        this.drawingPane.setPreferredSize(this.area);
                                        this.drawingPane.revalidate();
                                    }
                                }
                                if (successorRight == null) break block4;
                                actXpos = this.boundCoordList.get(i)[0] + fm.stringWidth(this.myTree.get(j).getContent()) + 30;
                                actYpos = this.boundCoordList.get(i)[1] + 3 * fm.getHeight();
                                this.bounds = this.rectangleCrookedLine(actXpos - fm.stringWidth(this.myTree.get(j).getContent()) / 2 - 30, actYpos - 3 * fm.getHeight(), actXpos + fm.stringWidth(successorRight.getContent()) / 2, actYpos, true);
                                this.crookedLineListRight.add(this.bounds);
                                this.bounds = new Rectangle(actXpos, (actYpos += insetsTop + fm.getHeight()) - fm.getHeight(), fm.stringWidth(successorRight.getContent()), fm.getHeight() + 2);
                                this.drawingPane.scrollRectToVisible(this.bounds);
                                this.boundList.add(this.bounds);
                                this.boundIDList.add(successorRight.getId());
                                this.boundCoordList.add(new int[]{actXpos, actYpos});
                                this.contentList.add(successorRight.getContent());
                                this_width = actXpos + fm.stringWidth(successorRight.getContent());
                                if (this_width > this.area.width) {
                                    this.area.width = this_width + 20;
                                    changed = true;
                                }
                                if ((this_height = actYpos + fm.getHeight()) > this.area.height) {
                                    this.area.height = this_height;
                                    changed = true;
                                }
                                if (!changed) break block4;
                                this.drawingPane.setPreferredSize(this.area);
                                this.drawingPane.revalidate();
                            }
                            default: {
                                break;
                            }
                        }
                        break block4;
                    }
                    ++j;
                }
                break;
            }
            ++i;
        }
        this.drawingPane.repaint();
    }

    private Rectangle rectangleCrookedLine(int x1, int y1, int x2, int y2, boolean direction) {
        Rectangle lineBound = null;
        int xPos = 0;
        int yPos = 0;
        int width = 0;
        int height = 0;
        if (!direction) {
            width = x1 - x2;
            height = y2 - y1;
            xPos = x1 - width;
            yPos = y1;
        } else {
            width = x2 - x1;
            height = y2 - y1;
            xPos = x1;
            yPos = y1;
        }
        lineBound = new Rectangle(xPos, yPos, width, height);
        return lineBound;
    }

    private int orientationSuccessors(int[] successors) {
        if (successors[0] == 0 && successors[1] != 0 && successors[2] == 0) {
            return 2;
        }
        if (successors[0] != 0 && successors[1] == 0 && successors[2] != 0) {
            return 3;
        }
        if (successors[0] == 0 && successors[1] == 0 && successors[2] == 0) {
            return 4;
        }
        return -1;
    }

    @Override
    public void mouseEntered(MouseEvent arg0) {
    }

    @Override
    public void mouseExited(MouseEvent arg0) {
    }

    @Override
    public void mousePressed(MouseEvent arg0) {
    }

    @Override
    public void mouseReleased(MouseEvent arg0) {
    }

    private void clearLists() {
        this.boundCoordList.clear();
        this.boundIDList.clear();
        this.boundList.clear();
        this.lineList.clear();
        this.crookedLineListLeft.clear();
        this.crookedLineListRight.clear();
        this.contentList.clear();
    }

    @Override
    public void actionPerformed(ActionEvent arg0) {
        if (arg0.getSource() == this.toggleButton) {
            if (this.expanded) {
                this.expanded = false;
                this.toggleButton.setText("Complete");
                this.drawingPane.addMouseListener(this);
                this.clearLists();
                this.setFirstNode();
            } else {
                this.toggleButton.setText("Step");
                this.expanded = true;
                this.drawingPane.removeMouseListener(this);
                this.clearLists();
                this.setWholeTree();
            }
        }
    }

    public class DrawingPane
    extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            Rectangle rectLines;
            super.paintComponent(g);
            int i = 0;
            while (i < MyTableaux.this.boundList.size()) {
                Rectangle rectString = (Rectangle)MyTableaux.this.boundList.elementAt(i);
                g.drawString((String)MyTableaux.this.contentList.elementAt(i), ((int[])MyTableaux.this.boundCoordList.get(i))[0], ((int[])MyTableaux.this.boundCoordList.get(i))[1]);
                ++i;
            }
            i = 0;
            while (i < MyTableaux.this.lineList.size()) {
                rectLines = (Rectangle)MyTableaux.this.lineList.elementAt(i);
                g.drawLine(rectLines.x, rectLines.y, rectLines.x, rectLines.y + 10);
                ++i;
            }
            i = 0;
            while (i < MyTableaux.this.crookedLineListLeft.size()) {
                rectLines = (Rectangle)MyTableaux.this.crookedLineListLeft.elementAt(i);
                g.drawLine(rectLines.x + rectLines.width, rectLines.y + 4, rectLines.x, rectLines.y + rectLines.height);
                ++i;
            }
            i = 0;
            while (i < MyTableaux.this.crookedLineListRight.size()) {
                rectLines = (Rectangle)MyTableaux.this.crookedLineListRight.elementAt(i);
                g.drawLine(rectLines.x, rectLines.y + 4, rectLines.x + rectLines.width, rectLines.y + rectLines.height);
                ++i;
            }
        }
    }

}

