/*
 * Decompiled with CFR 0_115.
 */
package gui;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;
import logic.Condition;

public class ResolutionTableModel
extends AbstractTableModel {
    private static final long serialVersionUID = 1;
    private String[] columnNames;
    private String[][] data;

    public ResolutionTableModel(ArrayList<Condition> conds, ArrayList<String> explanations) {
        this.data = new String[conds.size()][3];
        int i = 0;
        while (i < conds.size()) {
            this.data[i][0] = "" + conds.get(i).getId();
            this.data[i][1] = explanations.get(i);
            this.data[i][2] = conds.get(i).exprToString();
            ++i;
        }
        this.columnNames = new String[]{"No.", "Explanation", "Condition"};
    }

    @Override
    public String getColumnName(int col) {
        return this.columnNames[col].toString();
    }

    @Override
    public int getRowCount() {
        return this.data.length;
    }

    @Override
    public int getColumnCount() {
        return this.columnNames.length;
    }

    @Override
    public Object getValueAt(int row, int col) {
        return this.data[row][col];
    }

    @Override
    public boolean isCellEditable(int row, int col) {
        return true;
    }
}

