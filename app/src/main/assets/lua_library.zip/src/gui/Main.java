/*
 * Decompiled with CFR 0_115.
 */
package gui;

import gui.Surface;

public class Main {
    public static void main(String[] args) {
        new gui.Surface();
    }
}

