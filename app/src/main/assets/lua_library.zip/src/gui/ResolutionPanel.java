/*
 * Decompiled with CFR 0_115.
 */
package gui;

import gui.ResolutionTableModel;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.LayoutManager;
import java.util.ArrayList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;
import logic.Condition;

public class ResolutionPanel {
    public static JPanel createResolutionPanel(ArrayList<Condition> conds, ArrayList<String> explanations) {
        GridBagLayout gridBagL = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        JPanel pnlResolution = new JPanel(gridBagL);
        ResolutionTableModel resTableModel = new ResolutionTableModel(conds, explanations){
            private static final long serialVersionUID = 1;

            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable table = new JTable(resTableModel);
        JScrollPane spTable = new JScrollPane(table);
        spTable.setPreferredSize(new Dimension(550, 450));
        table.getColumnModel().getColumn(0).setPreferredWidth(80);
        table.getColumnModel().getColumn(1).setPreferredWidth(270);
        table.getColumnModel().getColumn(2).setPreferredWidth(200);
        table.setFillsViewportHeight(true);
        pnlResolution.add((Component)spTable, c);
        return pnlResolution;
    }

}

