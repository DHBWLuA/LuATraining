/*
 * Decompiled with CFR 0_115.
 */
package logic;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import logic.Condition;

public class ConditionConstr {
    private boolean isTautology = false;
    private int actID = 1;
    private ArrayList<Condition> conditions = new ArrayList();
    private ArrayList<String> explanations = new ArrayList();

    public ConditionConstr(String[] conds) {
        int m = 0;
        while (m < conds.length) {
            conds[m].trim();
            String[] arrayExprs = conds[m].split(", ");
            ArrayList<String> arrayLExprs = new ArrayList<String>();
            int n = 0;
            while (n < arrayExprs.length) {
                arrayLExprs.add(arrayExprs[n]);
                ++n;
            }
            Condition newCond = new Condition(this.actID, arrayLExprs);
            this.explanations.add(" present term");
            ++this.actID;
            this.conditions.add(newCond);
            ++m;
        }
        this.checkTautology();
    }

    public boolean isTautology() {
        return this.isTautology;
    }

    public void setTautology(boolean isTautology) {
        this.isTautology = isTautology;
    }

    public int getActID() {
        return this.actID;
    }

    public void setActID(int actID) {
        this.actID = actID;
    }

    public ArrayList<Condition> getConditions() {
        return this.conditions;
    }

    public void setConditions(ArrayList<Condition> conditions) {
        this.conditions = conditions;
    }

    public ArrayList<String> getExplanations() {
        return this.explanations;
    }

    public void setExplanantions(ArrayList<String> explanations) {
        this.explanations = explanations;
    }

    public void checkTautology() {
        int i = 0;
        while (i < this.conditions.size()) {
            int j = 0;
            while (j < this.conditions.get(i).getCondExprs().size()) {
                ArrayList<Integer> arrayLNoCandidates = this.defCondsWithContrVar(this.conditions.get(i).getCondExprs().get(j), i);
                if (arrayLNoCandidates.size() != 0) {
                    int k = 0;
                    while (k < arrayLNoCandidates.size()) {
                        Condition newCond = this.doResolutionStep(this.conditions.get(i), this.conditions.get(arrayLNoCandidates.get(k) - 1), j);
                        if (this.isPresent(newCond.getCondExprs())) {
                            --this.actID;
                            this.explanations.remove(this.explanations.size() - 1);
                        } else {
                            this.conditions.add(newCond);
                            if (newCond.getCondExprs().size() == 0) {
                                ArrayList<String> arrayLEmptyCond = new ArrayList<String>();
                                arrayLEmptyCond.add("\u2b1c");
                                this.explanations.add(" from " + this.conditions.get(i).getId() + " and " + this.actID);
                                newCond.setCondExprs(arrayLEmptyCond);
                                this.isTautology = true;
                                return;
                            }
                        }
                        ++k;
                    }
                }
                ++j;
            }
            ++i;
        }
    }

    public ArrayList<Integer> defCondsWithContrVar(String var, int iterNo) {
        ArrayList<Integer> candidateConds = new ArrayList<Integer>();
        int i = iterNo + 1;
        while (i < this.conditions.size()) {
            int j = 0;
            while (j < this.conditions.get(i).getCondExprs().size()) {
                if (var.length() == 1) {
                    if (this.conditions.get(i).getCondExprs().get(j).equals("\u00ac" + var)) {
                        candidateConds.add(this.conditions.get(i).getId());
                    }
                } else if (this.conditions.get(i).getCondExprs().get(j).equals(var.substring(1))) {
                    candidateConds.add(this.conditions.get(i).getId());
                }
                ++j;
            }
            ++i;
        }
        return candidateConds;
    }

    public Condition doResolutionStep(Condition actCondIter, Condition condFoundByNo, int exprNo) {
        ArrayList<String> condExprsNewCond = new ArrayList<String>();
        int i = 0;
        while (i < actCondIter.getCondExprs().size()) {
            condExprsNewCond.add(actCondIter.getCondExprs().get(i));
            ++i;
        }
        int j = 0;
        while (j < condFoundByNo.getCondExprs().size()) {
            condExprsNewCond.add(condFoundByNo.getCondExprs().get(j));
            ++j;
        }
        String contVar = new String();
        contVar = ((String)condExprsNewCond.get(exprNo)).length() == 1 ? "\u00ac" + (String)condExprsNewCond.get(exprNo) : ((String)condExprsNewCond.get(exprNo)).substring(1);
        int posContVar = condExprsNewCond.indexOf(contVar);
        condExprsNewCond.remove(exprNo);
        if (posContVar < exprNo) {
            condExprsNewCond.remove(posContVar);
        } else {
            condExprsNewCond.remove(posContVar - 1);
        }
        LinkedHashSet<String> setExprs = new LinkedHashSet<String>();
        int k = 0;
        while (k < condExprsNewCond.size()) {
            setExprs.add((String)condExprsNewCond.get(k));
            ++k;
        }
        ArrayList<String> definiteElements = new ArrayList<String>(setExprs);
        this.explanations.add(" from " + actCondIter.getId() + " and " + condFoundByNo.getId());
        Condition newCond = new Condition(this.actID, definiteElements);
        ++this.actID;
        return newCond;
    }

    public boolean isPresent(ArrayList<String> alNewConditionElements) {
        boolean isPresent = false;
        int i = 0;
        while (i < this.conditions.size()) {
            if (alNewConditionElements.size() == this.conditions.get(i).getCondExprs().size()) {
                int j = 0;
                while (j < this.conditions.get(i).getCondExprs().size()) {
                    boolean hasElement = false;
                    int k = 0;
                    while (k < alNewConditionElements.size()) {
                        if (this.conditions.get(i).getCondExprs().get(j).equals(alNewConditionElements.get(k))) {
                            hasElement = true;
                            break;
                        }
                        ++k;
                    }
                    if (!hasElement) break;
                    if (j == this.conditions.get(i).getCondExprs().size() - 1) {
                        isPresent = true;
                        return isPresent;
                    }
                    ++j;
                }
            }
            ++i;
        }
        return isPresent;
    }
}

