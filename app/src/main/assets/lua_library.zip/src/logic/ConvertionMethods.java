/*
 * Decompiled with CFR 0_115.
 */
package logic;

public class ConvertionMethods {
    private static final Character OPEN_BRACKET = Character.valueOf('(');
    private static final Character CLOSED_BRACKET = Character.valueOf(')');
    private static final Character IMPLICIT = Character.valueOf('\u2192');
    private static final Character AND = Character.valueOf('\u2227');
    private static final Character NOT = Character.valueOf('\u00ac');
    private static final Character OR = Character.valueOf('\u2228');
    private static final Character TRUE = Character.valueOf('\u22a8');

    public static String[] extrConds(String expr) {
        String exprTrim = expr.trim();
        String[] arrayCond = exprTrim.split("\u2227");
        int condQuantity = arrayCond.length;
        int i = 0;
        while (i < condQuantity) {
            arrayCond[i] = arrayCond[i].trim();
            arrayCond[i] = arrayCond[i].replace("(", "");
            arrayCond[i] = arrayCond[i].replace(")", "");
            arrayCond[i] = arrayCond[i].replace(" ", "");
            arrayCond[i] = arrayCond[i].replace("\u2228", ", ");
            ++i;
        }
        return arrayCond;
    }

    public static String replaceOperators(String expressions) {
        expressions = expressions.replace("~", NOT.toString());
        expressions = expressions.replace("&", AND.toString());
        expressions = expressions.replace("=", TRUE.toString());
        expressions = expressions.replace("->", IMPLICIT.toString());
        StringBuffer condition = new StringBuffer(expressions);
        int i = 0;
        while (i < condition.length()) {
            if (condition.charAt(i) == 'v' && (Character.isLetter(condition.charAt(i - 1)) || condition.charAt(i - 1) == CLOSED_BRACKET.charValue())) {
                condition.replace(i, i + 1, OR.toString());
            }
            ++i;
        }
        return condition.toString();
    }

    public static int getBracketCount(String expression) {
        int bracketCount = 0;
        int i = 0;
        while (i < expression.length()) {
            if (expression.charAt(i) == OPEN_BRACKET.charValue()) {
                ++bracketCount;
            } else if (expression.charAt(i) == CLOSED_BRACKET.charValue()) {
                --bracketCount;
            }
            ++i;
        }
        return bracketCount;
    }

    public static boolean hasWrongSigns(String expression) {
        int i = 0;
        while (i < expression.length()) {
            if (expression.charAt(i) == IMPLICIT.charValue() || expression.charAt(i) == TRUE.charValue()) {
                return true;
            }
            ++i;
        }
        return false;
    }

    public static String removeWhitespaces(String condition) {
        StringBuffer sb = new StringBuffer();
        String newCondition = ConvertionMethods.replaceOperators(condition);
        int offset = 0;
        int newConditionLength = newCondition.length();
        while (offset < newConditionLength) {
            char current = newCondition.charAt(offset);
            if (!Character.isWhitespace(current)) {
                sb.append(current);
                ++offset;
                continue;
            }
            ++offset;
        }
        return sb.toString();
    }

    public static boolean isCNF(String expression) {
        boolean isCNF = true;
        StringBuffer cnf = new StringBuffer(expression);
        int bracketCount = 0;
        int i = 0;
        while (i < cnf.length()) {
            if (cnf.charAt(i) == OPEN_BRACKET.charValue()) {
                ++bracketCount;
            } else if (cnf.charAt(i) == CLOSED_BRACKET.charValue()) {
                --bracketCount;
            }
            if (bracketCount > 1) {
                isCNF = false;
                return isCNF;
            }
            if (cnf.charAt(i) == AND.charValue() && bracketCount != 0) {
                isCNF = false;
                return isCNF;
            }
            if (cnf.charAt(i) == OR.charValue() && bracketCount != 1) {
                isCNF = false;
                return isCNF;
            }
            if (cnf.charAt(i) == NOT.charValue() && !Character.isLetter(cnf.charAt(i + 1))) {
                isCNF = false;
                return isCNF;
            }
            if (cnf.charAt(i) == TRUE.charValue() || cnf.charAt(i) == IMPLICIT.charValue()) {
                isCNF = false;
                return isCNF;
            }
            ++i;
        }
        return isCNF;
    }

    public static boolean conditionHasSyntacticalError(String expression) {
        StringBuffer condition = new StringBuffer(expression);
        if (condition.charAt(0) != '{' || condition.charAt(condition.length() - 1) != '}') {
            return true;
        }
        int i = 0;
        while (i < condition.length()) {
            if (condition.charAt(i) == '{' && !Character.isLetter(condition.charAt(i + 1)) && condition.charAt(i + 1) != NOT.charValue()) {
                return true;
            }
            if (condition.charAt(i) == NOT.charValue() && !Character.isLetter(condition.charAt(i + 1))) {
                return true;
            }
            if (Character.isLetter(condition.charAt(i)) && condition.charAt(i + 1) != ',' && condition.charAt(i + 1) != '}') {
                return true;
            }
            if (condition.charAt(i) == ',' && !Character.isLetter(condition.charAt(i + 1)) && condition.charAt(i + 1) != NOT.charValue()) {
                return true;
            }
            if (condition.charAt(i) == '}' && i != condition.length() - 1 && condition.charAt(i + 1) != '{') {
                return true;
            }
            ++i;
        }
        return false;
    }

    public static String insertWhitespacesToCondition(String expression) {
        StringBuffer condition = new StringBuffer(expression);
        int i = 0;
        while (i < condition.length()) {
            if (condition.charAt(i) == ',') {
                condition.insert(i + 1, " ");
            } else if (condition.charAt(i) == '}') {
                condition.insert(i + 1, "\n");
            }
            ++i;
        }
        return condition.toString();
    }
}

