/*
 * Decompiled with CFR 0_115.
 */
package logic;

import java.util.ArrayList;
import java.util.Collection;
import logic.TreeObject;

public class Tree {
    private ArrayList<TreeObject> alTree;
    private int topicalID = 1;
    private ArrayList<Integer> alOpenBranches = new ArrayList();
    private ArrayList<Integer> alFinalOpenBranches;
    private boolean isTautology = false;
    private static final Character IMPLICIT = Character.valueOf('\u2192');
    private static final Character AND = Character.valueOf('\u2227');
    private static final Character NOT = Character.valueOf('\u00ac');
    private static final Character OR = Character.valueOf('\u2228');
    private static final Character TRUE = Character.valueOf('\u22a8');
    private static final Character OPEN_BRACKET = Character.valueOf('(');
    private static final Character CLOSED_BRACKET = Character.valueOf(')');

    public Tree(String expression) {
        this.alOpenBranches.add(0);
        this.alTree = new ArrayList();
        if (!expression.equals("")) {
            this.addTreeObject(expression, "-", "a", 0);
            this.createTree(expression, 1);
            this.copyOpenBranchesToFinal();
            this.addTautologySigns();
            this.insertSuccessors();
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public void createTree(String expression, int superExpressionID) {
        if (expression.length() == 2 || expression.equals("-")) return;
        int topicalSignIndex = this.getPositionOfActualSign(expression);
        String[] subexpressions = this.resolveExpression(topicalSignIndex, expression);
        ArrayList<Integer> newExpressions = this.addTreeObject(subexpressions[0], subexpressions[1], subexpressions[2], superExpressionID);
        if (subexpressions[1].equals("-")) {
            int i = 0;
            while (i < newExpressions.size()) {
                this.createTree(subexpressions[0], newExpressions.get(i));
                ++i;
            }
            return;
        } else {
            int i = 0;
            while (i < newExpressions.size()) {
                this.createTree(subexpressions[0], newExpressions.get(i));
                this.createTree(subexpressions[1], newExpressions.get(i + 1));
                i += 2;
            }
        }
    }

    public ArrayList<Integer> addTreeObject(String firstSubexpression, String secondSubexpression, String type, int superExpressionID) {
        ArrayList<Integer> alNewOpenBranches = new ArrayList<Integer>();
        alNewOpenBranches.addAll(this.alOpenBranches);
        ArrayList<Integer> newExpressionID = new ArrayList<Integer>();
        if (type.equals("a")) {
            int i = 0;
            while (i < this.alOpenBranches.size()) {
                if (this.isInLine(this.alOpenBranches.get(i), superExpressionID)) {
                    this.alTree.add(new TreeObject(this.topicalID, firstSubexpression, this.alOpenBranches.get(i)));
                    this.removeNumberFromAL(alNewOpenBranches, this.alOpenBranches.get(i));
                    newExpressionID.add(this.topicalID);
                    ++this.topicalID;
                    if (!secondSubexpression.equals("-")) {
                        this.alTree.add(new TreeObject(this.topicalID, secondSubexpression, this.topicalID - 1));
                        alNewOpenBranches.add(this.topicalID);
                        newExpressionID.add(this.topicalID);
                        ++this.topicalID;
                    } else {
                        alNewOpenBranches.add(this.topicalID - 1);
                    }
                }
                ++i;
            }
        } else {
            int i = 0;
            while (i < this.alOpenBranches.size()) {
                if (this.isInLine(this.alOpenBranches.get(i), superExpressionID)) {
                    this.alTree.add(new TreeObject(this.topicalID, firstSubexpression, this.alOpenBranches.get(i)));
                    alNewOpenBranches.add(this.topicalID);
                    this.removeNumberFromAL(alNewOpenBranches, this.alOpenBranches.get(i));
                    newExpressionID.add(this.topicalID);
                    ++this.topicalID;
                    if (!secondSubexpression.equals("-")) {
                        this.alTree.add(new TreeObject(this.topicalID, secondSubexpression, this.alOpenBranches.get(i)));
                        alNewOpenBranches.add(this.topicalID);
                        newExpressionID.add(this.topicalID);
                        ++this.topicalID;
                    }
                }
                ++i;
            }
        }
        this.alOpenBranches = alNewOpenBranches;
        return newExpressionID;
    }

    public int getPositionOfActualSign(String expression) {
        int bracketSign = 0;
        int topicalSignIndex = 0;
        char actualSign = 'a';
        if (expression.charAt(1) == NOT.charValue()) {
            return 1;
        }
        int i = 0;
        while (i < expression.length()) {
            if (expression.charAt(i) == '(') {
                ++bracketSign;
            } else if (expression.charAt(i) == ')') {
                --bracketSign;
            } else if ((expression.charAt(i) == NOT.charValue() || expression.charAt(i) == AND.charValue() || expression.charAt(i) == OR.charValue() || expression.charAt(i) == IMPLICIT.charValue() || expression.charAt(i) == TRUE.charValue()) && bracketSign == 1) {
                if (!(expression.charAt(i) != IMPLICIT.charValue() && expression.charAt(i) != TRUE.charValue() || actualSign == IMPLICIT.charValue() && actualSign == TRUE.charValue())) {
                    actualSign = expression.charAt(i);
                    topicalSignIndex = i;
                } else if (expression.charAt(i) == OR.charValue() && actualSign != OR.charValue() && actualSign != IMPLICIT.charValue() && actualSign != TRUE.charValue()) {
                    actualSign = expression.charAt(i);
                    topicalSignIndex = i;
                } else if (expression.charAt(i) == AND.charValue() && actualSign != AND.charValue() && actualSign != OR.charValue() && actualSign != IMPLICIT.charValue() && actualSign != TRUE.charValue()) {
                    actualSign = expression.charAt(i);
                    topicalSignIndex = i;
                } else if (expression.charAt(i) == NOT.charValue() && actualSign != AND.charValue() && actualSign != OR.charValue() && actualSign != IMPLICIT.charValue() && actualSign != TRUE.charValue()) {
                    actualSign = NOT.charValue();
                    topicalSignIndex = i;
                }
            }
            ++i;
        }
        return topicalSignIndex;
    }

    public String[] resolveExpression(int topicalSignIndex, String expression) {
        String leftSubexpression;
        String rightSubexpression;
        String[] signs = this.defineTypePrefix(expression.charAt(0), expression.charAt(topicalSignIndex));
        if (expression.charAt(topicalSignIndex) != NOT.charValue()) {
            String leftPart = expression.substring(2, topicalSignIndex - 1);
            String rightPart = expression.substring(topicalSignIndex + 2, expression.length() - 1);
            leftSubexpression = this.hasOuterBrackets(leftPart) ? signs[1].concat(leftPart) : signs[1].concat("(" + leftPart + ")");
            rightSubexpression = this.hasOuterBrackets(rightPart) ? signs[2].concat(rightPart) : signs[2].concat("(" + rightPart + ")");
        } else {
            leftSubexpression = Character.isLetter(expression.charAt(2)) ? signs[1].concat(Character.toString(expression.charAt(2))) : (expression.charAt(topicalSignIndex - 1) != '(' ? signs[1].concat(expression.substring(topicalSignIndex + 1, expression.length())) : signs[1].concat(expression.substring(topicalSignIndex + 1, expression.length() - 1)));
            rightSubexpression = "-";
        }
        if (leftSubexpression.length() != 2 && leftSubexpression.length() != 3 && !leftSubexpression.equals("-") && leftSubexpression.charAt(1) != '(') {
            leftSubexpression = Character.toString(leftSubexpression.charAt(0)).concat("(").concat(leftSubexpression.substring(1));
            leftSubexpression = leftSubexpression.concat(")");
        }
        if (rightSubexpression.length() != 2 && rightSubexpression.length() != 3 && !rightSubexpression.equals("-") && rightSubexpression.charAt(1) != '(') {
            rightSubexpression = Character.toString(rightSubexpression.charAt(0)).concat("(").concat(rightSubexpression.substring(1));
            rightSubexpression = rightSubexpression.concat(")");
        }
        return new String[]{leftSubexpression, rightSubexpression, signs[0]};
    }

    public String[] defineTypePrefix(char prefix, char actualSign) {
        if (prefix == '0') {
            if (actualSign == NOT.charValue()) {
                return new String[]{"a", "1", "-"};
            }
            if (actualSign == OR.charValue()) {
                return new String[]{"a", "0", "0"};
            }
            if (actualSign == IMPLICIT.charValue() || actualSign == TRUE.charValue()) {
                return new String[]{"a", "1", "0"};
            }
            if (actualSign == AND.charValue()) {
                return new String[]{"b", "0", "0"};
            }
        } else if (prefix == '1') {
            if (actualSign == NOT.charValue()) {
                return new String[]{"a", "0", "-"};
            }
            if (actualSign == AND.charValue()) {
                return new String[]{"a", "1", "1"};
            }
            if (actualSign == OR.charValue()) {
                return new String[]{"b", "1", "1"};
            }
            if (actualSign == IMPLICIT.charValue() || actualSign == TRUE.charValue()) {
                return new String[]{"b", "0", "1"};
            }
        }
        return new String[]{"z", "-", "-"};
    }

    public boolean isInLine(int freeBranch, int superID) {
        boolean isInLine = false;
        if (freeBranch == superID) {
            isInLine = true;
        } else {
            int newFreeBranch = this.alTree.get(freeBranch - 1).getPredecessor();
            if (newFreeBranch != 0) {
                isInLine = this.isInLine(newFreeBranch, superID);
            }
        }
        return isInLine;
    }

    public void removeNumberFromAL(ArrayList<Integer> alIntegerList, Integer number) {
        int i = 0;
        while (i < alIntegerList.size()) {
            if (alIntegerList.get(i) == number) {
                alIntegerList.remove(i);
                return;
            }
            ++i;
        }
    }

    public void insertSuccessors() {
        int i = 0;
        while (i < this.alTree.size()) {
            int counter = 0;
            int[] successors = new int[2];
            int j = i;
            while (j < this.alTree.size()) {
                if (this.alTree.get(i).getId() == this.alTree.get(j).getPredecessor()) {
                    if (++counter == 1) {
                        successors[0] = this.alTree.get(j).getId();
                    } else if (counter == 2) {
                        successors[1] = this.alTree.get(j).getId();
                        break;
                    }
                }
                ++j;
            }
            if (counter == 1) {
                this.alTree.get(i).setSingleSuccessor(successors[0]);
            } else {
                this.alTree.get(i).setDualSuccessor(successors[0], successors[1]);
            }
            ++i;
        }
    }

    public void addTautologySigns() {
        int i = 0;
        while (i < this.alFinalOpenBranches.size()) {
            ArrayList<String> expressionLine = new ArrayList<String>();
            this.getExpressionLine(this.alFinalOpenBranches.get(i), expressionLine);
            boolean isConflict = this.isConflict(expressionLine);
            if (isConflict) {
                this.addTreeObject("*", "-", "a", this.alFinalOpenBranches.get(i));
                this.isTautology = true;
            } else {
                this.addTreeObject("", "-", "a", this.alFinalOpenBranches.get(i));
            }
            ++i;
        }
    }

    public ArrayList<String> getExpressionLine(int topicalID, ArrayList<String> expressionLine) {
        if (this.alTree.get(topicalID - 1).getContent().length() == 2) {
            expressionLine.add(this.alTree.get(topicalID - 1).getContent());
        }
        if (this.alTree.get(topicalID - 1).getPredecessor() != 0) {
            this.getExpressionLine(this.alTree.get(topicalID - 1).getPredecessor(), expressionLine);
        }
        return expressionLine;
    }

    public boolean isConflict(ArrayList<String> expressionLine) {
        boolean isConflict = false;
        int i = 0;
        while (i < expressionLine.size()) {
            String topicalExpression = expressionLine.get(i);
            int j = i + 1;
            while (j < expressionLine.size()) {
                String expressionToCompare = expressionLine.get(j);
                if (topicalExpression.charAt(1) == expressionToCompare.charAt(1) && topicalExpression.charAt(0) != expressionToCompare.charAt(0)) {
                    isConflict = true;
                    return isConflict;
                }
                ++j;
            }
            ++i;
        }
        return isConflict;
    }

    public void copyOpenBranchesToFinal() {
        this.alFinalOpenBranches = new ArrayList();
        int i = 0;
        while (i < this.alOpenBranches.size()) {
            this.alFinalOpenBranches.add(this.alOpenBranches.get(i));
            ++i;
        }
    }

    public ArrayList<TreeObject> getTree() {
        return this.alTree;
    }

    public boolean isTautology() {
        return this.isTautology;
    }

    public boolean hasOuterBrackets(String expression) {
        int bracketCount = 0;
        int i = 0;
        while (i < expression.length()) {
            if (expression.charAt(i) == OPEN_BRACKET.charValue()) {
                ++bracketCount;
            } else if (expression.charAt(i) == CLOSED_BRACKET.charValue()) {
                --bracketCount;
            }
            if (bracketCount == 0 && i != expression.length() - 1) {
                return false;
            }
            ++i;
        }
        return true;
    }
}

