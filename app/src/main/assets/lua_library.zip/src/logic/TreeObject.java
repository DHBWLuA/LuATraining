/*
 * Decompiled with CFR 0_115.
 */
package logic;

public class TreeObject {
    private int id;
    private String content;
    private int predecessor;
    private int[] successor;

    public TreeObject(int id, String content, int predecessor) {
        this.id = id;
        this.content = content;
        this.predecessor = predecessor;
    }

    public int getId() {
        return this.id;
    }

    public String getContent() {
        return this.content;
    }

    public int getPredecessor() {
        return this.predecessor;
    }

    public int[] getSuccessor() {
        return this.successor;
    }

    public String toString() {
        return this.content;
    }

    public void setSingleSuccessor(int singleSuccessor) {
        int[] arrn = new int[3];
        arrn[1] = singleSuccessor;
        this.successor = arrn;
    }

    public void setDualSuccessor(int leftSuccessor, int rightSuccessor) {
        int[] arrn = new int[3];
        arrn[0] = leftSuccessor;
        arrn[2] = rightSuccessor;
        this.successor = arrn;
    }
}

