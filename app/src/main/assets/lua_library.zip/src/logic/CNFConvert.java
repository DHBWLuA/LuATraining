/*
 * Decompiled with CFR 0_115.
 */
package logic;

import java.io.PrintStream;
import java.util.ArrayList;
import logic.CheckCondition;
import logic.ConvertionMethods;

public class CNFConvert {
    private static final Character OPEN_BRACKET = Character.valueOf('(');
    private static final Character CLOSED_BRACKET = Character.valueOf(')');
    private static final Character IMPLICIT = Character.valueOf('\u2192');
    private static final Character AND = Character.valueOf('\u2227');
    private static final Character NOT = Character.valueOf('\u00ac');
    private static final Character OR = Character.valueOf('\u2228');
    private static final Character TRUE = Character.valueOf('\u22a8');

    public static String convertToCNF(String expression) {
        expression = new String(String.valueOf(Character.toString(NOT.charValue())) + "(" + expression + ")");
        expression = expression.replace(TRUE.charValue(), IMPLICIT.charValue());
        StringBuffer exWithoutImplicit = CNFConvert.convertImplicit(new StringBuffer(expression.replace(" ", "")));
        StringBuffer exWithAndBrackets = CNFConvert.placeBrackets(exWithoutImplicit);
        StringBuffer exWithoutDoubleBrackets = CheckCondition.removeDoubleInnerBrackets(exWithAndBrackets.toString());
        StringBuffer exWithoutDoubleNegations = CNFConvert.deleteDoubleNegations(exWithoutDoubleBrackets);
        StringBuffer exWithoutNot = CNFConvert.convertNOT(exWithoutDoubleNegations);
        StringBuffer exInCorrectForm = CNFConvert.convertToCNF(exWithoutNot);
        StringBuffer exWithEssentialBrackets = CNFConvert.deleteUnessentialBrackets(exInCorrectForm);
        StringBuffer exWithoutDoubleVariables = CNFConvert.deleteDoubleVariables(exWithEssentialBrackets);
        return CNFConvert.insertWhitespaces(exWithoutDoubleVariables.toString());
    }

    private static StringBuffer convertToCNF(StringBuffer exWithoutNot) {
        int topicalSignIndex = CNFConvert.getMainSignIndex(exWithoutNot);
        if (topicalSignIndex != 0) {
            int leftStartIndex = 0;
            int rightEndIndex = exWithoutNot.length();
            int leftBracketCount = 0;
            int i = topicalSignIndex - 1;
            while (i >= 0) {
                if (exWithoutNot.charAt(i) == OPEN_BRACKET.charValue() && leftBracketCount == 0) {
                    leftStartIndex = i;
                    break;
                }
                if (exWithoutNot.charAt(i) == OPEN_BRACKET.charValue() && leftBracketCount != 0) {
                    ++leftBracketCount;
                } else if (exWithoutNot.charAt(i) == CLOSED_BRACKET.charValue()) {
                    --leftBracketCount;
                } else if (exWithoutNot.charAt(i) == OR.charValue() && leftBracketCount == 0) {
                    leftStartIndex = i + 1;
                    break;
                }
                --i;
            }
            int rightBracketCount = 0;
            int i2 = topicalSignIndex + 1;
            while (i2 < exWithoutNot.length()) {
                if (i2 == exWithoutNot.length() - 1) {
                    rightEndIndex = exWithoutNot.length();
                } else {
                    if (exWithoutNot.charAt(i2) == CLOSED_BRACKET.charValue() && rightBracketCount == 0) {
                        rightEndIndex = i2 + 1;
                        break;
                    }
                    if (exWithoutNot.charAt(i2) == CLOSED_BRACKET.charValue() && rightBracketCount != 0) {
                        --rightBracketCount;
                    } else if (exWithoutNot.charAt(i2) == OPEN_BRACKET.charValue()) {
                        ++rightBracketCount;
                    } else if (exWithoutNot.charAt(i2) == OR.charValue() && rightBracketCount == 0) {
                        rightEndIndex = i2;
                        break;
                    }
                }
                ++i2;
            }
            String partToConvert = exWithoutNot.substring(leftStartIndex, rightEndIndex);
            if (ConvertionMethods.getBracketCount(partToConvert) == -1) {
                partToConvert = "(".concat(partToConvert);
                --leftStartIndex;
            }
            if (ConvertionMethods.getBracketCount(partToConvert) == 1) {
                partToConvert = partToConvert.concat(")");
                ++rightEndIndex;
            }
            if (leftStartIndex < 0) {
                leftStartIndex = 0;
            }
            if (rightEndIndex > exWithoutNot.length() - 1) {
                rightEndIndex = exWithoutNot.length() - 1;
            }
            String convertedPart = CNFConvert.convertConjunktiveConnection(partToConvert);
            String newConvertedPart = CNFConvert.removeOuterBrackets(new StringBuffer(convertedPart));
            String leftOldPart = exWithoutNot.charAt(leftStartIndex) == ')' || Character.isLetter(exWithoutNot.charAt(leftStartIndex)) ? exWithoutNot.substring(0, leftStartIndex) : exWithoutNot.substring(0, leftStartIndex + 1);
            String rightOldPart = exWithoutNot.charAt(rightEndIndex) == '(' || Character.isLetter(exWithoutNot.charAt(rightEndIndex)) || exWithoutNot.charAt(rightEndIndex) == NOT.charValue() ? exWithoutNot.substring(rightEndIndex - 1, exWithoutNot.length()) : exWithoutNot.substring(rightEndIndex, exWithoutNot.length());
            exWithoutNot.delete(0, exWithoutNot.length());
            exWithoutNot.append(leftOldPart);
            exWithoutNot.append(newConvertedPart);
            exWithoutNot.append(rightOldPart);
            CNFConvert.convertToCNF(exWithoutNot);
        }
        if (CNFConvert.hasOuterBrackets(exWithoutNot.toString())) {
            exWithoutNot.deleteCharAt(0);
            exWithoutNot.deleteCharAt(exWithoutNot.length() - 1);
        }
        return exWithoutNot;
    }

    public static String convertConjunktiveConnection(String expression) {
        if (!CNFConvert.hasOuterBrackets(expression)) {
            expression = "(".concat(expression).concat(")");
        }
        if (expression.charAt(0) != OPEN_BRACKET.charValue() || expression.charAt(expression.length() - 1) != CLOSED_BRACKET.charValue()) {
            expression = "(".concat(expression).concat(")");
        }
        int mainSignIndex = CNFConvert.getMainSignIndex(new StringBuffer(expression));
        ArrayList<String> leftExpressions = new ArrayList<String>();
        ArrayList<String> rightExpressions = new ArrayList<String>();
        int bracketCount = 0;
        boolean hasReachedMainSign = false;
        int i = 0;
        while (i < expression.length()) {
            String changedEntry;
            char topicalSign = expression.charAt(i);
            if (topicalSign == OPEN_BRACKET.charValue()) {
                ++bracketCount;
            } else if (topicalSign == CLOSED_BRACKET.charValue()) {
                --bracketCount;
            } else if (topicalSign == OR.charValue() && bracketCount == 1) {
                hasReachedMainSign = true;
            } else if (!hasReachedMainSign && Character.isLetter(expression.charAt(i))) {
                if (expression.charAt(i - 1) == NOT.charValue() && expression.charAt(i - 2) != OR.charValue()) {
                    leftExpressions.add(String.valueOf(Character.toString(NOT.charValue())) + Character.toString(topicalSign));
                } else if (expression.charAt(i - 1) == NOT.charValue() && expression.charAt(i - 2) == OR.charValue()) {
                    changedEntry = ((String)leftExpressions.get(leftExpressions.size() - 1)).concat(Character.toString(OR.charValue())).concat(Character.toString(NOT.charValue())).concat(Character.toString(topicalSign));
                    leftExpressions.set(leftExpressions.size() - 1, changedEntry);
                } else if (expression.charAt(i - 1) != NOT.charValue() && expression.charAt(i - 1) != OR.charValue()) {
                    leftExpressions.add(Character.toString(topicalSign));
                } else if (expression.charAt(i - 1) != NOT.charValue() && expression.charAt(i - 1) == OR.charValue()) {
                    changedEntry = ((String)leftExpressions.get(leftExpressions.size() - 1)).concat(Character.toString(OR.charValue())).concat(Character.toString(topicalSign));
                    leftExpressions.set(leftExpressions.size() - 1, changedEntry);
                }
            } else if (hasReachedMainSign && Character.isLetter(expression.charAt(i))) {
                if (expression.charAt(i - 1) == NOT.charValue() && expression.charAt(i - 2) != OR.charValue()) {
                    rightExpressions.add(String.valueOf(Character.toString(NOT.charValue())) + Character.toString(topicalSign));
                } else if (expression.charAt(i - 1) == NOT.charValue() && expression.charAt(i - 2) == OR.charValue() && i - 2 != mainSignIndex) {
                    changedEntry = ((String)rightExpressions.get(rightExpressions.size() - 1)).concat(Character.toString(OR.charValue())).concat(Character.toString(NOT.charValue())).concat(Character.toString(topicalSign));
                    rightExpressions.set(rightExpressions.size() - 1, changedEntry);
                } else if (expression.charAt(i - 1) == NOT.charValue() && expression.charAt(i - 2) == OR.charValue() && i - 2 == mainSignIndex) {
                    rightExpressions.add(String.valueOf(Character.toString(NOT.charValue())) + Character.toString(topicalSign));
                } else if (expression.charAt(i - 1) != NOT.charValue() && expression.charAt(i - 1) != OR.charValue()) {
                    rightExpressions.add(Character.toString(topicalSign));
                } else if (expression.charAt(i - 1) != NOT.charValue() && expression.charAt(i - 1) == OR.charValue() && i - 1 != mainSignIndex) {
                    changedEntry = ((String)rightExpressions.get(rightExpressions.size() - 1)).concat(Character.toString(OR.charValue())).concat(Character.toString(topicalSign));
                    rightExpressions.set(rightExpressions.size() - 1, changedEntry);
                } else if (expression.charAt(i - 1) != NOT.charValue() && expression.charAt(i - 1) == OR.charValue() && i - 1 == mainSignIndex) {
                    rightExpressions.add(Character.toString(topicalSign));
                }
            }
            ++i;
        }
        StringBuffer conjunctiveForm = new StringBuffer("(");
        int i2 = 0;
        while (i2 < leftExpressions.size()) {
            int j = 0;
            while (j < rightExpressions.size()) {
                conjunctiveForm.append("(");
                conjunctiveForm.append((String)leftExpressions.get(i2));
                conjunctiveForm.append(OR);
                conjunctiveForm.append((String)rightExpressions.get(j));
                conjunctiveForm.append(")");
                if (i2 != leftExpressions.size() - 1 || j != rightExpressions.size() - 1) {
                    conjunctiveForm.append(AND);
                }
                ++j;
            }
            ++i2;
        }
        conjunctiveForm.append(")");
        return conjunctiveForm.toString();
    }

    public static StringBuffer convertImplicit(StringBuffer condition) {
        int offset = 0;
        boolean hasChanged = false;
        int bracketCount = 0;
        block0 : while (offset < condition.length()) {
            char current = condition.charAt(offset);
            if (current == IMPLICIT.charValue()) {
                hasChanged = true;
                condition.replace(offset, offset + 1, Character.toString(OR.charValue()));
                boolean rightNeedBrackets = false;
                bracketCount = 0;
                int i = offset;
                while (i < condition.length()) {
                    if (condition.charAt(i) == '(') {
                        ++bracketCount;
                    } else if (condition.charAt(i) == ')') {
                        --bracketCount;
                    }
                    if (i != offset && bracketCount == 0 && condition.charAt(i + 1) != ')') {
                        rightNeedBrackets = true;
                    } else {
                        if (bracketCount == -1 && rightNeedBrackets) {
                            condition.insert(i, ")");
                            condition.insert(offset + 1, "(");
                            break;
                        }
                        if (bracketCount == -1 && !rightNeedBrackets) break;
                    }
                    ++i;
                }
                boolean leftNeedBrackets = false;
                bracketCount = 0;
                int i2 = offset;
                while (i2 >= 0) {
                    if (condition.charAt(i2) == '(') {
                        ++bracketCount;
                    } else if (condition.charAt(i2) == ')') {
                        --bracketCount;
                    }
                    if (i2 != offset && bracketCount == 0 && condition.charAt(i2 - 1) != '(') {
                        leftNeedBrackets = true;
                    } else {
                        if (bracketCount == 1 && leftNeedBrackets) {
                            condition.insert(offset, ")");
                            condition.insert(i2 + 1, String.valueOf(Character.toString(NOT.charValue())) + "(");
                            break block0;
                        }
                        if (bracketCount == 1 && !leftNeedBrackets) {
                            condition.insert(i2 + 1, NOT);
                            break block0;
                        }
                    }
                    --i2;
                }
                break;
            }
            ++offset;
        }
        if (hasChanged) {
            hasChanged = false;
            CNFConvert.convertImplicit(condition);
        }
        return condition;
    }

    public static StringBuffer deleteDoubleNegations(StringBuffer condition) {
        int offset = 0;
        while (offset < condition.length()) {
            char current = condition.charAt(offset);
            if (current == NOT.charValue()) {
                if (condition.charAt(offset + 1) == NOT.charValue()) {
                    condition.deleteCharAt(offset);
                    condition.deleteCharAt(offset);
                    continue;
                }
                ++offset;
                continue;
            }
            ++offset;
        }
        return condition;
    }

    public static String insertWhitespaces(String condition) {
        StringBuffer newCondition = new StringBuffer(condition);
        int offset = 0;
        while (offset < newCondition.length()) {
            char current = newCondition.charAt(offset);
            if (current == OR.charValue()) {
                if (!CNFConvert.checkWhitespace(newCondition.charAt(offset + 1))) {
                    newCondition.insert(offset, ' ');
                    offset += 2;
                }
                if (CNFConvert.checkWhitespace(newCondition.charAt(offset))) continue;
                newCondition.insert(offset, ' ');
                offset += 2;
                continue;
            }
            if (current == AND.charValue()) {
                if (!CNFConvert.checkWhitespace(newCondition.charAt(offset + 1))) {
                    newCondition.insert(offset, ' ');
                    offset += 2;
                }
                if (CNFConvert.checkWhitespace(newCondition.charAt(offset))) continue;
                newCondition.insert(offset, ' ');
                offset += 2;
                continue;
            }
            if (current == IMPLICIT.charValue() || current == TRUE.charValue()) {
                if (!CNFConvert.checkWhitespace(newCondition.charAt(offset + 1))) {
                    newCondition.insert(offset, ' ');
                    offset += 2;
                }
                if (CNFConvert.checkWhitespace(newCondition.charAt(offset))) continue;
                newCondition.insert(offset, ' ');
                offset += 2;
                continue;
            }
            ++offset;
        }
        return newCondition.toString();
    }

    public static boolean checkWhitespace(char proof) {
        return Character.isWhitespace(proof);
    }

    public static StringBuffer convertNOT(StringBuffer expression) {
        int offset = 0;
        int bracketCount = 0;
        boolean hasChanged = false;
        while (offset < expression.length()) {
            if (expression.charAt(offset) == NOT.charValue() && expression.charAt(offset + 1) == '(') {
                ++bracketCount;
                expression.deleteCharAt(offset);
                while (++offset < expression.length()) {
                    if (expression.charAt(offset) == OPEN_BRACKET.charValue()) {
                        if (bracketCount == 1) {
                            hasChanged = true;
                            expression.insert(offset, NOT);
                            ++offset;
                        }
                        ++bracketCount;
                    } else if (Character.isLetter(expression.charAt(offset)) && bracketCount == 1) {
                        hasChanged = true;
                        expression.insert(offset, NOT);
                        offset += 2;
                    } else if ((expression.charAt(offset) == AND.charValue() || expression.charAt(offset) == OR.charValue()) && bracketCount == 1) {
                        if (expression.charAt(offset) == AND.charValue()) {
                            expression.deleteCharAt(offset);
                            expression.insert(offset, OR);
                            ++offset;
                        } else if (expression.charAt(offset) == OR.charValue()) {
                            expression.deleteCharAt(offset);
                            expression.insert(offset, AND);
                            ++offset;
                        }
                    } else if (expression.charAt(offset) == CLOSED_BRACKET.charValue()) {
                        --bracketCount;
                        ++offset;
                    } else if (expression.charAt(offset) == NOT.charValue() && bracketCount == 1) {
                        expression.deleteCharAt(offset);
                        hasChanged = true;
                        if (expression.charAt(offset) == OPEN_BRACKET.charValue()) {
                            ++bracketCount;
                        } else {
                            ++offset;
                        }
                    }
                    if (bracketCount == 0) break;
                    if (bracketCount <= 1 || expression.charAt(offset) == CLOSED_BRACKET.charValue()) continue;
                    ++offset;
                }
                if (!hasChanged) continue;
                break;
            }
            ++offset;
        }
        if (hasChanged) {
            hasChanged = false;
            expression = CNFConvert.convertNOT(expression);
        }
        return expression;
    }

    public static String removeOuterBrackets(StringBuffer sbCNFWithBrackets) {
        sbCNFWithBrackets.deleteCharAt(0);
        sbCNFWithBrackets.deleteCharAt(sbCNFWithBrackets.length() - 1);
        return sbCNFWithBrackets.toString();
    }

    public static int getMainSignIndex(StringBuffer expression) {
        int bracketCount = 0;
        int topicalLevel = -1;
        int topicalSignIndex = 0;
        int i = 0;
        while (i < expression.length()) {
            char currentSign = expression.charAt(i);
            if (currentSign == OPEN_BRACKET.charValue()) {
                ++bracketCount;
            } else if (currentSign == CLOSED_BRACKET.charValue()) {
                --bracketCount;
            } else if (currentSign == OR.charValue() && bracketCount > topicalLevel) {
                if (expression.charAt(i - 1) == CLOSED_BRACKET.charValue() || expression.charAt(i + 1) == OPEN_BRACKET.charValue()) {
                    topicalLevel = bracketCount;
                    topicalSignIndex = i;
                } else if (expression.charAt(i + 1) == NOT.charValue() && expression.charAt(i + 2) == OPEN_BRACKET.charValue()) {
                    topicalLevel = bracketCount;
                    topicalSignIndex = i;
                } else if (i > 1 && expression.charAt(i - 2) == AND.charValue()) {
                    topicalLevel = bracketCount;
                    topicalSignIndex = i;
                } else if (i > 3 && expression.charAt(i - 2) == NOT.charValue() && expression.charAt(i - 3) == AND.charValue()) {
                    topicalLevel = bracketCount;
                    topicalSignIndex = i;
                } else if (i < expression.length() - 2 && expression.charAt(i + 2) == AND.charValue()) {
                    topicalLevel = bracketCount;
                    topicalSignIndex = i;
                } else if (expression.charAt(i + 1) == NOT.charValue() && expression.charAt(i + 3) == AND.charValue()) {
                    topicalLevel = bracketCount;
                    topicalSignIndex = i;
                }
            }
            ++i;
        }
        return topicalSignIndex;
    }

    private static boolean hasOuterBrackets(String expression) {
        int bracketCount = 0;
        boolean hasOuterBrackets = true;
        boolean hasBrackets = false;
        int i = 0;
        while (i < expression.length()) {
            if (expression.charAt(i) == '(') {
                ++bracketCount;
                hasBrackets = true;
            } else if (expression.charAt(i) == ')' && i != expression.length() - 1 && --bracketCount == 0) {
                hasOuterBrackets = false;
            }
            ++i;
        }
        if (!hasBrackets) {
            hasOuterBrackets = false;
        }
        return hasOuterBrackets;
    }

    public static StringBuffer deleteUnessentialBrackets(StringBuffer expression) {
        String exWithoutBrackets = expression.toString();
        exWithoutBrackets = exWithoutBrackets.replace("(", "");
        exWithoutBrackets = exWithoutBrackets.replace(")", "");
        System.out.println("egwg" + expression);
        StringBuffer newExpression = new StringBuffer(exWithoutBrackets);
        int bracketCount = 0;
        int i = 0;
        while (i < newExpression.length()) {
            if (!(newExpression.charAt(1) != OR.charValue() && newExpression.charAt(2) != OR.charValue() || i != 1 && i != 2 || !CNFConvert.hasAND(expression))) {
                newExpression.insert(0, "(");
                ++bracketCount;
                ++i;
            } else {
                if (newExpression.charAt(newExpression.length() - 2) == OR.charValue() && i == newExpression.length() - 2 && CNFConvert.hasAND(expression)) {
                    newExpression.insert(newExpression.length(), ")");
                    --bracketCount;
                    break;
                }
                if (newExpression.charAt(newExpression.length() - 3) == OR.charValue() && i == newExpression.length() - 3) {
                    newExpression.insert(newExpression.length(), ")");
                    --bracketCount;
                    break;
                }
                if (i == newExpression.length() - 1) break;
                if (i > 1 && newExpression.charAt(i - 1) == AND.charValue() && Character.isLetter(newExpression.charAt(i)) && newExpression.charAt(i + 1) == OR.charValue()) {
                    newExpression.insert(i, "(");
                    ++i;
                    ++bracketCount;
                } else if (i > 2 && i < newExpression.length() - 1 && newExpression.charAt(i - 2) == AND.charValue() && Character.isLetter(newExpression.charAt(i)) && newExpression.charAt(i + 1) == OR.charValue()) {
                    newExpression.insert(i - 1, "(");
                    ++i;
                    ++bracketCount;
                }
                if (i < newExpression.length() - 1 && newExpression.charAt(i + 1) == AND.charValue() && Character.isLetter(newExpression.charAt(i)) && bracketCount == 1) {
                    newExpression.insert(i + 1, ")");
                    --bracketCount;
                }
            }
            ++i;
        }
        return newExpression;
    }

    public static StringBuffer deleteDoubleVariables(StringBuffer expression) {
        int currentIndex = 0;
        int bracketCount = 0;
        int i = 0;
        while (i < expression.length()) {
            if (expression.charAt(i) == '(') {
                ++bracketCount;
            } else if (expression.charAt(i) == ')') {
                --bracketCount;
            }
            if (bracketCount == 1) {
                if (Character.isLetter(expression.charAt(i)) && expression.charAt(i - 1) != NOT.charValue()) {
                    currentIndex = i + 1;
                    while (expression.charAt(currentIndex) != ')' && expression.charAt(currentIndex) != AND.charValue() && currentIndex != expression.length() - 1) {
                        if (expression.charAt(currentIndex) == expression.charAt(i) && expression.charAt(currentIndex - 1) != NOT.charValue()) {
                            expression.delete(currentIndex - 1, currentIndex + 1);
                            break;
                        }
                        ++currentIndex;
                    }
                } else if (Character.isLetter(expression.charAt(i)) && expression.charAt(i - 1) == NOT.charValue() && currentIndex != expression.length() - 1) {
                    currentIndex = i + 1;
                    while (expression.charAt(currentIndex) != ')' && expression.charAt(currentIndex) != AND.charValue()) {
                        if (expression.charAt(currentIndex) == expression.charAt(i) && expression.charAt(currentIndex - 1) == NOT.charValue()) {
                            expression.delete(currentIndex - 2, currentIndex + 1);
                            break;
                        }
                        ++currentIndex;
                    }
                }
            }
            ++i;
        }
        i = 0;
        while (i < expression.length()) {
            if (expression.charAt(i) == '(' && expression.charAt(i + 2) == ')') {
                expression.deleteCharAt(i + 2);
                expression.deleteCharAt(i);
            } else if (expression.charAt(i) == '(' && expression.charAt(i + 3) == ')') {
                expression.deleteCharAt(i + 3);
                expression.deleteCharAt(i);
            }
            ++i;
        }
        return expression;
    }

    public static StringBuffer placeBrackets(StringBuffer expression) {
        int i = 0;
        while (i < expression.length()) {
            int leftIndexInsertion = -1;
            int rightIndexInsertion = -1;
            if (expression.charAt(i) == AND.charValue()) {
                int bracketCount = 0;
                int j = i;
                while (j < expression.length()) {
                    if (expression.charAt(j) == OPEN_BRACKET.charValue()) {
                        ++bracketCount;
                    } else if (expression.charAt(j) == CLOSED_BRACKET.charValue()) {
                        --bracketCount;
                    }
                    if (j == expression.length() - 2) {
                        expression.insert(j + 1, CLOSED_BRACKET);
                        rightIndexInsertion = j + 1;
                        break;
                    }
                    if (bracketCount == -1) {
                        expression.insert(j, CLOSED_BRACKET);
                        rightIndexInsertion = j;
                        break;
                    }
                    if (bracketCount == 0 && expression.charAt(j) == CLOSED_BRACKET.charValue() && (expression.charAt(j + 1) == OR.charValue() || expression.charAt(j + 1) == CLOSED_BRACKET.charValue())) {
                        expression.insert(j, CLOSED_BRACKET);
                        rightIndexInsertion = j;
                        break;
                    }
                    if (expression.charAt(i) == OR.charValue() && bracketCount == 0) {
                        expression.insert(j, CLOSED_BRACKET);
                        rightIndexInsertion = j;
                        break;
                    }
                    ++j;
                }
                bracketCount = 0;
                j = i;
                while (j >= 0) {
                    if (expression.charAt(j) == OPEN_BRACKET.charValue()) {
                        ++bracketCount;
                    } else if (expression.charAt(j) == CLOSED_BRACKET.charValue()) {
                        --bracketCount;
                    }
                    if (j == 2) {
                        expression.insert(2, OPEN_BRACKET);
                        leftIndexInsertion = 2;
                        ++rightIndexInsertion;
                        ++i;
                        break;
                    }
                    if (bracketCount == 0 && expression.charAt(j) == OPEN_BRACKET.charValue() && (expression.charAt(j - 1) == OR.charValue() || expression.charAt(j - 1) == OPEN_BRACKET.charValue())) {
                        expression.insert(j, OPEN_BRACKET);
                        leftIndexInsertion = j;
                        ++rightIndexInsertion;
                        ++i;
                        break;
                    }
                    if (expression.charAt(j) == OR.charValue() && bracketCount == 0) {
                        leftIndexInsertion = j + 1;
                        ++rightIndexInsertion;
                        expression.insert(j + 1, OPEN_BRACKET);
                        ++i;
                        break;
                    }
                    --j;
                }
                if (leftIndexInsertion == 2 && rightIndexInsertion == expression.length() - 2) {
                    expression.deleteCharAt(rightIndexInsertion);
                    expression.deleteCharAt(2);
                }
            }
            ++i;
        }
        return expression;
    }

    public static boolean hasAND(StringBuffer expression) {
        int i = 0;
        while (i < expression.length()) {
            if (expression.charAt(i) == AND.charValue()) {
                return true;
            }
            ++i;
        }
        return false;
    }
}

