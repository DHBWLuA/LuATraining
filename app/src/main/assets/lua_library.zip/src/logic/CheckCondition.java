/*
 * Decompiled with CFR 0_115.
 */
package logic;

import logic.CNFConvert;
import logic.ConvertionMethods;

public class CheckCondition {
    private static final Character OPEN_BRACKET = Character.valueOf('(');
    private static final Character CLOSED_BRACKET = Character.valueOf(')');
    private static final Character IMPLICIT = Character.valueOf('\u2192');
    private static final Character AND = Character.valueOf('\u2227');
    private static final Character NOT = Character.valueOf('\u00ac');
    private static final Character OR = Character.valueOf('\u2228');
    private static final Character TRUE = Character.valueOf('\u22a8');

    public static String trim(String condition) {
        StringBuffer sb = new StringBuffer(condition);
        int offset = 0;
        while (offset < sb.length()) {
            char current = sb.charAt(offset);
            if (Character.isLowerCase(current)) {
                sb.replace(offset, offset + 1, Character.toString(Character.toUpperCase(current)));
                ++offset;
                continue;
            }
            ++offset;
        }
        offset = 0;
        String expressionWithoutDoubleNegations = CNFConvert.deleteDoubleNegations(sb).toString();
        String expressionWithRemovedDoubleInnerBrackets = CheckCondition.removeDoubleInnerBrackets(expressionWithoutDoubleNegations).toString();
        return CNFConvert.insertWhitespaces(expressionWithRemovedDoubleInnerBrackets);
    }

    public static int checkLogicalValid(String condition) {
        int valid = 0;
        StringBuffer sb = new StringBuffer(ConvertionMethods.removeWhitespaces(condition));
        int bracketCount = 0;
        int offset = 0;
        boolean bracket = true;
        while (offset < sb.length()) {
            char current = sb.charAt(offset);
            if (CheckCondition.isOperator(current) && offset == sb.length() - 1) {
                valid = 7;
                break;
            }
            if (CheckCondition.isOperator(current)) {
                if (CheckCondition.isOperator(sb.charAt(offset + 1))) {
                    valid = 1;
                    bracket = false;
                    break;
                }
                if (!CheckCondition.isVariable(sb.charAt(offset + 1))) {
                    if (sb.charAt(offset + 1) == OPEN_BRACKET.charValue() || sb.charAt(offset + 1) == NOT.charValue()) {
                        ++offset;
                        continue;
                    }
                    valid = 6;
                    bracket = false;
                    break;
                }
                ++offset;
                continue;
            }
            if (current == OPEN_BRACKET.charValue()) {
                ++bracketCount;
                if (!CheckCondition.isVariable(sb.charAt(offset + 1)) && sb.charAt(offset + 1) != OPEN_BRACKET.charValue() && sb.charAt(offset + 1) != NOT.charValue()) {
                    valid = 4;
                    bracket = false;
                    break;
                }
                if (sb.charAt(offset + 1) == NOT.charValue()) {
                    ++offset;
                    continue;
                }
                if (sb.charAt(offset + 1) == OPEN_BRACKET.charValue()) {
                    ++offset;
                    continue;
                }
                ++offset;
                continue;
            }
            if (current == CLOSED_BRACKET.charValue()) {
                --bracketCount;
                ++offset;
                continue;
            }
            if (current == NOT.charValue()) {
                if (!CheckCondition.isVariable(sb.charAt(offset + 1)) && sb.charAt(offset + 1) != OPEN_BRACKET.charValue()) {
                    valid = 5;
                    bracket = false;
                    break;
                }
                ++offset;
                continue;
            }
            if (CheckCondition.isVariable(current)) {
                if (offset != 0 && sb.charAt(offset - 1) != OPEN_BRACKET.charValue() && sb.charAt(offset - 1) != NOT.charValue()) {
                    if (CheckCondition.isOperator(sb.charAt(offset - 1))) {
                        ++offset;
                        continue;
                    }
                    valid = 7;
                    bracket = false;
                    break;
                }
                ++offset;
                continue;
            }
            ++offset;
        }
        if (bracket) {
            if (bracketCount < 0) {
                valid = 2;
            } else if (bracketCount > 0) {
                valid = 3;
            }
        }
        return valid;
    }

    private static boolean isOperator(char c) {
        boolean bOperator = false;
        bOperator = c == OR.charValue() || c == AND.charValue() || c == IMPLICIT.charValue() || c == TRUE.charValue();
        return bOperator;
    }

    private static boolean isVariable(char c) {
        boolean bVariable = false;
        bVariable = Character.isLetter(c);
        return bVariable;
    }

    public static StringBuffer removeDoubleInnerBrackets(String condition) {
        int indexOpenBracket;
        char current;
        int i;
        StringBuffer sb = new StringBuffer(condition);
        int offset = 0;
        int bracketCount = 0;
        while (offset < sb.length()) {
            current = sb.charAt(offset);
            if (current == OPEN_BRACKET.charValue() && sb.charAt(offset + 1) == OPEN_BRACKET.charValue()) {
                indexOpenBracket = offset;
                ++bracketCount;
                i = offset + 1;
                while (i <= sb.length() - 1) {
                    if (sb.charAt(i) == OPEN_BRACKET.charValue()) {
                        ++bracketCount;
                    } else if (sb.charAt(i) == CLOSED_BRACKET.charValue()) {
                        --bracketCount;
                    }
                    if (bracketCount == 1 && sb.charAt(i + 1) == CLOSED_BRACKET.charValue()) {
                        sb.deleteCharAt(i);
                        sb.deleteCharAt(indexOpenBracket);
                        offset = indexOpenBracket;
                        bracketCount = 0;
                        break;
                    }
                    if (bracketCount == 1 && sb.charAt(i + 1) != CLOSED_BRACKET.charValue()) {
                        bracketCount = 0;
                        break;
                    }
                    ++i;
                }
                ++offset;
                continue;
            }
            ++offset;
        }
        offset = sb.length() - 1;
        while (offset > -1) {
            current = sb.charAt(offset);
            if (current == CLOSED_BRACKET.charValue() && sb.charAt(offset - 1) == CLOSED_BRACKET.charValue()) {
                indexOpenBracket = offset;
                ++bracketCount;
                i = offset - 1;
                while (i > -1) {
                    if (sb.charAt(i) == CLOSED_BRACKET.charValue()) {
                        ++bracketCount;
                    } else if (sb.charAt(i) == OPEN_BRACKET.charValue()) {
                        --bracketCount;
                    }
                    if (bracketCount == 1 && sb.charAt(i - 1) == OPEN_BRACKET.charValue()) {
                        sb.deleteCharAt(i);
                        sb.deleteCharAt(indexOpenBracket);
                        offset = indexOpenBracket;
                        bracketCount = 0;
                        break;
                    }
                    if (bracketCount == 1 && sb.charAt(i - 1) != OPEN_BRACKET.charValue()) {
                        bracketCount = 0;
                        break;
                    }
                    --i;
                }
                --offset;
                continue;
            }
            --offset;
        }
        if (sb.charAt(0) != NOT.charValue()) {
            offset = 0;
            bracketCount = 0;
            while (offset < sb.length()) {
                current = sb.charAt(offset);
                if (current == OPEN_BRACKET.charValue()) {
                    ++bracketCount;
                    ++offset;
                    continue;
                }
                if (current == CLOSED_BRACKET.charValue()) {
                    if (offset < sb.length() - 1 && sb.charAt(offset + 1) == CLOSED_BRACKET.charValue() && offset == sb.length() - 2 && --bracketCount == 1) {
                        if (sb.charAt(0) != sb.charAt(1)) continue;
                        sb.deleteCharAt(0);
                        sb.deleteCharAt(sb.length() - 2);
                        break;
                    }
                    if (bracketCount == 0 && offset < sb.length() - 1) break;
                    ++offset;
                    continue;
                }
                ++offset;
            }
        }
        return sb;
    }
}

