/*
 * Decompiled with CFR 0_115.
 */
package logic;

import java.util.ArrayList;

public class Condition {
    private int id;
    private ArrayList<String> condExprs;

    public Condition(int id, ArrayList<String> condExprs) {
        this.id = id;
        this.condExprs = condExprs;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public ArrayList<String> getCondExprs() {
        return this.condExprs;
    }

    public void setCondExprs(ArrayList<String> condExprs) {
        this.condExprs = condExprs;
    }

    public String toString() {
        String condString = "";
        int i = 0;
        while (i < this.condExprs.size()) {
            condString = i == this.condExprs.size() - 1 ? String.valueOf(condString) + this.condExprs.get(i) : String.valueOf(condString) + this.condExprs.get(i) + ", ";
            ++i;
        }
        return String.valueOf(this.id) + " { " + condString + " }";
    }

    public String exprToString() {
        String exprString = "";
        int i = 0;
        while (i < this.condExprs.size()) {
            exprString = i == this.condExprs.size() - 1 ? String.valueOf(exprString) + this.condExprs.get(i) : String.valueOf(exprString) + this.condExprs.get(i) + ", ";
            ++i;
        }
        return " { " + exprString + " }";
    }
}

